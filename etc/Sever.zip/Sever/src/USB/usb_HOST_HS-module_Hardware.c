/**
  ******************************************************************************
  * @file    usb_bsp.c
  * @author  MCD Application Team
  * @version V2.1.0
  * @date    19-March-2012
  * @brief   This file implements the board support package for the USB host library
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2012 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/

#include "usb_bsp.h"



//#define USE_ACCURATE_TIME
#define TIM_MSEC_DELAY                     0x01
#define TIM_USEC_DELAY                     0x02

#define HOST_POWERSW_PORT_RCC             RCC_AHB1Periph_GPIOB
#define HOST_POWERSW_PORT                 GPIOB
#define HOST_POWERSW_VBUS                 GPIO_Pin_13


// #define HOST_SOF_OUTPUT_RCC                RCC_APB2Periph_GPIOA
// #define HOST_SOF_PORT                      GPIOA
// #define HOST_SOF_SIGNAL                    GPIO_Pin_8



/** @defgroup USBH_BSP_Private_Variables
  * @{
  */ 
ErrorStatus HSEStartUpStatus;



/*****************************************************************************
*	@function		USB_HS_HOST_BSP_Init
*	@brief			Initializes BSP configurations
*	@input			USB_OTG_CORE_HANDLE *pdev
*	@output			void
*****************************************************************************/
void USB_HS_HOST_BSP_Init(USB_OTG_CORE_HANDLE *pdev)
{
/*
    USB - Flash - HS-FS (HS)
    74 - PB13 - OTG_HS_FS_VBUS
    75 - PB14 - OTG_HS_FS_DM
    76 - PB15 - JNG_HS_FS_DP
*/

// EXTI_InitTypeDef EXTI_InitStructure;
 GPIO_InitTypeDef GPIO_InitStructure;

  RCC_AHB1PeriphClockCmd( RCC_AHB1Periph_GPIOB , ENABLE);  
  
 /* Configure VBUS ID DM DP Pins */
	// --- DP DM pins
  GPIO_InitStructure.GPIO_Pin = ( GPIO_Pin_14 | GPIO_Pin_15);
  
  GPIO_InitStructure.GPIO_Speed	= GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd 	= GPIO_PuPd_NOPULL;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
 
  GPIO_PinAFConfig(GPIOB,GPIO_PinSource14,GPIO_AF_OTG2_FS);
  GPIO_PinAFConfig(GPIOB,GPIO_PinSource15,GPIO_AF_OTG2_FS);

  RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_OTG_HS, ENABLE) ; 

  /* Intialize Timer for delay function */
#ifdef USE_ACCURATE_TIME
  USB_OTG_BSP_TimeInit();   
#endif
}

/**
  * @brief  USB_HS_HOST_BSP_EnableInterrupt
  *         Configures USB Global interrupt
  * @param  None
  * @retval None
  */

void USB_HS_HOST_BSP_EnableInterrupt(USB_OTG_CORE_HANDLE *pdev)
{
  NVIC_InitTypeDef NVIC_InitStructure; 
  
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
  NVIC_InitStructure.NVIC_IRQChannel = OTG_HS_IRQn;  
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);  

}

/**
  * @brief  BSP_Drive_VBUS
  *         Drives the Vbus signal through IO
  * @param  state : VBUS states
  * @retval None
  */

void USB_OTG_BSP_DriveVBUS(USB_OTG_CORE_HANDLE *pdev, uint8_t state)
{
  /*
  On-chip 5 V VBUS generation is not supported. For this reason, a charge pump 
  or, if 5 V are available on the application board, a basic power switch, must 
  be added externally to drive the 5 V VBUS line. The external charge pump can 
  be driven by any GPIO output. When the application decides to power on VBUS 
  using the chosen GPIO, it must also set the port power bit in the host port 
  control and status register (PPWR bit in OTG_FS_HPRT).
  
  Bit 12 PPWR: Port power
  The application uses this field to control power to this port, and the core 
  clears this bit on an overcurrent condition.
  */
    /*
  if (0 == state)
  { 
    GPIO_SetBits(HOST_POWERSW_PORT, HOST_POWERSW_VBUS);
  }
  else
  {
    GPIO_ResetBits(HOST_POWERSW_PORT, HOST_POWERSW_VBUS);
  }
  */
}

/**
  * @brief  USB_OTG_BSP_ConfigVBUS
  *         Configures the IO for the Vbus and OverCurrent
  * @param  None
  * @retval None
  */

void  USB_OTG_BSP_ConfigVBUS(USB_OTG_CORE_HANDLE *pdev)
{
    return;

    /*
  GPIO_InitTypeDef GPIO_InitStructure; 

  RCC_AHB1PeriphClockCmd( HOST_POWERSW_PORT_RCC , ENABLE);  
  
  GPIO_InitStructure.GPIO_Pin = HOST_POWERSW_VBUS;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP ;
  GPIO_Init(HOST_POWERSW_PORT,&GPIO_InitStructure);
    */

  /* By Default, DISABLE is needed on output of the Power Switch */
  // GPIO_SetBits(HOST_POWERSW_PORT, HOST_POWERSW_VBUS);
  
  // USB_OTG_BSP_mDelay(200);   /* Delay is need for stabilising the Vbus Low 
  //in Reset Condition, when Vbus=1 and Reset-button is pressed by user */
}


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
