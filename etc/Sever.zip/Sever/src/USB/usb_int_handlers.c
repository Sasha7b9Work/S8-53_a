
/* Includes ------------------------------------------------------------------*/
#include "usb_bsp.h"
#include "usb_hcd_int.h"
#include "usb_dcd_int.h"
#include "usbh_core.h"
#include "usb_int_handlers.h"

#include "../main.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

extern USB_OTG_CORE_HANDLE          USB_HS_Host_Core;
extern USBH_HOST                    USB_Host;

extern USB_OTG_CORE_HANDLE           USB_OTG_dev;

 
/* Private function prototypes -----------------------------------------------*/
extern void USB_OTG_BSP_TimerIRQ (void);

/* Private functions ---------------------------------------------------------*/


/**
  * @brief  TIM2_IRQHandler
  *         This function handles Timer2 Handler.
  * @param  None
  * @retval None
  */
void TIM2_IRQHandler(void)
{
  USB_OTG_BSP_TimerIRQ();
}

void SysTick_Handler(void)
{
    Time_Update();
}
/**
  * @brief  OTG_FS_IRQHandler
  *          This function handles USB-On-The-Go FS global interrupt request.
  *          requests.
  * @param  None
  * @retval None
  */

void OTG_FS_IRQHandler(void)
{
  USBD_OTG_ISR_Handler (&USB_OTG_dev);
}

/**
  * @brief  OTG_HS_IRQHandler
  *          This function handles USB-On-The-Go HS global interrupt request.
  *          requests.
  * @param  None
  * @retval None
  */
void OTG_HS_IRQHandler(void)
{
  USBH_OTG_ISR_Handler(&USB_HS_Host_Core);
}

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
