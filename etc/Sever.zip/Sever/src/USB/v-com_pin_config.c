//	config hardware (pins & interrupts) 
	
/* Includes ------------------------------------------------------------------*/

#include "v-com_pin_config.h"



//--- local definitions - pin rename according functionality
#define USB_VBUS_Pin	GPIO_Pin_9
#define USB_ID_Pin		GPIO_Pin_10
#define USB_DM_Pin		GPIO_Pin_11
#define USB_DP_Pin		GPIO_Pin_12

#define USB_VBUS_PinSourse 	GPIO_PinSource9
#define USB_ID_PinSourse 		GPIO_PinSource10
#define USB_DM_PinSourse 		GPIO_PinSource11
#define USB_DP_PinSourse 		GPIO_PinSource12


/*****************************************************************************
*	@function		USB_FS_DEV_BSP_Init
*	@brief			Initializes BSP configurations
*	@input			USB_OTG_CORE_HANDLE *pdev
*	@output			void
*****************************************************************************/
void USB_FS_DEV_BSP_Init(USB_OTG_CORE_HANDLE *pdev)
{

  GPIO_InitTypeDef GPIO_InitStructure;   
  RCC_AHB1PeriphClockCmd( RCC_AHB1Periph_GPIOA , ENABLE);  
  
   /* Configure SOF ID DM DP Pins */
  GPIO_InitStructure.GPIO_Pin = USB_ID_Pin  | 							// corrected
                                USB_DM_Pin	| 
                                USB_DP_Pin;
  
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
  GPIO_Init(GPIOA, &GPIO_InitStructure);  
  
  GPIO_PinAFConfig(GPIOA,USB_ID_PinSourse,GPIO_AF_OTG1_FS) ;
  GPIO_PinAFConfig(GPIOA,USB_DM_PinSourse,GPIO_AF_OTG1_FS) ; 
  GPIO_PinAFConfig(GPIOA,USB_DP_PinSourse,GPIO_AF_OTG1_FS) ;
  
  /* Configure  VBUS Pin */
  GPIO_InitStructure.GPIO_Pin = USB_VBUS_Pin;									// corrected
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
  GPIO_Init(GPIOA, &GPIO_InitStructure);    
  
  /* Configure ID pin */
  GPIO_InitStructure.GPIO_Pin =  USB_ID_Pin;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP ;  
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);  
  GPIO_PinAFConfig(GPIOA,USB_ID_PinSourse,GPIO_AF_OTG1_FS) ;   
 
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
  RCC_AHB2PeriphClockCmd(RCC_AHB2Periph_OTG_FS, ENABLE) ; 				// looks like OK
 
}

/**
  * @brief  USB_FS_DEV_BSP_EnableInterrupt
  *         Configures USB Global interrupt
  * @param  None
  * @retval None
  */

void USB_FS_DEV_BSP_EnableInterrupt(USB_OTG_CORE_HANDLE *pdev)	{
  NVIC_InitTypeDef NVIC_InitStructure; 
  
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);

  NVIC_InitStructure.NVIC_IRQChannel = OTG_FS_IRQn;  		// use OTG_FS 

  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);  

	// there is nothing interesting was here (just strange & useles smth with OTG_FS shit)
}


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
