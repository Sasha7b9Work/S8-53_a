/**
  ******************************************************************************
  * @file    usbh_usr.h
  * @author  MCD Application Team
  * @version V2.1.0
  * @date    19-March-2012
  * @brief   Header file for usbh_usr.c
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2012 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */ 

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __USH_USR_H__
#define __USH_USR_H__

/* Includes ------------------------------------------------------------------*/
#include "ff.h"
#include "usbh_core.h"
#include "usb_conf.h"
#include "usbh_msc_core.h"
#include "../defines.h"

// define line from debug project: USE_STM322xG_EVAL,  USE_USB_OTG_FS,  USE_EMBEDDED_PHY, USE_STDPERIPH_DRIVER


// declaration prototypes for exported global data structs
extern USB_OTG_CORE_HANDLE  USB_HS_Host_Core;
extern USBH_HOST            USB_Host;
extern USBH_Usr_cb_TypeDef	USR_Host_cb;





// usser callbacks prototypes, needed for proper work 
// 	maybe this list will be decreased
void USBH_USR_ApplicationSelected(void);
void USBH_USR_Init(void);
void USBH_USR_DeInit(void);
void USBH_USR_DeviceAttached(void);
void USBH_USR_ResetDevice(void);
void USBH_USR_DeviceDisconnected (void);
void USBH_USR_OverCurrentDetected (void);
void USBH_USR_DeviceSpeedDetected(uint8_t DeviceSpeed); 
void USBH_USR_Device_DescAvailable(void *);
void USBH_USR_DeviceAddressAssigned(void);
void USBH_USR_Configuration_DescAvailable(USBH_CfgDesc_TypeDef * cfgDesc,
                                          USBH_InterfaceDesc_TypeDef *itfDesc,
                                          USBH_EpDesc_TypeDef *epDesc);
void USBH_USR_Manufacturer_String(void *);
void USBH_USR_Product_String(void *);
void USBH_USR_SerialNum_String(void *);
void USBH_USR_EnumerationDone(void);
USBH_USR_Status USBH_USR_UserInput(void);
void USBH_USR_DeInit(void);
void USBH_USR_DeviceNotSupported(void);
void USBH_USR_UnrecoveredError(void);
int USBH_USR_MSC_Application(void);



// some debug if-def constructions

//#define USE_CONSOLE_MECH
#define USE_API_MECH

#ifdef USE_CONSOLE_MECH

// FS Application state machine states
typedef enum {
	FS_NOPE,
	FS_MOUNT,
	FS_LS,
	FS_CD,
	FS_CP,
	FS_MV,
	FS_RM,
	FS_PWD,
	FS_MKDIR,
	FS_RMDIR,
	FS_CAT,
	FS_TOUCH,
	FS_VOLINFO,
	FS_API_BUILD_LIST
}	FS_Application_Status_Typedef;


typedef struct {
	uint8_t state;
	char **arg;
	char* tokens[5];
	char  path[128];
}	USBH_USR_AppStateDataStruct_TypeDef;
#endif	// USE_CONSOLE_MECH


#ifdef USE_API_MECH

// FS Application state machine states
typedef enum {
	FS_ST_NOPE,
	FS_ST_MOUNT,
	FS_ST_CREATE_FILE,
	FS_ST_CREATE_DIR,
	FS_ST_WRITE_DATA,
	FS_ST_READ_DATA,
	FS_ST_CHDIR,
	FS_ST_REMOVE,
	FS_ST_GET_ITEMS_NUM,
	FS_ST_GET_ITEM,
	FS_ST_GET_PATH,
	FS_ST_UNMOUNT,
	FS_ST_GET_FREE,
}	FS_Application_Status_Typedef;

#define WD_PATH_LENTH 255
#define SFN_LENTH 13



// main status-storage datastruct
typedef struct {
	FS_Application_Status_Typedef state;
#if _LFN_UNICODE
    TCHAR  wdpath[WD_PATH_LENTH];
#else
	char  wdpath[WD_PATH_LENTH];
#endif
	uint32_t free_space;
	
	//FRESULT res;
	uint8_t res;
	
	uint8_t * write_data_buffer;
	uint32_t write_buffer_size;
	
	uint8_t * read_data_buffer;
	uint32_t read_buffer_size;
	
	uint32_t data_offset;
	
	FILINFO fileinfo;
	uint32_t items_num;
	uint32_t need_item;
#if _LFN_UNICODE
    TCHAR   filename[SFN_LENTH];
#else
	char	filename[SFN_LENTH];
#endif
}	USBH_USR_AppStateDataStruct_TypeDef;




// API-functions for export

void uffs_dcreate(char * dirname);
void uffs_read(char* filename, char * read_buff, uint32_t buff_size, uint32_t offset);
void uffs_remove(char * name);
void uffs_chdir(char * path);
uint32_t  uffs_get_items_num(void);
FILINFO* uffs_get_item(uint32_t seek_num);


bool FlashDriveIsConnected(void);

bool FS_GetNameCurrentDir(TCHAR buffer[50], int sizeBuffer);
int  FS_GetNumItemsInDir(TCHAR *path);
void  FS_SetFirstItem(void);
bool FS_GetInfoAboutNextItem(char name[20], uint8 *attrib);
bool FS_GetInfoAboutItem(int numItem, char name[20], uint8 *attrib);


/// ������� ��� ������ ����. �������� � ���������.
#if _USE_LFN > 0
bool OpenFile(TCHAR *fileName);
#else
bool OpenFile(char *fileName);          // ������ ���� � ������ fileName �������� �������.
#endif
bool WriteToFile(uint8 *buffer, int sizeBuffer);    // ���������� � ����� ����� � ������ fileName ������ �� buffer.
bool CloseLastFile(void);               // ������� ����.

#endif		// USE_API_MECH


#endif /*__USH_USR_H__*/


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

