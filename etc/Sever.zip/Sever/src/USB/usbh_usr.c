/**
  ******************************************************************************
  * @file    usbh_usr.c
  * @author  SS-service
  * @version V8
  * @date    19-March-2012
  * @brief   This file includes the usb host library user callbacks
  ******************************************************************************
  *
  */

/* Includes ------------------------------------------------------------------*/
#include <string.h>
#include "usbh_usr.h"
#include "ff.h"       /* FATFS */
#include "usbh_msc_core.h"
#include "usbh_msc_scsi.h"
#include "usbh_msc_bot.h" 
#include "../../Log.h"
#include "../../defines.h"
#include "../Menu/Menu.h    "
#include "../Timer.h"


//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//#define MAX_LIST_SIZE 254
#define	MAX_PATH_SIZE 512
//#define IS_DIR(fi)	((fi.fattrib & AM_MASK) == AM_DIR)
#define IS_DIR(fi)	(((fi) & AM_MASK) == AM_DIR)


///////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////

#if _LFN_UNICODE
uint8_t fs_create_file_processor(TCHAR * path);
uint8_t fs_create_directory_processor(TCHAR * dir_name);
uint8_t fs_data_write_processor(TCHAR * path, uint8_t * data, uint32_t data_lenth, uint32_t data_offset);
uint8_t fs_remove_item_processor(TCHAR * path);
uint8_t fs_set_work_directory_processor(TCHAR * path);
uint8_t fs_mount_processor(TCHAR * rootpath);
uint8_t fs_data_read_processor(TCHAR * path, uint8_t * data, uint32_t data_lenth, uint32_t data_offset);
uint8_t fs_get_directory_items_num_processor(TCHAR * path, uint32_t * items_num);
uint8_t fs_get_directory_item_data_processor(TCHAR * path, uint32_t item_num, FILINFO * fno);
uint8_t fs_get_working_directory_processor(TCHAR* dir_name, uint16_t path_lenth);
#else
uint8_t fs_create_file_processor(char * path);
uint8_t fs_create_directory_processor(char * dir_name);
uint8_t fs_data_write_processor(char * path, uint8_t * data, uint32_t data_lenth, uint32_t data_offset);
uint8_t fs_remove_item_processor(char * path);
uint8_t fs_set_work_directory_processor(char * path);
uint8_t fs_mount_processor(char * rootpath);
uint8_t fs_data_read_processor(char * path, uint8_t * data, uint32_t data_lenth, uint32_t data_offset);
uint8_t fs_get_directory_items_num_processor(char * path, uint32_t * items_num);
uint8_t fs_get_directory_item_data_processor(char * path, uint32_t item_num, FILINFO * fno);
uint8_t fs_get_working_directory_processor(char* dir_name, uint16_t path_lenth);
#endif
    
uint8_t fs_unmount_processor(void);
uint8_t fs_get_free_spase_processor(uint32_t * freespace);



///////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////


USB_OTG_CORE_HANDLE						USB_HS_Host_Core;
USBH_HOST                     USB_Host;

extern FS_Application_Status_Typedef FS_Application_Status;


USBH_USR_AppStateDataStruct_TypeDef USBH_USR_AppState = 
{.state = FS_ST_NOPE};

static bool flashDriveIsConnected = false;



FATFS fatfs;
extern FIL file;

/*  Points to the DEVICE_PROP structure of current device */
/*  The purpose of this register is to speed up the execution */

USBH_Usr_cb_TypeDef USR_Host_cb =
{
  USBH_USR_Init,
  USBH_USR_DeInit,
  USBH_USR_DeviceAttached,
  USBH_USR_ResetDevice,
  USBH_USR_DeviceDisconnected,
  USBH_USR_OverCurrentDetected,
  USBH_USR_DeviceSpeedDetected,
  USBH_USR_Device_DescAvailable,
  USBH_USR_DeviceAddressAssigned,
  USBH_USR_Configuration_DescAvailable,
  USBH_USR_Manufacturer_String,
  USBH_USR_Product_String,
  USBH_USR_SerialNum_String,		
  USBH_USR_EnumerationDone,	                                // enumeration done report
  USBH_USR_UserInput,							            // just return Ok value				
  USBH_USR_MSC_Application,									// main working process
  USBH_USR_DeviceNotSupported,								// message for unsupported device
  USBH_USR_UnrecoveredError									// message for error
    
};


//  temporery console messages
 
const uint8_t MSG_HOST_INIT[]        = "> Host Library Initialized\n";
const uint8_t MSG_DEV_ATTACHED[]     = "> Device Attached \n";
const uint8_t MSG_DEV_DISCONNECTED[] = "> Device Disconnected\n";
const uint8_t MSG_DEV_ENUMERATED[]   = "> Enumeration completed \n";
const uint8_t MSG_DEV_HIGHSPEED[]    = "> High speed device detected\n";
const uint8_t MSG_DEV_FULLSPEED[]    = "> Full speed device detected\n";
const uint8_t MSG_DEV_LOWSPEED[]     = "> Low speed device detected\n";
const uint8_t MSG_DEV_ERROR[]        = "> Device fault \n";
const uint8_t MSG_DEV_OVERCURRENT[]	 = "> Overcurrent detected\n";

const uint8_t MSG_MSC_CLASS[]        = "> Mass storage device connected\n";
const uint8_t MSG_HID_CLASS[]        = "> HID device connected\n";
const uint8_t MSG_DISK_SIZE[]        = "> Size of the disk in MBytes: \n";
const uint8_t MSG_UNREC_ERROR[]      = "> UNRECOVERED ERROR STATE\n";

/*       USBH_USR_Private_FunctionPrototypes	*/

////////////////////////////////////////////////
//					DEVICE USER CALLBSCKS							//
////////////////////////////////////////////////

#define Log_Write(x) 

//----------------------------------------------
void USBH_USR_Init(void)	{
  static uint8_t startup = 0;  
  
    Log_Write((void*)MSG_HOST_INIT);

  if(startup == 0 )
  {
    startup = 1;
  }

  
}


//----------------------------------------------
void USBH_USR_DeviceAttached(void)	{
	Log_Write((void*)MSG_DEV_ATTACHED);

    Log_Write("Attached!!!"); 
}


//----------------------------------------------
void USBH_USR_UnrecoveredError (void)	{
	Log_Write((void*)MSG_UNREC_ERROR);
	// it just reports about error stare & continue execution 
}


//----------------------------------------------
void USBH_USR_DeviceDisconnected (void)	{
	Log_Write((void*)MSG_DEV_DISCONNECTED);
    flashDriveIsConnected = false;
    Menu_ChangeStateFlashDrive(FlashDriveIsConnected()); 

}


//----------------------------------------------
void USBH_USR_ResetDevice(void)	{
  Log_Write((void*)MSG_UNREC_ERROR);
}


//----------------------------------------------
void USBH_USR_DeviceSpeedDetected(uint8_t DeviceSpeed)	{
  if(DeviceSpeed == HPRT0_PRTSPD_HIGH_SPEED)
  {
    Log_Write((void *)MSG_DEV_HIGHSPEED);
		Log_Write("\n");
  }  
  else if(DeviceSpeed == HPRT0_PRTSPD_FULL_SPEED)
  {
    Log_Write((void *)MSG_DEV_FULLSPEED);
		Log_Write("\n");
  }
  else if(DeviceSpeed == HPRT0_PRTSPD_LOW_SPEED)
  {
    Log_Write((void *)MSG_DEV_LOWSPEED);
		Log_Write("\n");
  }
  else
  {
    Log_Write((void *)MSG_DEV_ERROR);
		Log_Write("\n");
  }
}


//----------------------------------------------
void USBH_USR_Device_DescAvailable(void *DeviceDesc)	{ 

}


//----------------------------------------------
void USBH_USR_DeviceAddressAssigned(void)	{

}

void ActivateFM() {
    Menu_ChangeStateFlashDrive(FlashDriveIsConnected());
    Timer_KillTimer(Timer_Temp);
}

//----------------------------------------------
void USBH_USR_Configuration_DescAvailable(USBH_CfgDesc_TypeDef * cfgDesc, 
																					USBH_InterfaceDesc_TypeDef *itfDesc,
																					USBH_EpDesc_TypeDef *epDesc)	{
																						
  USBH_InterfaceDesc_TypeDef *id;
  
  id = itfDesc;  
  
  if((*id).bInterfaceClass  == 0x08)
  {
		Log_Write((void *)MSG_MSC_CLASS);
  }
  else if((*id).bInterfaceClass  == 0x03)
  {
    Log_Write((void *)MSG_HID_CLASS);
  }    

  //flashDriveIsConnected = true;

    //Timer_SetTimer(Timer_Temp, 10000, ActivateFM);
}


//----------------------------------------------
void USBH_USR_Manufacturer_String(void *ManufacturerString)	{
  Log_Write("Manufacturer :\n");
  Log_Write((char *)ManufacturerString);
	Log_Write("\n");
}


//----------------------------------------------
void USBH_USR_Product_String(void *ProductString)	{
	Log_Write("Product :\n");
	Log_Write((char *)ProductString);
	Log_Write("\n");  
}


//----------------------------------------------
void USBH_USR_SerialNum_String(void *SerialNumString)	{
 Log_Write( "Serial Number : \n");
 Log_Write((char *)SerialNumString);
 Log_Write("\n");	
} 


//----------------------------------------------
void USBH_USR_EnumerationDone(void)	{
  
  Log_Write((void*)MSG_DEV_ENUMERATED);
	
	// automount start process
	Log_Write((void*)">> FS_MOUNT status sets automaticaly\n");	
	USBH_USR_AppState.state = FS_ST_MOUNT;
} 


//----------------------------------------------
void USBH_USR_DeviceNotSupported(void)	{
	Log_Write((void*)">> Device not supported \n");
}  


//----------------------------------------------
USBH_USR_Status USBH_USR_UserInput(void)	{
	
	//////////////////////////////////////////////////////////////////////
	// I think, it is need for realization of user input flow.					//
	// means - if it have user response - do smth; if not - do nothin		//
	// here be realized something like bisy flag												//
	//////////////////////////////////////////////////////////////////////
	
	// now - it is just waiting of button push;
	
//    USBH_USR_Status usbh_usr_status;
// //   
//    usbh_usr_status = USBH_USR_NO_RESP;  
// //   
// //   /*Key B3 is in polling mode to detect user action */
// //   if(STM_EVAL_PBGetState(Button_KEY) == RESET)
// 	if(HCD_IsDeviceConnected(&USB_HS_Host_Core))
//   {
// 		usbh_usr_status = USBH_USR_RESP_OK;
//   } 
  return USBH_USR_RESP_OK;	//usbh_usr_status;
}  


//----------------------------------------------
void USBH_USR_OverCurrentDetected (void)	{
	Log_Write((void*)MSG_DEV_OVERCURRENT);
}


//----------------------------------------------
void USBH_USR_DeInit(void)	{
	Log_Write((void*)MSG_DEV_DISCONNECTED);
}


////////////////////////////////////////////////
//					MSC APPLICATION CALLBACK					//
//						THE MOST IMPORTANT							//								
//					 DEVICE USER CALLBACK							//
////////////////////////////////////////////////


#ifdef USE_API_MECH
// little debug macro 
//#define FRESULT_GLOBAL_MESSAGE {fs_res_notificator(USBH_USR_AppState.res);}		
#define FRESULT_GLOBAL_MESSAGE

//	API-style version of function for work with USB flash drive
int USBH_USR_MSC_Application(void)	{	
	
	
	switch(USBH_USR_AppState.state)	{
		
		// stand by of free or nothing to do
		case FS_ST_NOPE:
		
			USBH_USR_AppState.state = FS_ST_NOPE;	
		break;	
		
		// mount volume
		case FS_ST_MOUNT:
			USBH_USR_AppState.res = fs_mount_processor(USBH_USR_AppState.wdpath);
			FRESULT_GLOBAL_MESSAGE;

            // WARN ����� ������� ������������ ���������.

			//if(FR_OK == USBH_USR_AppState.res) Log_Write("mounted_Ok\n");
			USBH_USR_AppState.state = FS_ST_NOPE;	

        flashDriveIsConnected = true;
        Menu_ChangeStateFlashDrive(FlashDriveIsConnected());
            
		break;
		
		// create file
		case FS_ST_CREATE_FILE:
			USBH_USR_AppState.res = fs_create_file_processor(USBH_USR_AppState.filename);
			FRESULT_GLOBAL_MESSAGE;
			USBH_USR_AppState.state = FS_ST_NOPE;	
		break;
		
		// create directory
		case FS_ST_CREATE_DIR:
			USBH_USR_AppState.res = fs_create_directory_processor(USBH_USR_AppState.filename);
			FRESULT_GLOBAL_MESSAGE;
			USBH_USR_AppState.state = FS_ST_NOPE;	
		break;	
		
		// write data array to file
		case FS_ST_WRITE_DATA:
			USBH_USR_AppState.res = fs_data_write_processor(USBH_USR_AppState.filename, 
                                                            USBH_USR_AppState.write_data_buffer, 
															USBH_USR_AppState.write_buffer_size, 
															USBH_USR_AppState.data_offset);
			FRESULT_GLOBAL_MESSAGE;
			USBH_USR_AppState.state = FS_ST_NOPE;	
		break;	
		
		// read data array from file
		case FS_ST_READ_DATA:
			USBH_USR_AppState.res = fs_data_write_processor(USBH_USR_AppState.filename, 
																											USBH_USR_AppState.read_data_buffer, 
																											USBH_USR_AppState.read_buffer_size, 
																											USBH_USR_AppState.data_offset);
			FRESULT_GLOBAL_MESSAGE;
			USBH_USR_AppState.state = FS_ST_NOPE;	
		break;	
		
		// set working directory
		case FS_ST_CHDIR:
			USBH_USR_AppState.res = fs_set_work_directory_processor(USBH_USR_AppState.wdpath);
			FRESULT_GLOBAL_MESSAGE;
			USBH_USR_AppState.state = FS_ST_NOPE;	
		break;	
		
		// remove filesystem item
		case FS_ST_REMOVE:
			USBH_USR_AppState.res = fs_remove_item_processor(USBH_USR_AppState.filename);
			FRESULT_GLOBAL_MESSAGE;
			USBH_USR_AppState.state = FS_ST_NOPE;	
		break;	
		
		// get number of items in working directory
		case FS_ST_GET_ITEMS_NUM:
			USBH_USR_AppState.res = fs_get_directory_items_num_processor(USBH_USR_AppState.wdpath, 
											    						 &USBH_USR_AppState.items_num);
			FRESULT_GLOBAL_MESSAGE;
			USBH_USR_AppState.state = FS_ST_NOPE;	
		break;	
		
		// get item by num from working directory
		case FS_ST_GET_ITEM:
			USBH_USR_AppState.res = fs_get_directory_item_data_processor(USBH_USR_AppState.wdpath, 
																		 USBH_USR_AppState.need_item, 
												    					 &USBH_USR_AppState.fileinfo);
			FRESULT_GLOBAL_MESSAGE;
			USBH_USR_AppState.state = FS_ST_NOPE;	
		break;	
		
		// get working directory path
		case FS_ST_GET_PATH:
			USBH_USR_AppState.res = fs_get_working_directory_processor(USBH_USR_AppState.wdpath,
																        WD_PATH_LENTH);
			FRESULT_GLOBAL_MESSAGE;
			USBH_USR_AppState.state = FS_ST_NOPE;	
		break;
		
		// unmount volume
		case FS_ST_UNMOUNT:
			USBH_USR_AppState.res = fs_unmount_processor();
			FRESULT_GLOBAL_MESSAGE;
			USBH_USR_AppState.state = FS_ST_NOPE;	
		break;	
		
		// get free space on volume
		case FS_ST_GET_FREE:
			USBH_USR_AppState.res = fs_get_free_spase_processor(&USBH_USR_AppState.free_space);
			FRESULT_GLOBAL_MESSAGE;
			USBH_USR_AppState.state = FS_ST_NOPE;	
		break;	
		
		// DEFAULT
		default:
			// TODO - put here macro for processing illegal state, make it defined in config 
			if(FS_ST_NOPE != USBH_USR_AppState.state) Log_Write(">>>  no callback for this state \n");
			USBH_USR_AppState.state = FS_ST_NOPE;
		break;
		
		
	}


	return 0;
}
#endif		// USE_API_MECH

////////////////////////////////////////////////
//				MSC API FOR WORK WITH SEVER-C				//
//						EXPORTED FUNCTIONS							//
////////////////////////////////////////////////

void ProcessingRequest(FS_Application_Status_Typedef state) {
    /*
    while(FS_ST_NOPE != USBH_USR_AppState.state && USB_Host.gState != HOST_IDLE) {
        USBH_Process(&USB_HS_Host_Core, &USB_Host);
    }
    */

    USBH_USR_AppState.state = state;

    while(FS_ST_NOPE != USBH_USR_AppState.state && USB_Host.gState != HOST_IDLE && FlashDriveIsConnected()) {
        USBH_Process(&USB_HS_Host_Core, &USB_Host);
    }
}

//----------------------------------------------
void uffs_dcreate(char * dirname)	{
	uint32_t i;	
			
	for(i=0; i<SFN_LENTH; i++)	USBH_USR_AppState.filename[i] = dirname[i];

    ProcessingRequest(FS_ST_CREATE_DIR);
}

bool FlashDriveIsConnected() {
    //return HCD_IsDeviceConnected(&USB_HS_Host_Core);
    return flashDriveIsConnected;
}

bool FS_GetNameCurrentDir(TCHAR buffer[50], int sizeBuffer) {
    if(f_getcwd(buffer, sizeBuffer) == FR_OK) {
        return true;
    } else {
        LOG_ERROR("�� ���� �������� ������� �������");
    }
    return false;
}

int FS_GetNumItemsInDir(TCHAR *path) {
        FILINFO fno;
        DIR dir;

        int numItems = 0;

        if(f_opendir(&dir, path) != FR_OK) {
            LOG_ERROR("�� ���� ������� ������� ��� %s", path);
        }

        while(true)	{

            if(f_readdir(&dir, &fno) != FR_OK) {
                LOG_ERROR("�� ���� ������� �������");
            }

            if (fno.fname[0] == 0)	{
                break;
            }
            if (fno.fname[0] != '.')	{
                numItems++;
            }
        }

        if(f_closedir(&dir) != FR_OK) {
            LOG_ERROR("�� ���� ������� �������");
        }

        return numItems;
}

static FIL currentFP;
#if _USE_LFN > 0
bool OpenFile(TCHAR *fileName) {
#else
bool OpenFile(char *fileName) {
#endif
    FRESULT res = FR_OK;
    if(FR_OK == f_open(&currentFP, fileName, FA_READ)) {
        f_unlink(fileName);
    }
    res = f_open(&currentFP, fileName, FA_CREATE_NEW | FA_WRITE);
    if(res != FR_OK) {
        LOG_ERROR("�� ���� ������� ����. ������ %d", (int)res);
        return false;
    }
    return true;
}

bool WriteToFile(uint8 *buffer, int sizeBuffer) {
    uint numBytes;

    if(FR_OK != f_write(&currentFP, buffer, sizeBuffer, &numBytes)) {
        LOG_ERROR("�� ���� �������� � ����");
        return false;
    }

    return true;
}

bool CloseLastFile() {
    if(FR_OK != f_close(&currentFP)) {
        LOG_ERROR("�� ���� ������� ����");
        return false;
    }
    return true;
}


//----------------------------------------------
void uffs_read(char* filename, char * read_buff, uint32_t buff_size, uint32_t offset)	{
	uint32_t i;
	
	USBH_USR_AppState.read_data_buffer = (uint8_t*)read_buff;
	USBH_USR_AppState.read_buffer_size = buff_size;
	USBH_USR_AppState.data_offset = offset;
	
	for(i=0; i<SFN_LENTH; i++)	USBH_USR_AppState.filename[i] = filename[i];

    ProcessingRequest(FS_ST_READ_DATA);
}


//----------------------------------------------
void uffs_remove(char * name)	{
	uint32_t i;
	
	for(i=0; i<SFN_LENTH; i++)	USBH_USR_AppState.filename[i] = name[i];
	
    ProcessingRequest(FS_ST_REMOVE);
}


//----------------------------------------------
void uffs_chdir(char * path)	{
	uint32_t i;
	
	for(i=0; i<WD_PATH_LENTH; i++)	USBH_USR_AppState.wdpath[i] = path[i];
	
    ProcessingRequest(FS_ST_CHDIR);
}


//----------------------------------------------
uint32_t uffs_get_items_num(void)	{
	
    ProcessingRequest(FS_ST_GET_ITEMS_NUM);

    return USBH_USR_AppState.items_num;
}

//----------------------------------------------
FILINFO* uffs_get_item(uint32_t seek_num)	{
	
	USBH_USR_AppState.need_item = seek_num;
		
    ProcessingRequest(FS_ST_GET_ITEM);

    return &USBH_USR_AppState.fileinfo;
}





////////////////////////////////////////////////
//				MSC API FOR WORK WITH SEVER-C				//
//					INTERNAL PROCESSORS								//
////////////////////////////////////////////////
//----------------------------------------------
#if _LFN_UNICODE
uint8_t fs_create_file_processor(TCHAR * path)	{
#else
uint8_t fs_create_file_processor(char * path)	{
#endif
	FIL fp; 
	uint8_t res;
	
	res = f_open(&fp, path, (FA_CREATE_NEW));
	f_close(&fp);
	
	return res;
	
}


//----------------------------------------------
#if _LFN_UNICODE
uint8_t fs_data_write_processor(TCHAR * path, uint8_t * data, uint32_t data_lenth, uint32_t data_offset)	{
#else
uint8_t fs_data_write_processor(char * path, uint8_t * data, uint32_t data_lenth, uint32_t data_offset)	{
#endif
	FIL fp; 
	uint8_t res;
	uint32_t bytes_write;
	
	res = f_open(&fp, path, (FA_OPEN_EXISTING | FA_WRITE));
	
	if(data_offset)	res = f_lseek(&fp, data_offset);
	
	for(;;)	{
		res = f_write(&fp, data, data_lenth, &bytes_write);
		if((res)||(bytes_write <= data_lenth))	break;		
	}
	
	f_close(&fp);

	return res;
	
}


//----------------------------------------------
#if _LFN_UNICODE
uint8_t fs_data_read_processor(TCHAR * path, uint8_t * data, uint32_t data_lenth, uint32_t data_offset)	{
#else
uint8_t fs_data_read_processor(char * path, uint8_t * data, uint32_t data_lenth, uint32_t data_offset)	{
#endif
	FIL fp; 
	uint8_t res;
	uint32_t bytes_read;
	
	if(data_offset)	res = f_lseek(&fp, data_offset);
	
	for(;;)	{
		res = f_read(&fp, data, data_lenth, &bytes_read);
		if((res)||(0 == bytes_read))	break;
	}
	
	f_close(&fp);
	
	return res;
	
}


//----------------------------------------------
#if _LFN_UNICODE
uint8_t fs_set_work_directory_processor(TCHAR * path)	{
#else
uint8_t fs_set_work_directory_processor(char * path)	{
#endif
	FRESULT res;
	// TODO: also set value to global state if ok
	res =  f_chdir(path);
	res = f_getcwd(path, WD_PATH_LENTH);
	
	return res;
	
}


//----------------------------------------------
#if _LFN_UNICODE
uint8_t fs_remove_item_processor(TCHAR * path)	{
#else
uint8_t fs_remove_item_processor(char * path)	{
#endif
	// work only with single file or empty directory
	// TODO - add detection of non-emptyfolder & handle this situation
	return f_unlink(path);
	
}


//----------------------------------------------
#if _LFN_UNICODE
uint8_t fs_get_directory_items_num_processor(TCHAR * path, uint32_t * items_num)	{
#else
uint8_t fs_get_directory_items_num_processor(char * path, uint32_t * items_num)	{
#endif
	
    FRESULT res;
    FILINFO fno;
    DIR dir;
	
	
	*items_num = 0;
		
	res = f_opendir(&dir, path);
	
	while(HCD_IsDeviceConnected(&USB_HS_Host_Core))	{
		
		res = f_readdir(&dir, &fno);
		
		if (res != FR_OK || fno.fname[0] == 0)	{
			break;
		}
		if (fno.fname[0] == '.')	{
			continue;
		}
			
		(*items_num)++;
	}
	
	f_closedir(&dir);
	
	return res;
};


//----------------------------------------------
#if _LFN_UNICODE
uint8_t fs_get_directory_item_data_processor(TCHAR * path, uint32_t item_num, FILINFO * fno)	{
#else
uint8_t fs_get_directory_item_data_processor(char * path, uint32_t item_num, FILINFO * fno)	{
#endif
	
	FRESULT res;
  
  static DIR dir;
	uint32_t i;
	
	res = f_opendir(&dir, path);
		
	for(i=0; i < item_num; i++)	{
		
		res = f_readdir(&dir, fno);
		
		if (res != FR_OK || fno->fname[0] == 0)	{
			break;
		}
		if (fno->fname[0] == '.')	{
			continue;
		}
	
	}
	
	f_closedir(&dir);
	
	return res;
}

static int currentItem = 0;
static int numItems = 0;
static DIR dir;

void FS_SetFirstItem() {
    currentItem = 0;

    char curDir[50];
    
    f_getcwd(curDir, 50);
    FS_GetNumItemsInDir(curDir);

    f_getcwd(curDir, 50);
    f_opendir(&dir, curDir);
}

bool FS_GetInfoAboutNextItem(char name[20], uint8 *attrib) {
    /*
    if(currentItem < numItems) {
        f_readdir()
    }
    */
    return false;
}

//----------------------------------------------
#if _LFN_UNICODE
uint8_t fs_create_directory_processor(TCHAR * dir_name)	{
#else
uint8_t fs_create_directory_processor(char * dir_name)	{
#endif

	return f_mkdir(dir_name);
}


//----------------------------------------------
#if _LFN_UNICODE
uint8_t fs_get_working_directory_processor(TCHAR* dir_name, uint16_t path_lenth)	{
#else
uint8_t fs_get_working_directory_processor(char* dir_name, uint16_t path_lenth)	{
#endif

	return f_getcwd(USBH_USR_AppState.wdpath, path_lenth); // may be path lentz should be a macro
}


//----------------------------------------------
#if _LFN_UNICODE
uint8_t fs_mount_processor(TCHAR * rootpath)	{
#else
uint8_t fs_mount_processor(char * rootpath)	{
#endif
	FRESULT res;
		
	res = f_mount(&fatfs, (TCHAR*)"0", 1);

	res = f_getcwd(rootpath, WD_PATH_LENTH);
	
	return res;

}


//----------------------------------------------
uint8_t fs_unmount_processor(void)	{
	
    FRESULT res = f_mount(NULL, (TCHAR*)"0", 1);

	return res;
}


//----------------------------------------------
// may be it useles in near time
uint8_t fs_get_free_spase_processor(uint32_t * freespace)	{
	
	FRESULT res;
	// will be realized later
	//res = f_getfree( "/0", freespace, fatfs);
	
	return res;
}


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

