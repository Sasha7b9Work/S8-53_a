/// @file

#pragma once   
#include "defines.h"

#define LOG_ERROR(...) Log_Error(__MODULE__, __FUNCTION__, __LINE__, __VA_ARGS__)

void Log_Error(const char *module, const char *func, int numLine, char *format, ...);
void Log_Write(char *format, ...);
void Log_DisconnectLoggerUSB(void);
void Log_EnableLoggerUSB(bool);

