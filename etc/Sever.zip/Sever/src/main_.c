/**
  ******************************************************************************
  * @file    DAC/DAC_SignalsGeneration/main.c 
  * @author  MCD Application Team
  * @version V1.1.0
  * @date    13-April-2012
  * @brief   Main program body.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2012 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/
#include "stm32f2xx.h"
#include "stm32f2xx_dac.h"
#include "stm32f2xx_dma.h"

#include <math.h>

/** @addtogroup STM32F2xx_StdPeriph_Examples
  * @{
  */

/** @addtogroup DAC_SignalsGeneration
  * @{
  */ 

#define SYSTEMTICK_PERIOD_MS  10
unsigned int LocalTime = 0; /* this variable is used to create a time reference incremented by 10ms */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define DAC_DHR12R2_ADDRESS 0x40007408
#define DAC_DHR8R1_ADDRESS  0x40007410
#define SAMPLING_FREQ       10000

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
DAC_InitTypeDef  DAC_InitStructure;

const uint16_t Sine12bit[32] = { 
                      2047, 2447, 2831, 3185, 3498, 3750, 3939, 4056, 4095, 4056,
                      3939, 3750, 3495, 3185, 2831, 2447, 2047, 1647, 1263, 909, 
                      599, 344, 155, 38, 0, 38, 155, 344, 599, 909, 1263, 1647};
const uint8_t Escalator8bit[6] = {0x0, 0x33, 0x66, 0x99, 0xCC, 0xFF};

__IO uint8_t SelectedWavesForm = 1;
__IO uint8_t KeyPressed = SET; 

/* Private function prototypes -----------------------------------------------*/
void TIM6_Config(void);
void TIM7_Config(void);
void DAC_Config();
void DAC_Ch1_EscalatorConfig(void);
void DAC_Ch2_SineWaveConfig(void);

void DAC_Ch1_NoiseConfig(void);
void DAC_Ch2_TriangleConfig(void);

/* Private functions ---------------------------------------------------------*/

/**
  * @brief   Main program
  * @param  None
  * @retval None
  */


int main(void)
{
  TIM7_Config();
  DAC_Config();

  while (1)
  {
  }
}

void DAC_Config() {
   RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);
   DAC_Cmd(DAC_Channel_1, ENABLE);
}

void TIM7_Config() {

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7, ENABLE);

 
    TIM_TimeBaseInitTypeDef isTIM7 = {
        119,
        TIM_CounterMode_Up,
        100,
        TIM_CKD_DIV1
    };

    TIM_TimeBaseInit(TIM7, &isTIM7);
    TIM_Cmd(TIM7, ENABLE);
    TIM_ITConfig(TIM7, TIM_IT_Update, ENABLE);

    NVIC_EnableIRQ(TIM7_IRQn);
}

void TIM7_IRQHandler(void) {

//    if(TIM_GetFlagStatus(TIM7, TIM_FLAG_Update) && TIM_GetITStatus(TIM7, TIM_IT_Update)) {
        static int counter = 0;
        //DAC_SetChannel1Data(DAC_Align_12b_R, Sine12bit[counter++]);
        //counter &= 31;
        TIM_ClearITPendingBit(TIM7, TIM_IT_Update);
        static float time = 0.0f;
        static float freq = 100.0f;
        DAC_SetChannel1Data(DAC_Align_12b_R, 255 * (sin(2 * 3.1415296f * freq * time) + 1.0f));
        time += 2e-4;
//        TIM_ClearFlag(TIM7, TIM_FLAG_Update);
        
//    }

}

#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/**
  * @}
  */ 

/**
  * @}
  */ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/


void Time_Update(void) {
    LocalTime += SYSTEMTICK_PERIOD_MS;
}


unsigned int sys_now() {
    return LocalTime;
}
