/// @file

#include "Pool.h"
#include "defines.h"

uint8* gBufferForDisplay;
