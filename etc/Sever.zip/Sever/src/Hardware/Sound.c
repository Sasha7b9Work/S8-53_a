#include "defines.h"

#include "Sound.h"
#include "../Timer.h"
#include "../Math/Math.h"
#include "../Log.h"
#include "../Settings/Settings.h"
#include <stm32f2xx_tim.h>
#include <stm32f2xx_dac.h>
#include <stm32f2xx_gpio.h>
#include <stm32f2xx_dma.h>
#include <stm32f2xx.h>

#include <math.h>

static void StopTheSound(void);
static void TIM7_Config(uint16 prescaler, uint16 period);
static void DMA_Config(void);
static void DAC_Config(void);
static void CalculatePrescalerAndPeriod(float frequency, float *timeBetweenPoints, uint16 *prescalerForTIM, uint16 *periodForTIM);
static float CalculateSine(float frequency, float amplitude, float phase, float time);
static float CalculateTriangle(float frequency, float amplitude, float phase, float durationFront, float time);
static float CalculateRectangle(float frequency, float amplitude, float phase, float durationFront, float time);
//static float DegreeInRadians(float degrees);

static Sound sound;
static bool nowSounds = false;

static const int POINTS_IN_PERIOD = 1000;
static uint8 poinst[POINTS_IN_PERIOD];
//static int numPoints = 0;

void Sound_Set(Sound *eSound) {

    if(SoundEquals(eSound, &sound)) {
        return;
    }

    sound = *eSound;
    float freqSine = sound.sine.frequency;
    float freqTriangle = sound.triangle.frequency;
    float freqRectangle = sound.rectangle.frequency;

    float frequency = Math_MinFrom3float(freqSine, freqTriangle, freqRectangle);

    uint16 prescaler = 0;
    uint16 period = 0;
    float dTime = 0.0f;

    CalculatePrescalerAndPeriod(frequency, &dTime, &prescaler, &period);

    float time = 0.0f;

    for(int i = 0; i < POINTS_IN_PERIOD; i++) {
        float amplSine = CalculateSine(freqSine, sound.sine.amplitude, sound.sine.phaseDegrees, time);
        float amplTriangle = CalculateTriangle(freqTriangle, sound.triangle.amplitude, sound.triangle.phaseDegrees, sound.triangle.durationFront, time);
        float amplRectangle = CalculateRectangle(freqRectangle, sound.rectangle.amplitude, sound.rectangle.phaseDegrees, sound.rectangle.durationFront, time);
        
        float amplitude = amplSine + amplTriangle + amplRectangle;
        int amplRel = amplitude * 128 + 128;
        amplRel = LimitationInt(amplRel, 0, 255) * sound.amplitude;
        poinst[i] = (uint8)amplRel;
        time += dTime;
    }

    TIM7_Config(prescaler, period);
    DAC_Config();
    DMA_Config();
}

void Sound_Beep(void) {
    DMA_Cmd(DMA1_Stream5, ENABLE);
    DAC_Cmd(DAC_Channel_1, ENABLE);
    DAC_DMACmd(DAC_Channel_1, ENABLE);
    TIM_Cmd(TIM7, ENABLE);

    Timer_SetTimer(Timer_StopSound, sound.duration * 1000, StopTheSound);
    nowSounds = true;
}

void StopTheSound() {
    Timer_KillTimer(Timer_StopSound);
    DMA_Cmd(DMA1_Stream5, DISABLE);
    DAC_Cmd(DAC_Channel_1, DISABLE);
    DAC_DMACmd(DAC_Channel_1, DISABLE);
    TIM_Cmd(TIM7, DISABLE);
    nowSounds = false;
}

void TIM7_Config(uint16 prescaler, uint16 period) {

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7, ENABLE);

    TIM_TimeBaseInitTypeDef isTIM7 = {
        prescaler,
        TIM_CounterMode_Up,
        period,
        TIM_CKD_DIV1,
        0
    };

    TIM_TimeBaseInit(TIM7, &isTIM7);
    TIM_SelectOutputTrigger(TIM7, TIM_TRGOSource_Update);
}

void DMA_Config() {
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1, ENABLE);

    static const uint DAC_DHR8R1_ADDRESS = 0x40007410;

    DMA_DeInit(DMA1_Stream5);

    DMA_InitTypeDef isDMA = {
        DMA_Channel_7,                  // DMA_Channel
        DAC_DHR8R1_ADDRESS,             // DMA_PeripheralBaseAddr
        (uint)poinst,                   // DMA_Memory0BaseAddr
        DMA_DIR_MemoryToPeripheral,     // DMA_Dir
        POINTS_IN_PERIOD,               // DMA_BufferSize
        DMA_PeripheralInc_Disable,      // DMA_PeripheralInc
        DMA_MemoryInc_Enable,           // DMA_MemoryInc
        DMA_PeripheralDataSize_Byte,    // DMA_PeripheralDataSize
        DMA_MemoryDataSize_Byte,        // DMA_MemoryDataSize
        DMA_Mode_Circular,              // DMA_Mode
        DMA_Priority_High,              // DMA_Priority
        DMA_FIFOMode_Disable,           // DMA_FIFOMode
        DMA_FIFOThreshold_HalfFull,     // DMA_FIFOThreshold
        DMA_MemoryBurst_Single,         // DMA_MemoryBurst
        DMA_PeripheralBurst_Single      // DMA_PeripheralBurst
    };

    DMA_Init(DMA1_Stream5, &isDMA);
}

void DAC_Config() {

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

    GPIO_InitTypeDef isGPIO;

    isGPIO.GPIO_Pin = GPIO_Pin_4;
    isGPIO.GPIO_Mode = GPIO_Mode_AN;
    isGPIO.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOA, &isGPIO);

    DAC_DeInit();

    DAC_InitTypeDef isDAC = {
        DAC_Trigger_T7_TRGO,
        DAC_WaveGeneration_None,
        0,
        DAC_OutputBuffer_Enable
    };

    DAC_Init(DAC_Channel_1, &isDAC);
}

void CalculatePrescalerAndPeriod(float frequency, float *timeBetweenPoints, uint16 *prescalerForTIM, uint16 *periodForTIM) {
    *prescalerForTIM = 0;
    uint16 per = 120e6 / frequency / POINTS_IN_PERIOD;
    *periodForTIM = per;
    *timeBetweenPoints = per * 1.0f / 120e6;
}
 
float CalculateSine(float frequency, float amplitude, float phase, float time) {
    return amplitude * sin(2.0f * 3.14159265358979323846f * frequency * time + 2.0f * 3.14159265358979323846f * phase);
}

float CalculateTriangle(float frequency, float amplitude, float phase, float durationFrontRel, float time) {
    float period = 1.0f / frequency;
    float front = period * durationFrontRel;
    time += period / 360.0f * phase;
    if(time <= front) {
        return time * 2.0f * amplitude / front - amplitude;
    }
    time -= front;
    return amplitude - time * 2.0f * amplitude / front;
}

float CalculateRectangle(float frequency, float amplitude, float phase, float durationFrontRel, float time) {
    float period = 1.0f / frequency;
    float front = period * durationFrontRel;
    time += period / 360.0f * phase;
    return time <= front ? amplitude : -amplitude;
}

/*
float DegreeInRadians(float degrees) {
    return degrees * 3.14159265358979323846f / 180.0f;
}
*/
