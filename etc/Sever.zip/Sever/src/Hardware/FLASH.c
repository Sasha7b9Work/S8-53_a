/// @file

#include "FLASH.h"
#include "HAL.h"
#include "Settings/Settings.h"
#include "Timer.h"
#include "../Math/GlobalFunctions.h"
#include "../Log.h"

typedef struct {
    uint address;       // ���� ��� ������ ����� ���������� ����� ��� ������.
    int sizeInBytes;    // ������ � ������
    uint crc;           // ����������� �����. ����������� ��������� ��������� ���� ����. ��� ������ ��� �������� ����� - �� 0 �� 16.
} RecordConfig;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const uint SIZE_SECTOR_SETTINGS = 128 * 1024;
static const uint ADDR_ARRAY_POINTERS = ADDR_SECTOR_SETTINGS + 4;
static const uint SIZE_ARRAY_POINTERS_IN_ELEMENTS = 1024;
static const uint SIZE_ARRAY_POINTERS_IN_BYTES = SIZE_ARRAY_POINTERS_IN_ELEMENTS * sizeof(RecordConfig);
static const uint ADDR_FIRST_CONFIG = ADDR_ARRAY_POINTERS + SIZE_ARRAY_POINTERS_IN_BYTES;

// ������� ����, ��� ������ � ���� ������� ���� ��� �������������. ���� ������� ����� ������� (������, �������� ��� ��������) ����� ��� ��������, ������ ��� ���� ����������� ��� ������� ���� ���
static const uint MARK_OF_FILLED = 0xaaaaaaaa;
static const uint MAX_UINT = 0xffffffff;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
uint addressesOfGrids[TG_Size];

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool            ResourcesOfExits(void);
uint            ReadWord(uint _address);
bool            TheFirstInclusion(void);
void            EraseSector(uint _startAddress);
void            WriteWord(uint _address ,uint _word);
RecordConfig*   FindRecordConfigForWrite(void);
RecordConfig*   FindRecordConfigForRead(void);
void            WriteBufferWord(uint _address, uint *_buffer, int _size);
void            ReadBufferWord(uint _address, uint *_buffer, int _size);
int             SizeConfig(uint _addressRecord);
uint            CalculateCRC(void);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void FLASH_Init() {
    for(int i = 0; i < TG_Size; i++) {
        addressesOfGrids[i] = 4 + i * SIZE_BUFFER_FOR_SCREEN;
    }

    if(!ResourcesOfExits()) {
        EraseSector(ADDR_SECTOR_RESOURCES_0);
        WriteWord(ADDR_SECTOR_RESOURCES_0, MARK_OF_FILLED);
    }
}

bool FLASH_LoadSettings() {
    bool retValue = false;
    if(!TheFirstInclusion()) {
        RecordConfig *pRecordForRead = FindRecordConfigForRead();
        //int size = pRecordForRead->sizeInBytes;
        //int cantWrite = (ADDR_FIRST_CONFIG - (uint)pRecordForRead) / sizeof(RecordConfig);
        //Log_Write("������ %d. �������� ����� ��� %d", size, cantWrite);
        if(Settings_Size() == pRecordForRead->sizeInBytes) {
            ReadBufferWord(pRecordForRead->address, (uint*)(Settings_Pointer()), pRecordForRead->sizeInBytes / 4);
            /*
            Log_Write("����� ����� ������ %d ����, %d �����, %d �����, %d ������",    set.common.workingTimeInSecs / (3600 * 24), 
                                                                                    set.common.workingTimeInSecs % (3600 * 24) / 3600,
                                                                                    (set.common.workingTimeInSecs % 3600) / 60,
                                                                                    set.common.workingTimeInSecs % 60);
                                                                                    */
            retValue = true;
            /*
            if(CalculateCRC() == pRecordForRead->crc) {
                Log_WriteMessage("����������� ����� �������, ��������� ���������");
                retValue = true;
            } else {
                Log_WriteError("����������� ����� �� ���������");
            }
            */
        }
    } 
    else {
        Log_Write("������ ���������");
    }
    IncCommonCountEnables();
    return retValue;
}

void FLASH_SaveSettings() {
    if(TheFirstInclusion()) {
        CommonCountErasedFlashSettings();
        SetCommonCountEnables(0);
        SetCommonCountErasedFlashData(0);
        SetCommonWorkingTimeInSecs(0);
        EraseSector(ADDR_SECTOR_SETTINGS);
        WriteWord(ADDR_SECTOR_SETTINGS, MARK_OF_FILLED);        
    }
    volatile RecordConfig *pRecordConfig = FindRecordConfigForWrite();
    Log_Write("������������ ���������, ������ %d", sizeof(Settings));
    if(pRecordConfig == 0) {
        CommonCountErasedFlashSettingsInc();
        EraseSector(ADDR_SECTOR_SETTINGS);
        WriteWord(ADDR_SECTOR_SETTINGS, MARK_OF_FILLED);
        pRecordConfig = (RecordConfig *)ADDR_ARRAY_POINTERS;
    }

    AddCommonWorkingTimeInSecs(Timer_GetMS() / 1000);

    if((uint)pRecordConfig == ADDR_ARRAY_POINTERS) {
        WriteWord((uint)(&pRecordConfig->address), ADDR_FIRST_CONFIG);
    } else {
        WriteWord((uint)(&pRecordConfig->address), (pRecordConfig - 1)->address + (pRecordConfig - 1)->sizeInBytes);
    }

    WriteWord((uint)(&pRecordConfig->sizeInBytes), Settings_Size());

    WriteWord((uint)(&pRecordConfig->crc), CalculateCRC());


    WriteBufferWord(pRecordConfig->address, (uint*)Settings_Pointer(), pRecordConfig->sizeInBytes / 4);
    ReadBufferWord(pRecordConfig->address, (uint*)Settings_Pointer(), pRecordConfig->sizeInBytes / 4);
}

uint FLASH_FirstByteGrids() {
    return ADDR_SECTOR_RESOURCES_0 + 4;
}

void FLASH_SaveGrid(TypeGrid type, uint8 data[SIZE_BUFFER_FOR_SCREEN]) {
    WriteBufferWord(ADDR_SECTOR_RESOURCES_0 + 4 + type * SIZE_BUFFER_FOR_SCREEN, (uint*)data, SIZE_BUFFER_FOR_SCREEN / 4);
};

bool FLASH_GridsInResources() {
    return ResourcesOfExits();
}

bool ResourcesOfExits() {
    return ReadWord(ADDR_SECTOR_RESOURCES_0) == MARK_OF_FILLED;
};

uint ReadWord(uint address) {
    return(*((volatile uint*)address));
}

bool TheFirstInclusion() {
    return ReadWord(ADDR_SECTOR_SETTINGS) != MARK_OF_FILLED;
}

void EraseSector(uint startAddress) {
    HAL_FLASH_EraseSector(startAddress);
}

void WriteWord(uint address ,uint word) {
    HAL_FLASH_WriteWord(address, word);
}

RecordConfig* FindRecordConfigForRead() {
    RecordConfig *retValue = 0;
    if(ReadWord(ADDR_SECTOR_SETTINGS == MARK_OF_FILLED)) {
        if(ReadWord(ADDR_ARRAY_POINTERS) != MAX_UINT) {
            retValue = (RecordConfig*)ADDR_ARRAY_POINTERS;
            while(retValue->address != MAX_UINT) {
                retValue++;
            }
            retValue--;
        }
    }
    return retValue;
}

uint CalculatFreeMemory() {
    RecordConfig *recConf = (RecordConfig*)ADDR_ARRAY_POINTERS;
    if(ReadWord(ADDR_ARRAY_POINTERS) == MAX_UINT) {
        return ADDR_SECTOR_SETTINGS - ADDR_FIRST_CONFIG - 4;
    }
    while(recConf->address != MAX_UINT) {
        recConf++;
    }
    uint freeMemory = ADDR_SECTOR_SETTINGS + SIZE_SECTOR_SETTINGS - (recConf - 1)->address - (recConf - 1)->sizeInBytes - 4;
    return freeMemory;
}

RecordConfig* FindRecordConfigForWrite() {

    RecordConfig *retValue = (RecordConfig*)ADDR_ARRAY_POINTERS;
    if(ReadWord(ADDR_ARRAY_POINTERS) == MAX_UINT) {
        Log_Write("��� �� ����� ������");
    } else {
        while(retValue->address != MAX_UINT) {
            retValue++;
        }

        int freeMemory = ADDR_SECTOR_SETTINGS + SIZE_SECTOR_SETTINGS - (retValue - 1)->address - (retValue - 1)->sizeInBytes - 4;
        if(freeMemory < Settings_Size()) {
            retValue = 0;
        }
    }

    return retValue;
}

RecordConfig* FindRecordConfigForWriteData(DataSettings *ds) {
    if(*((uint*)ADDR_FLASH_SECTOR_6) != MARK_OF_FILLED) {
        return 0;
    }
    int requiredMemory = sizeof(RecordConfig) + sizeof(DataSettings);
    if(ds->enable[0]) {
        requiredMemory += ds->length1channel;
    }
    if(ds->enable[1]) {
        requiredMemory += ds->length1channel;
    }
    uint address = ADDR_FLASH_SECTOR_6 + 4;
    while(*((uint*)address)) {
        address = ((RecordConfig*)address)->address;
    }

    if(ADDR_FLASH_SECTOR_6 + 128 * 1024 - address < requiredMemory) {
        return 0;
    }
    return (RecordConfig*)address;
}

void WriteBufferWord(uint address, uint *buffer, int size) {
    HAL_FLASH_WriteBufferWord(address, buffer, size);
}

void ReadBufferWord(uint address, uint *buffer, int size) {
    for(int i = 0; i < size; i++) {
        buffer[i] = *((uint*)address);
        address += 4;
    }
}

uint CalculateCRC() {
    uint retValue = 0;
    uint8 *pointer = (uint8*)Settings_Pointer();
    for(int i = 0; i < Settings_Size(); i++) {
        retValue += pointer[i];
    }
    return retValue;
}



void FLASH_GetDataInfo(bool existData[MAX_NUM_SAVED_WAVES]) {
    for(int i = 0; i < MAX_NUM_SAVED_WAVES; i++) {
        existData[i] = FLASH_GetData(i, 0, 0, 0);
    }
}

int CalculateSizeRecordConfig() {
    int size = sizeof(RecordConfig);
    while(size % 4) {
        size++;
    }
    return size;
}

int CalculateSizeDataSettings() {
    int size = sizeof(DataSettings);
    while(size % 4) {
        size++;
    }
    return size;
}

int CalculateSizeData(DataSettings *ds, Channel chan) {
    int size = 0;
    if(ds->enable[chan]) {
        size = ds->length1channel;
    }
    while(size % 4) {
        size++;
    }
    return size;
}

bool FLASH_GetData(int num, DataSettings **ds, uint8 **data0, uint8 **data1) {
    uint address = ADDR_FLASH_SECTOR_6;
    if(data0) {
        *data0 = 0;
    }
    if(data1) {
        *data1 = 0;
    }

    if(*((uint*)ADDR_FLASH_SECTOR_6) != MARK_OF_FILLED) {
        return false;
    }

    address = ADDR_FLASH_SECTOR_6 + 4;
    while(*((uint*)address)) {
        RecordConfig *rc = (RecordConfig*)address;
        if(rc->crc == num) {
            if(ds) {
                int sizeRecordConfig = CalculateSizeRecordConfig();
                *ds = (DataSettings*)(address + sizeRecordConfig);
                int sizeData0 = CalculateSizeData(*ds, Chan0);
                address += sizeRecordConfig + CalculateSizeDataSettings();
                if(sizeData0) {
                    *data0 = (uint8*)address;
                    address += CalculateSizeData(*ds, Chan0);
                }
                if(CalculateSizeData(*ds, Chan1)) {
                    *data1 = (uint8*)address;
                }
            } else {
                return true;
            }
        }
    }

    return data0 || data1;
}

void FLASH_SaveData(int num, DataSettings *ds, uint8 *data0, uint8 *data1) {
    // ��������� ������ ����� � ������� 6

    RecordConfig *address = FindRecordConfigForWriteData(ds);
    if(!address) {
        EraseSector(ADDR_FLASH_SECTOR_6);
        WriteWord(ADDR_FLASH_SECTOR_6, MARK_OF_FILLED);
        address = (RecordConfig*)ADDR_FLASH_SECTOR_6;
        address += 4;
    }

    int sizeRecordConfig = CalculateSizeRecordConfig();
    int sizeDataSettings = CalculateSizeDataSettings();
    int sizeData0 = CalculateSizeData(ds, Chan0);
    int sizeData1 = CalculateSizeData(ds, Chan1);
    
    RecordConfig config = {
        (uint)address + sizeRecordConfig + sizeDataSettings + sizeData0 + sizeData1,
        0,
        num
    };

    WriteBufferWord((uint)address, (uint*)&config, sizeRecordConfig / 4);
    address += sizeRecordConfig;
    WriteBufferWord((uint)address, (uint*)ds, sizeDataSettings / 4);
    address += sizeDataSettings;
    if(ds->enable[0]) {
        WriteBufferWord((uint)address, (uint*)data0, sizeData0 / 4);
        address += sizeData0;
    }
    if(ds->enable[1]) {
        WriteBufferWord((uint)address, (uint*)data1, sizeData1 / 4);
    }
}
