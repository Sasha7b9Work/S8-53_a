/// @file

#include "EEPROM.h"
#include "HAL.h"

void EEPROM_WriteWord(uint address, uint word) {
    HAL_EEPROM_WriteWord(address, word);
}

uint EEPROM_ReadWord(uint address) {
    return HAL_EEPROM_ReadWord(address);
}
