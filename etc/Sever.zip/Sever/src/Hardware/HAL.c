/** @file
    @verbatim
    ***** FSMC ************************************************************************
    �������   �����������   �������
    �� �����  �� �����        CPU
    43        DAO  PD14        85
    42        DA1  PD15        86
    41        DA2  PD0         114
    40        DA3  PD1         115
    39        DA4  PE7         58
    38        DA5  PE8         59
    37        DA6  PE9         60
    36        DA7  PE10        63

    24        A16  PD11        80
    25        A17  PD12        81
    26        A18  PD13        82
    27        A19  PE3         2
    28        A20  PE4         3
    29        A21  PE5         4
    30        A22  PE6         5
    31        A23  PE2         1

    19        RD   PD4        118
    18        WR   PD5        119
    32        NE1  PD7        123   
    33        NL1  PB7        137


    A23 A22 A21 A20 A19 A18 A17 A16
    ����          81.��.��                1   0   0   0   0   0   0   1
    ��������� �/� 90.��.�� D0...D7        1   0   0   1   0   0   0   0
    91.��.�� A0                           1   0   0   1   0   0   0   1
    ��������� ��. 80.��.��                1   0   0   0   0   0   0   0

    ************************************************************************************
    ��� �������� ������� ���. ��������
    ������� �������
    CPU     PIC24
PG11   126     24	������� ���������� PIC24 � ����� 1 - �����, 0 - �� �����

    ************************************************************************************
    ��� ��� �������������
    ���� - ADC3 - 18 ADC3_IN4 - PF6
    �������� ������� 25���
    ����� ������:
    - ��������� �� 1 ����������� ������
    - ��������� ��������� �� ������ �������� ������� (���������� �� 112 - EXT11 - PC11)

    *************************************************************************************
    USB - Flash - HS-FS
    74 - PB13 - OTG_HS_FS_VBUS
    75 - PB14 - OTG_HS_FS_DM
    76 - PB15 - JNG_HS_FS_DP

    USB - PC FS
    101 - PA9 - OTG_FS_VBUS
    103 - PA11 - OTG_FS_DM
    104 - PA12 - OTG_FS_DP

    ************************************************************************************
    ���������� �����
    87 - PG2 - SCLK
    88 - PG3 - DATA
    ...
    90 - PG5 - setect1
    ...
    92 - PG7 - select2

    ***********************************************************************************
    ������������� - 57 - PG1 : 0 - �������, 1 - �/�

    40 - ������� - DAC1_OUT - PA4

    * @endverbatim 
    */

/*
    ��������������� ���������� �������

	PG12 - �������� ��� ����� ���������.

    GPIOA
    GPIOB
    GPIOC
    GPIOD
    GPIOE
    GPIOF
    GPIOG
    FSMC
    TIM6 - ������� �����
    TIM2 - ������� ����
    TIM7 - DAC
    DAC
    PWR
    ADC3
    SYSCFG
    SPI1
*/


#include "HAL.h"
#include "FLASH.h"
#include "../FPGA/FPGA.h"
#include "../Panel/Panel.h"
#include "../Settings/Settings.h"
#include "../Math/GlobalFunctions.h"
#include "../Menu/Pages/PageDebug.h"
#include "../Timer.h"
#include "../Log.h"
#include "../ETH/stm32f2x7_eth_bsp.h"
#include "Sound.h"

#include <stm32f2xx_adc.h>
#include <stm32f2xx_fsmc.h>
#include <stm32f2xx_rcc.h>
#include <stm32f2xx_gpio.h>
#include <stm32f2xx_tim.h>
#include <stm32f2xx_dac.h>
#include <stm32f2xx_syscfg.h>
#include <stm32f2xx_exti.h>
#include <stm32f2xx_spi.h>
#include <stm32f2xx_pwr.h>
#include <stm32f2xx_rtc.h>
#include <stm32f2xx_flash.h>
#include <misc.h>

#define VALUE_FOR_RTC 0x1234

void PanelInit(void);

void HAL_Init() {
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA | RCC_AHB1Periph_GPIOB | RCC_AHB1Periph_GPIOC | RCC_AHB1Periph_GPIOD | 
                           RCC_AHB1Periph_GPIOE | RCC_AHB1Periph_GPIOF | RCC_AHB1Periph_GPIOG | 
                           RCC_AHB1Periph_DMA1,             // ��� DAC1 (�������)
                           ENABLE);
    RCC_AHB3PeriphClockCmd(RCC_AHB3Periph_FSMC, ENABLE);
    RCC_APB1PeriphClockCmd( RCC_APB1Periph_TIM6 |           // ������ ��� ������� �����������
                            RCC_APB1Periph_TIM2 |           // ������ ��� �����
                            RCC_APB1Periph_TIM7 |           // ������ ��� DAC1 (�������)
                            RCC_APB1Periph_DAC  |           // ��� �������
                            RCC_APB1Periph_PWR,
                            ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC3 | RCC_APB2Periph_SYSCFG | RCC_APB2Periph_SPI1, ENABLE);
    //RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);     // EEPROM

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);

// ���� /////////////////////////////////////////////////////////////////////////////////////

    if(RTC_ReadBackupRegister(RTC_BKP_DR0) != VALUE_FOR_RTC) {
        if(HAL_SetTimeAndData(11, 11, 11, 11, 11, 11)) {
            RTC_WriteBackupRegister(RTC_BKP_DR0, VALUE_FOR_RTC);
        }
    }
    
// Analog and DAC programmable SPI ///////////////////////////////////////////////////////////

    GPIO_InitTypeDef isGPIOG = {
        GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_5 | GPIO_Pin_7,
        GPIO_Mode_OUT,
        GPIO_Speed_100MHz,
        GPIO_OType_PP,
        GPIO_PuPd_NOPULL
    };
    GPIO_Init(GPIOG, &isGPIOG);

// ��� ���� ������� PG1 - 0 - �������, 1 - �����-�����  ////////////////////////////////////////
    isGPIOG.GPIO_Pin = GPIO_Pin_1;
    isGPIOG.GPIO_Mode = GPIO_Mode_IN;
    GPIO_Init(GPIOG, &isGPIOG);

// Color display /////////////////////////////////////////////////////////////////////////////

#ifdef DISPLAY_COLOR
    GPIO_InitTypeDef isGPIO_ = {
        GPIO_Pin_11,
        GPIO_Mode_IN,
        GPIO_Speed_100MHz,
        GPIO_OType_PP,
        GPIO_PuPd_NOPULL
    };
    GPIO_Init(GPIOG, &isGPIO_);      // ������ ���������� �������  � ����� �������
#endif

// ADC3  /////////////////////////////////////////////////////////////////////////////////////

    GPIO_InitTypeDef isGPIOC = {
        GPIO_Pin_11,            // GPIO_Pin
        GPIO_Mode_IN,           // GPIO_Mode
        GPIO_Speed_25MHz,       // GPIO_Speed
        GPIO_OType_PP,          // GPIO_OType
        GPIO_PuPd_NOPULL        // GPIO_PuPd
    };
    GPIO_Init(GPIOC, &isGPIOC);

    SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOC, EXTI_PinSource11);

    EXTI_InitTypeDef isEXTI = {
        EXTI_Line11,            // EXTI_Line
        EXTI_Mode_Interrupt,    // EXTI_Mode
        EXTI_Trigger_Rising,    // EXTI_Trigger
        ENABLE                  // EXTI_LineCmd
    };
    
    EXTI_Init(&isEXTI);

    GPIO_InitTypeDef isGPIOF = {
        GPIO_Pin_6,             // GPIO_Pin
        GPIO_Mode_AN,           // GPIO_Mode
        GPIO_Speed_25MHz,       // GPIO_Speed
        GPIO_OType_PP,          // GPIO_OType
        GPIO_PuPd_NOPULL,       // GPIO_PuPd
    };

    GPIO_Init(GPIOF, &isGPIOF);

    ADC_CommonInitTypeDef cisADC3 = {
        ADC_Mode_Independent,       // ADC_Mode
        ADC_Prescaler_Div2,         // ADC_Prescaler
        ADC_DMAAccessMode_Disabled  // ADC_DMAAccessMode
    };

    ADC_CommonInit(&cisADC3);

    ADC_InitTypeDef isADC3 = {
        ADC_Resolution_12b,                 // ADC_Resolution
        DISABLE,                            // ADC_ScanConvMode
        DISABLE,                            // ADC_ContinuousConvMode
        ADC_ExternalTrigConvEdge_Rising,    // ADC_ExternalTrigConvEdge
        ADC_ExternalTrigConv_Ext_IT11,      // ADC_ExternalTrigConv
        ADC_DataAlign_Right,                // ADC_DataAlign
        1                                   // ADC_NbrOfConversion
    };

    ADC_Init(ADC3, &isADC3);
    ADC_RegularChannelConfig(ADC3, ADC_Channel_4, 1, ADC_SampleTime_28Cycles);
    ADC_Cmd(ADC3, ENABLE);

// FSMC   //////////////////////////////////////////////////////////////////////////////////

    /* GPIOD configuration */
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource0, GPIO_AF_FSMC);     // DA2
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource1, GPIO_AF_FSMC);     // DA3
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource4, GPIO_AF_FSMC);     // RD
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource5, GPIO_AF_FSMC);     // WR
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource7, GPIO_AF_FSMC);     // NE1
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource11, GPIO_AF_FSMC);    // A16
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource12, GPIO_AF_FSMC);    // A17
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource13, GPIO_AF_FSMC);    // A18
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource14, GPIO_AF_FSMC);    // DA0
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource15, GPIO_AF_FSMC);    // DA1

    GPIO_InitTypeDef isGPIO = {
        GPIO_Pin_0  | GPIO_Pin_1  | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_7 | GPIO_Pin_11  | GPIO_Pin_12  | 
        GPIO_Pin_13  | GPIO_Pin_14  | GPIO_Pin_15,
        GPIO_Mode_AF,
        GPIO_Speed_25MHz,
        GPIO_OType_PP,
        GPIO_PuPd_NOPULL
    };

    GPIO_Init(GPIOD, &isGPIO);

    /* GPIOE configuration */
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource2, GPIO_AF_FSMC);     // A23
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource3 , GPIO_AF_FSMC);    // A19
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource4 , GPIO_AF_FSMC);    // A20
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource5 , GPIO_AF_FSMC);    // A21
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource6 , GPIO_AF_FSMC);    // A22
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource7 , GPIO_AF_FSMC);    // DA4
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource8 , GPIO_AF_FSMC);    // DA5
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource9 , GPIO_AF_FSMC);    // DA6
    GPIO_PinAFConfig(GPIOE, GPIO_PinSource10 , GPIO_AF_FSMC);   // DA7

    isGPIO.GPIO_Pin = GPIO_Pin_2  | GPIO_Pin_3 |  
        GPIO_Pin_4  | GPIO_Pin_5  | GPIO_Pin_6  | GPIO_Pin_7 |
        GPIO_Pin_8  | GPIO_Pin_9  | GPIO_Pin_10;

    GPIO_Init(GPIOE, &isGPIO);

    GPIO_PinAFConfig(GPIOB, GPIO_PinSource7, GPIO_AF_FSMC);     // NL1
    isGPIO.GPIO_Pin = GPIO_Pin_7;
    GPIO_Init(GPIOB, &isGPIO);

    FSMC_NORSRAMTimingInitTypeDef pRead = {
        5,                  // FSMC_AddressSetupTime
        7,                  // FSMC_AddressHoldTime
        13,                 // FSMC_DataSetupTime
        11,                 // FSMC_BusTurnAroundDuration
        3,                  // FSMC_CLKDivision
        0,                  // FSMC_DataLatency
        FSMC_AccessMode_A   // FSMC_AccessMode
    };

    FSMC_NORSRAMInitTypeDef isNOSRAM = {

        FSMC_Bank1_NORSRAM1,                    // FSMC_Bank
        FSMC_DataAddressMux_Enable,             // FSMC_DataAddressMux
        FSMC_MemoryType_NOR,                    // FSMC_MemoryType
        FSMC_MemoryDataWidth_8b,                // FSMC_MemoryDataWidth
        FSMC_BurstAccessMode_Disable,           // FSMC_BurstAccessMode
        FSMC_AsynchronousWait_Disable,          // FSMC_AsynchronousWait
        FSMC_WaitSignalPolarity_Low,            // FSMC_WaitSignalPolarity
        FSMC_WrapMode_Disable,                  // FSMC_WrapMode
        FSMC_WaitSignalActive_BeforeWaitState,  // FSMC_WaitSignalActive
        FSMC_WriteOperation_Enable,             // FSMC_WriteOperation
        FSMC_WaitSignal_Disable,                // FSMC_WaitSignal
        FSMC_ExtendedMode_Disable,              // FSMC_ExtendedMode
        FSMC_WriteBurst_Disable,                // FSMC_WriteBurst
        &pRead,                                 // FSMC_ReadWriteTimingStruct
        &pRead                                  // FSMC_WriteTimingStruct
    };

    FSMC_NORSRAMInit((FSMC_NORSRAMInitTypeDef*)(&isNOSRAM)); 

    FSMC_NORSRAMCmd(FSMC_Bank1_NORSRAM1, ENABLE);

// Timer  ///////////////////////////////////////////////////////////////////////////////////
    RCC_PCLK1Config(RCC_HCLK_Div1);

    // ������ ��� ��
    NVIC_InitTypeDef isNVIC = {
        TIM6_DAC_IRQn,      // NVIC_IRQChannel
        2,              // NVIC_IRQChannelPreemptionPriority
        4,              // NVIC_IRQChannelSubPriority
        ENABLE          // NVIC_IRQChannelCmd
    };

    NVIC_Init(&isNVIC);

    TIM_TimeBaseInitTypeDef isTIM6 = {
        119,                    // TIM_Prescaler
        TIM_CounterMode_Up,     // TIM_CounterMode
        1000,                   // TIM_Period
        TIM_CKD_DIV1            // TIM_ClockDivision
    };

    TIM_TimeBaseInit(TIM6, &isTIM6);
    TIM_ARRPreloadConfig(TIM6, DISABLE);
    TIM_ITConfig(TIM6, TIM_IT_Update, ENABLE);
    TIM_Cmd(TIM6, ENABLE);

    // ������ ��� �����

    TIM_TimeBaseInitTypeDef isTIM2 = {
        0,
        TIM_CounterMode_Up,
        0xffffffff,
        TIM_CKD_DIV1
    };

    TIM_TimeBaseInit(TIM2, &isTIM2);
    TIM_SetCounter(TIM2, 0);
    TIM_Cmd(TIM2, ENABLE);

// Panel ///////////////////////////////////////////////////////////////////////////////////
    PanelInit();

    //Sound_Init();
}

void PanelInit() {

    /*
    SPI1
    56  - PG0 - ����������� NSS 
    41  - PA5 - SCK
    42  - PA6 - MISO
    135 - PB5 - MOSI
    */

    GPIO_PinAFConfig(GPIOA, GPIO_PinSource5, GPIO_AF_SPI1);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource6, GPIO_AF_SPI1);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource5, GPIO_AF_SPI1);

    GPIO_InitTypeDef isGPIOpanel = {
        GPIO_Pin_5 | GPIO_Pin_6,
        GPIO_Mode_AF,
        GPIO_Speed_50MHz,
        GPIO_OType_PP,
        GPIO_PuPd_DOWN
    };

    GPIO_Init(GPIOA, &isGPIOpanel);

    isGPIOpanel.GPIO_Pin = GPIO_Pin_5;
    GPIO_Init(GPIOB, &isGPIOpanel);

    SPI_InitTypeDef isSPI = {
        SPI_Direction_2Lines_FullDuplex,    // SPI_Direction
        SPI_Mode_Slave,                     // SPI_Mode
        SPI_DataSize_8b,                    // SPI_DataSize
        SPI_CPOL_High,                      // SPI_CPOL
        SPI_CPHA_1Edge,                     // SPI_CPHA
        SPI_NSS_Soft,                       // SPI_NSS
        SPI_BaudRatePrescaler_2,            // SPI_BaudRatePrescaler
        SPI_FirstBit_MSB,                   // SPI_FirstBit
        7                                   // SPI_CRCPolynomial
    };

    SPI_DeInit(SPI1);

    SPI_Init(SPI1, &isSPI);

    SPI_ITConfig(SPI1, SPI_I2S_IT_RXNE, DISABLE);
    SPI_ITConfig(SPI1, SPI_I2S_IT_RXNE, ENABLE);

    static NVIC_InitTypeDef initStructNVIC = {
        SPI1_IRQn,      // NVIC_IRQChannel
        2,              // NVIC_IRQChannelPreemptionPriority
        3,              // NVIC_IRQChannelSubPriority
        ENABLE          // NVIC_IRQChannelCmd
    };

    NVIC_Init(&initStructNVIC);

    SPI_Cmd(SPI1, DISABLE);

    NVIC_DisableIRQ(SPI1_IRQn);
    NVIC_EnableIRQ(SPI1_IRQn);

    // ������ �������� ����������� NSS (PG0).

    GPIO_InitTypeDef isGPIOG = {
        GPIO_Pin_0,
        GPIO_Mode_IN,
        GPIO_Speed_50MHz,
        GPIO_OType_PP,
        GPIO_PuPd_DOWN
    };

    GPIO_Init(GPIOG, &isGPIOG);

    SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOG, EXTI_PinSource0);

    EXTI_InitTypeDef isEXTI = {
        EXTI_Line0,
        EXTI_Mode_Interrupt,
        EXTI_Trigger_Rising,
        ENABLE
    };

    EXTI_Init(&isEXTI);

    NVIC_InitTypeDef isNVIC = {
        EXTI0_IRQn,     // NVIC_IRQChannel
        2,              // NVIC_IRQChannelPreemptionPriority
        2,              // NVIC_IRQChannelSubPriority
        ENABLE          // NVIC_IRQChannelCmd
    };

    NVIC_Init(&isNVIC);
    NVIC_EnableIRQ(EXTI1_IRQn);
}

void EXTI0_IRQHandler(void) {
    if(EXTI_GetITStatus(EXTI_Line0) != RESET) {
        SPI_Cmd(SPI1, ENABLE);
        EXTI_ClearITPendingBit(EXTI_Line0);
    }
}

uint16 HAL_ADC_GetValue() {
    return ADC_GetConversionValue(ADC3);
}

void HAL_EEPROM_WriteWord(uint address, uint word) {
    /*
    //RTC_WriteBackupRegister(_address, _word);
    //PWR_BackupAccessCmd(ENABLE);
    *(__IO uint32_t *) (PERIPH_BB_BASE + (((PWR_BASE - PERIPH_BASE) + 0x00) * 32) + (0x08 * 4)) = (uint32_t)ENABLE;
    *(__IO uint32_t *)(RTC_BASE + 0x50 + address * 4) = word;
    //PWR_BackupAccessCmd(DISABLE);
    *(__IO uint32_t *) (PERIPH_BB_BASE + (((PWR_BASE - PERIPH_BASE) + 0x00) * 32) + (0x08 * 4)) = (uint32_t)DISABLE;
    */
    PWR_BackupAccessCmd(ENABLE);
    RTC_WriteBackupRegister(address, word);
    PWR_BackupAccessCmd(DISABLE);
}

uint HAL_EEPROM_ReadWord(uint address) {
    /*
    // RTC_ReadBackupRegister(_address);
    //PWR_BackupAccessCmd(ENABLE);
    *(__IO uint32_t *) (PERIPH_BB_BASE + (((PWR_BASE - PERIPH_BASE) + 0x00) * 32) + (0x08 * 4)) = (uint32_t)ENABLE;
    uint16 retValue = (*(__IO uint32_t *)(RTC_BASE + 0x50 + address * 4));
    //PWR_BackupAccessCmd(DISABLE);
    *(__IO uint32_t *) (PERIPH_BB_BASE + (((PWR_BASE - PERIPH_BASE) + 0x00) * 32) + (0x08 * 4)) = (uint32_t)DISABLE;
    return retValue;
    */
    PWR_BackupAccessCmd(ENABLE);
    uint retValue = RTC_ReadBackupRegister(address);
    PWR_BackupAccessCmd(DISABLE);
    return retValue;
}

void HAL_FLASH_EraseSector(uint startAddress) {
    uint16 sector = 0;
    if(startAddress == ADDR_SECTOR_DATA_1) {
        sector = FLASH_Sector_6;
    } else if(startAddress == ADDR_SECTOR_DATA_2) {
        sector = FLASH_Sector_7;
    } else if(startAddress == ADDR_SECTOR_DATA_3) {
        sector = FLASH_Sector_8;
    } else if(startAddress == ADDR_SECTOR_RESOURCES_0) {
        sector = FLASH_Sector_9;
    } else if(startAddress == ADDR_SECTOR_SESOURCES_1) {
        sector = FLASH_Sector_10;
    } else if(startAddress == ADDR_SECTOR_SETTINGS) {
        sector = FLASH_Sector_11;
    }

    FLASH_Unlock();

    FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_OPERR | FLASH_FLAG_WRPERR | FLASH_FLAG_PGAERR | FLASH_FLAG_PGPERR | FLASH_FLAG_PGSERR);


    if(FLASH_EraseSector(sector, VoltageRange_3) != FLASH_COMPLETE) {
        LOG_ERROR("�� ���� ������� ������ ����-������");
    } else {
        Log_Write("�������� ��������� �������");
    }
    FLASH_Lock();
}

void HAL_FLASH_WriteWord(uint address, uint word) {
    FLASH_Unlock();
    if(FLASH_ProgramWord(address, word) != FLASH_COMPLETE) {
        LOG_ERROR("�� ���� �������� � ������");
    }
    FLASH_Lock();
}

void HAL_FLASH_WriteBufferWord(uint address, uint *buffer, int size) {
    FLASH_Unlock();
    for(int i = 0; i < size; i++) {
        if(FLASH_ProgramWord(address, buffer[i]) != FLASH_COMPLETE) {
            LOG_ERROR("�� ���� �������� � ����-������");
        }
        address += sizeof(uint);
    }
    FLASH_Lock();
}

#define pinCLC      GPIO_Pin_2
#define pinData     GPIO_Pin_3
#define CHIP_SELECT_IN_LOW  GPIO_WriteBit(GPIOG, pinSelect, Bit_RESET);
#define CHIP_SELECT_IN_HI   GPIO_WriteBit(GPIOG, pinSelect, Bit_SET);
#define CLC_HI              GPIO_WriteBit(GPIOG, pinCLC, Bit_SET);
#define CLC_LOW             GPIO_WriteBit(GPIOG, pinCLC, Bit_RESET);
#define DATA_SET(x)         GPIO_WriteBit(GPIOG, pinData, x);

void HAL_WriteToAnalog(TypeWriteAnalog type, uint data) {
#define pinSelect   GPIO_Pin_5

    char *str = Bin2String16(data);
    if(type == TypeWriteAnalog_Range0 && IsShowReg_Range(Chan0)) {
        Log_Write("range 0 = %s", str);
    } else if(type == TypeWriteAnalog_Range1 && IsShowReg_Range(Chan1)) {
        Log_Write("range 1 = %s", str);
    } else if(type == TypeWriteAnalog_TrigParam && IsShowReg_TrigParam()) {
        Log_Write("�����. �����. = %s", str);
    } else if(type == TypeWriteAnalog_ChanParam0 && IsShowReg_ChanParam(Chan0)) {
        Log_Write("�����. ���. 1 = %s", str);
    } else if(type == TypeWriteAnalog_ChanParam1 && IsShowReg_ChanParam(Chan1)) {
        Log_Write("�����. ���. 2 = %s", str);
    } else if(type == TypeWriteAnalog_All && (IsShowReg_TrigParam() || IsShowReg_Range(Chan0) || IsShowReg_Range(Chan1) || IsShowReg_ChanParam(Chan0) || 
                IsShowReg_ChanParam(Chan1))) {
        Log_Write("������ ������ � ���������� ����� = %s", str);
    }

    CHIP_SELECT_IN_LOW
    for(int i = 23; i >= 0; i--) {
        DATA_SET((data & (1 << i)) ? Bit_SET : Bit_RESET);
        CLC_HI
        CLC_LOW
    }
    CHIP_SELECT_IN_HI;
}

void HAL_WriteToDAC(TypeWriteDAC type, uint16 data) {
#undef pinSelect
#define pinSelect   GPIO_Pin_7

    if(type == TypeWriteDAC_RShift0 && IsShowReg_RShift0()) {
        Log_Write("rShift 0 = %s", Bin2String16(data));
    } else if(type == TypeWriteDAC_RShift1 && IsShowReg_RShift1()) {
        Log_Write("rShfit 1 = %s", Bin2String16(data));
    } else if(type == TypeWriteDAC_TrigLev && IsShowReg_TrigLev()) {
        Log_Write("trigLev = %s", Bin2String16(data));
    }

    CHIP_SELECT_IN_LOW
    for(int i = 15; i >= 0; i--) {
        DATA_SET((data & (1 << i)) ? Bit_SET : Bit_RESET);
        CLC_HI
        CLC_LOW
    }
    CHIP_SELECT_IN_HI;
}

void SPI1_IRQHandler(void) {
    if(SPI_GetITStatus(SPI1, SPI_I2S_IT_RXNE) == SET) {
        bool rez = Panel_ProcessingCommandFromPIC(SPI_ReceiveData(SPI1));
        while(SPI_GetFlagStatus(SPI1, SPI_I2S_FLAG_BSY) == SET) {
        }
        if(!rez) {
            PanelInit();
            return;
        }
        uint16 data = Panel_NextData();
        SPI_SendData(SPI1, data);
    }
    SPI_Cmd(SPI1, DISABLE);
}

void TIM6_DAC_IRQHandler(void) {
    if(TIM_GetFlagStatus(TIM6, TIM_FLAG_Update) && TIM_GetITStatus(TIM6, TIM_IT_Update)) {
        Timer_Update1ms();
        TIM_ClearFlag(TIM6, TIM_FLAG_Update);
        TIM_ClearITPendingBit(TIM6, TIM_IT_Update);
    }
}

/*
void TIM7_IRQHandler(void) {

    if(TIM_GetFlagStatus(TIM7, TIM_FLAG_Update) && TIM_GetITStatus(TIM7, TIM_IT_Update)) {
        
        TIM_ClearFlag(TIM7, TIM_FLAG_Update);
        TIM_ClearITPendingBit(TIM7, TIM_IT_Update);
    }

}
*/


void EXTI15_10_IRQHandler(void)
{
  if(EXTI_GetITStatus(ETH_LINK_EXTI_LINE) != RESET)
  {
    //Eth_Link_ITHandler(DP83848_PHY_ADDRESS);
    /* Clear interrupt pending bit */
   //XTI_ClearITPendingBit(ETH_LINK_EXTI_LINE);
  }
}

int HAL_GetHours() {
    RTC_TimeTypeDef isTime;
    RTC_GetTime(RTC_Format_BIN, &isTime);
    return isTime.RTC_Hours;
}

int HAL_GetMinutes() {
    RTC_TimeTypeDef isTime;
    RTC_GetTime(RTC_Format_BIN, &isTime);
    return isTime.RTC_Minutes;
}

int HAL_GetSeconds() {
    RTC_TimeTypeDef isTime;
    RTC_GetTime(RTC_Format_BIN, &isTime);
    return isTime.RTC_Seconds;
}

int HAL_GetYear() {
    RTC_DateTypeDef isDate;
    RTC_GetDate(RTC_Format_BIN, &isDate);
    return isDate.RTC_Year + 2000;
}

int HAL_GetMonth() {
    RTC_DateTypeDef isDate;
    RTC_GetDate(RTC_Format_BIN, &isDate);
    return isDate.RTC_Month;
}

int HAL_GetDay() {
    RTC_DateTypeDef isDate;
    RTC_GetDate(RTC_Format_BIN, &isDate);
    return isDate.RTC_Date;
}

bool HAL_SetTimeAndData(int day, int month, int year, int hours, int minutes, int seconds) {

    PWR_BackupAccessCmd(ENABLE);
    RCC_LSEConfig(RCC_LSE_ON);
    while(RCC_GetFlagStatus(RCC_FLAG_LSERDY) == RESET) {};
    RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);
    RCC_RTCCLKCmd(ENABLE);
    RTC_WaitForSynchro();
    RTC_TimeStampCmd(RTC_TimeStampEdge_Falling, ENABLE);

    RTC_InitTypeDef isRTC;
    isRTC.RTC_AsynchPrediv = 0x7f;
    isRTC.RTC_SynchPrediv = 0xff;
    isRTC.RTC_HourFormat = RTC_HourFormat_24;

    if(RTC_Init(&isRTC) == ERROR) {
        Log_Write("������ ������������� �����");
    }

    RTC_TimeTypeDef isTime;
    RTC_DateTypeDef isDate;

    isTime.RTC_H12 = RTC_H12_AM;
    isTime.RTC_Hours = hours;
    isTime.RTC_Minutes = minutes;
    isTime.RTC_Seconds = seconds;
    if(RTC_SetTime(RTC_Format_BIN, &isTime) == ERROR) {
        Log_Write("�� ���� ���������� �����");
        return false;
    }

    isDate.RTC_WeekDay = 1;
    isDate.RTC_Date = day;
    isDate.RTC_Month = month;
    isDate.RTC_Year = year;
    if(RTC_SetDate(RTC_Format_BIN, &isDate) == ERROR) {
        LOG_ERROR("�� ���� ���������� ����");
        return false;
    };

    return true;
}



