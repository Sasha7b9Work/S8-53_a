/// @file

#pragma once  

#include "../defines.h"

typedef enum {
    TypeWriteDAC_RShift0,
    TypeWriteDAC_RShift1,
    TypeWriteDAC_TrigLev
} TypeWriteDAC;

typedef enum {
    TypeWriteAnalog_All,
    TypeWriteAnalog_Range0,
    TypeWriteAnalog_Range1,
    TypeWriteAnalog_TrigParam,
    TypeWriteAnalog_ChanParam0,
    TypeWriteAnalog_ChanParam1
} TypeWriteAnalog;

void HAL_Init(void);

uint16 HAL_ADC_GetValue(void);

void HAL_EEPROM_WriteWord(uint address, uint word);
uint HAL_EEPROM_ReadWord(uint address);

void HAL_FLASH_EraseSector(uint startAddress);
void HAL_FLASH_WriteWord(uint address, uint word);
void HAL_FLASH_WriteBufferWord(uint address, uint *buffer, int size);

void HAL_WriteToAnalog(TypeWriteAnalog type, uint data);
void HAL_WriteToDAC(TypeWriteDAC type, uint16 data);

int HAL_GetHours(void);
int HAL_GetMinutes(void);
int HAL_GetSeconds(void);
int HAL_GetYear(void);
int HAL_GetMonth(void);
int HAL_GetDay(void);
bool HAL_SetTimeAndData(int day, int month, int year, int hours, int minutes, int seconds);


