#pragma once

#include "../Settings/Settings.h"

void Sound_Set(Sound *sound);
void Sound_Beep(void);
