/// @file

#pragma once

#include "../defines.h"

#define EEPROM_RShift0          0
#define EEPROM_RShift1          1
#define EEPROM_TShift           2
#define EEPROM_Range0           3
#define EEPROM_Range1           4
#define EEPROM_TBase            5
#define EEPROM_TrigLev0         6
#define EEPROM_TrigLev1         7
#define EEPROM_SinchroChannel   8
#define EEPROM_9
#define EEPROM_10
#define EEPROM_11
#define EEPROM_12
#define EEPROM_13
#define EEPROM_14
#define EEPROM_15
#define EEPROM_16
#define EEPROM_17
#define EEPROM_18
#define EEPROM_19

void EEPROM_WriteWord(uint address, uint word);
uint EEPROM_ReadWord(uint address);

