
#include "./Hardware/HAL.h"
#include "fattime.h"



/*
Description of Return Value of DWORD get_fattime (void) function.
Currnet time is returned with packed into a DWORD value. The bit field is as follows:
bit31:25
Year origin from the 1980 (0..127)
bit24:21
Month (1..12)
bit20:16
Day of the month(1..31)
bit15:11
Hour (0..23)
bit10:5
Minute (0..59)
bit4:0
Second / 2 (0..29)

Description
The get_fattime() function shall return any valid time even if the system does not support a real time clock. If a zero is returned, the file will not have a valid timestamp.
QuickInfo
This function is not needed when _FS_READONLY == 1.

more info: http://elm-chan.org/fsw/ff/en/fattime.html
*/


DWORD get_fattime (void)
{
	DWORD * tmp;
	
	struct {
		unsigned year: 7;
		unsigned month: 4;
		unsigned day: 5;
		unsigned hour: 5;
		unsigned minute: 6;
		unsigned halfsecond: 5;
	}	time;
	
	tmp = (DWORD*)&time;

	
	time.year = (HAL_GetYear() - 1980);
	time.month = HAL_GetMonth();
	time.day = HAL_GetDay();
	time.hour = HAL_GetHours();
	time.minute = HAL_GetMinutes();
	time.halfsecond = HAL_GetSeconds()/2;
	
	
  return *tmp;
}



