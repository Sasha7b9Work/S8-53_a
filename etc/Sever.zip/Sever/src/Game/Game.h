#pragma once
#include "../defines.h"

void Game_Start(void *_memory, uint _sizeMemory, uint8 *_srceen);
