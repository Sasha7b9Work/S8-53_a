#include "Game.h"

static uint8 *screen = 0;
extern uint8 codeButton = 0;

void Game_Start(void *_memory, uint _sizeMemory, uint8 *_srceen) {
	screen = _srceen;
}

