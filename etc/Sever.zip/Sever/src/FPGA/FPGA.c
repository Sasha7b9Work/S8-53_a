/// @file

#include "FPGA.h"
#include "FPGA_Settings.h"
#include "DataStorage.h"
#include "FPGA_Types.h"
#include "../Menu/Pages/PageChannels.h"
#include "../Menu/Pages/PageDebug.h"
#include "../Menu/Pages/PageTrig.h"
#include "../Menu/Pages/PageTime.h"
#include "../Menu/Pages/PageDisplay.h"
#include "../Menu/Pages/PageMemory.h"
#include "../Display/Display.h"
#include "../Display/DisplayDrawing.h"
#include "../Hardware/FSMC.h"
#include "../Hardware/HAL.h"
#include "../Panel/Panel.h"
#include "../Panel/Controls.h"
#include "../Settings/Settings.h"  
#include "../Math/Math.h"
#include "../Math/GlobalFunctions.h"
#include "../Math/ProcessingSignal.h"
#include "../Timer.h"
#include "../Log.h"

/** @addtogroup SEVER_HARDWARE
    @{ */

#define NULL_TSHIFT 1000000

State state = {
    false,
    B_Empty,
    StateFPGA_Stop,
    StateCalibration_None
};

extern Redraw redraw;

static BitSet32 freqFPGA = {0};
static BitSet32 periodFPGA = {0};
static float freq = 0.0f;           ///< �������, ���������� ��������.
volatile static int numberMeasuresForGates = 1000;
static bool autoFindInProgress = false;

static int additionShift = 0;
static const int n = 200;
static const int Kr[] = {n / 2, n / 5, n / 10, n / 20, n / 50};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static void     DataRead(                           ///  ��������� ������.
                         bool necessaryShift        ///< ������� ����, ��� ������ ����� �������.
                         );       
static void     ReadPoint(void);
static void     ReadFreq(void);
static void     ReadPeriod(void);
static uint8    ReadFlag(void);
static bool     CalculateGate(uint16 rand, uint16 *min, uint16 *max);
static int      CalculateShift(void);
static void     InverseDataIsNecessary(Channel chan, uint8 *data);          ///< ����������� ������
static void     ApplySmoothlyRange(Channel chan, uint8 *data);              ///< ���� ������� ����� �������� ��������� �������� ����������, ��������� ������ ��� ������� �������.   
static void     OnTimerCanReadData(void);                                   ///< ������� ����������, ����� ����� ��������� ��������� ������.
static void     AutoFind(void);
static uint8    CalculateMin(Channel chan);
static uint8    CalculateMax(Channel chan);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static uint8 dataRel0[FPGA_MAX_POINTS] = {0};       ///< ����� ������������ ��� ������ ������ ������� ������.
static uint8 dataRel1[FPGA_MAX_POINTS] = {0};       ///< ����� ������������ ��� ������ ������ ������� ������.
static bool  inProcessingOfRead = false;
static volatile uint  timeClear = 0;                         ///< ����� ��������� ������� ������ ( FPGA_ClearData() ).
static int   countReads = 0;                        ///< ������� ������, ������� ��������� ��� ���������� ������ ��������� � ������ �������������.

static StateFPGA stateFPGA = StateFPGA_Stop;        ///< ������� ��������� �������.
static bool iCanReadData = true;
static bool critiacalSituation = false;
static Settings storingSettings;
static uint timeStart = 0;
static bool firstAfterWrite = false;                // ������������ � ������ �������������. ����� ������ ������ ��������� � �������
                                                    // ����� �� ������������ ������ ��������� ������ � ���, ������ ��� ��� �������� � ������ ������.


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void FPGA_Init() {
    DS_Clear();
}

void FPGA_SetNumSignalsInSec(int numSigInSec) {
    Timer_SetTimer(Timer_NumSignalsInSec, 1000.f / numSigInSec, OnTimerCanReadData);
}

void OnTimerCanReadData() {
    iCanReadData = true;
}

void SwitchingTrig() {
    FSMC_Write(WR_TRIG_F, GetTrigPolarity() == TrigPolarity_Front ? 0x00 : 0x01);
    FSMC_Write(WR_TRIG_F, GetTrigPolarity() == TrigPolarity_Front ? 0x01 : 0x00);
}

bool ProcessingData() {

    bool retValue = false;

    int num = (GetRandomizeModeEnable() && GetTrigStartMode() != StartMode_Single) ? 50 : 1;

    for(int i = 0; i < num; i++) {
        uint8 flag = ReadFlag();
        if(critiacalSituation) {
            if(Timer_GetMS() - timeStart > 500) {
                SwitchingTrig();
                critiacalSituation = false;
            } else if(_GET_BIT(flag, BIT_TRIG)) {
                critiacalSituation = false;
            }
        } else if(_GET_BIT(flag, BIT_DATA_READY)) {
            if(IsShowReg_RD_FL()) {
                Log_Write("���� ���������� %s", Bin2String(flag));
            }
            Panel_EnableLEDTrig(true);
            FPGA_Stop(true);
            DataRead(_GET_BIT(flag, BIT_SIGN_SHIFT_POINT));
            retValue = true;
            if(GetTrigStartMode() != StartMode_Single) {
                FPGA_Start();
                stateFPGA = StateFPGA_Work;
            } else {
                FPGA_Stop(false);
            }
        } else if(_GET_BIT(flag, BIT_TRIG)) {
            Panel_EnableLEDTrig(true);
        } else {
            Panel_EnableLEDTrig(false);
            if(flag & (1 << 2)) {
                if(GetTrigStartMode() == StartMode_Auto) {
                    critiacalSituation = true;
                }
                timeStart = Timer_GetMS();
            }
        }
    }

    return retValue;
}

void FPGA_Update() {

	if(autoFindInProgress) {
		AutoFind();
		return;
	}

    if((!iCanReadData && !GetRandomizeModeEnable()) || (stateFPGA == StateFPGA_Stop)) {
        return;
    }

    if(ModeSelfRecorderEnable()) {
        ReadPoint();
    }

    ProcessingData();

    iCanReadData = false;
}

StateFPGA FPGA_State() {
    return stateFPGA;
}

void FPGA_OnPressStartStop() {
    if(stateFPGA == StateFPGA_Stop) {
        FPGA_Start();
    } else if(stateFPGA == StateFPGA_Wait) {
        FPGA_Stop(false);
    } else if(stateFPGA == StateFPGA_Work) {
        FPGA_Stop(false);
    } else if(stateFPGA == StateFPGA_Pause) {
        FPGA_Stop(false);
    } else {
        LOG_ERROR("����������� ��������� fpga = %d", (int)stateFPGA);
    }
}

void FPGA_Start() {
    if (GetTBase() >= MIN_TBASE_P2P) {
        Display_ResetP2Ppoints(false);
        Timer_SetTimer(Timer_P2P, 1, ReadPoint);
    } else {
        Timer_KillTimer(Timer_P2P);
        Display_ResetP2Ppoints(true);
    }

    FSMC_Write(WR_START, 1);
    timeStart = Timer_GetMS();
    stateFPGA = StateFPGA_Wait;
    critiacalSituation = false;
}

void FPGA_Stop(bool pause) {
    Timer_KillTimer(Timer_P2P);
    FSMC_Write(WR_STOP, 1);
    stateFPGA = pause ? StateFPGA_Pause : StateFPGA_Stop;
}

bool FPGA_IsRunning() {
    return stateFPGA != StateFPGA_Stop;
}

void DataRead(bool necessaryShift) {
    Panel_EnableLEDTrig(false);
    inProcessingOfRead = true;
    do {
        if(GetRandomizeModeEnable()) {

            countReads++;

            int Tsm = CalculateShift();
            if(Tsm == NULL_TSHIFT) {
                break;
            };

            int numPoints = FPGA_MAX_POINTS / Kr[GetTBase()] + 2;
            int step = Kr[GetTBase()];
            int index = Tsm - step - additionShift;
            if(index < 0) {     
                index += step;
            }

            uint8 *pData0 = &dataRel0[index];
            uint8 *pData0Last = &dataRel0[FPGA_MAX_POINTS - 1];
            uint8 *pData1 = &dataRel1[index];
            uint8 *pData1Last = &dataRel1[FPGA_MAX_POINTS - 1];

            int numAve = GetDebugNumAveForRand();
            if(GetNumAveraging() > numAve) {
                numAve = GetNumAveraging();
            }

            int addShiftMem = step / 2;

            StartMode startMode = GetTrigStartMode();

            if(startMode == StartMode_Single) {
                for(int i = 0; i < FPGA_MAX_POINTS; i++) {
                    dataRel0[i] = 0;
                    dataRel1[i] = 0;
                }
            }

            while(pData0 < &dataRel0[FPGA_MAX_POINTS]) {
                uint8 data10 = *RD_ADC_B2;
                uint8 data11 = *RD_ADC_B1;
                uint8 data00 = *RD_ADC_A2;
                uint8 data01 = *RD_ADC_A1;

                if(*pData0 == 0 || numAve == 1 || startMode == StartMode_Single) {
                    if(pData0 <= pData0Last) {
                        *pData0 = data00;
                    }
                    
                    if((pData0 + addShiftMem) <= pData0Last) {
                        *(pData0 + addShiftMem) = data01;
                    }

                    if(pData1 <= pData1Last) {
                        *pData1 = data10;
                    }
                    
                    if((pData1 + addShiftMem) <= pData1Last) {
                        *(pData1 + addShiftMem) = data11;
                    }
                } else {
                    *pData0 = (float)(numAve - 1) / (float)(numAve) * (*pData0) + data00 * 1.0f / (float)numAve;
                    if((pData0 + addShiftMem) <= pData0Last) {
                        *(pData0 + addShiftMem) = (float)(numAve - 1) / (float)(numAve) * (*(pData0 + addShiftMem)) + data01 * 1.0f / (float)numAve;
                    }

                    *pData1 = (float)(numAve - 1) / (float)(numAve) * (*pData1) + data10 * 1.0f / (float)numAve;
                    if((pData1 + addShiftMem) <= pData1Last) {
                        *(pData1 + addShiftMem) = (float)(numAve - 1) / (float)(numAve) * (*(pData1 + addShiftMem)) + data11 * 1.0f / (float)numAve;
                    }
                }

                pData0 += step;
                pData1 += step;
            }
            if(startMode == StartMode_Single) {
                Processing_InterpolationSinX_X(dataRel0, GetTBase());
                Processing_InterpolationSinX_X(dataRel1, GetTBase());
            }
            break;
        } else {
            uint8 *p0 = &dataRel0[0];
            uint8 *p1 = &dataRel1[0];
            uint8 *endP = &dataRel0[FPGA_MAX_POINTS];

            while(p0 < endP && inProcessingOfRead) {
                *p1++ = *RD_ADC_B2;
                *p1++ = *RD_ADC_B1;
                *p0++ = *RD_ADC_A2;
                *p0++ = *RD_ADC_A1;
            }

            if(!GetPeackDetEnable() && necessaryShift && GetDebugAltShift() != 0) {
                int shift = GetDebugAltShift();
                if(shift < 0) {
                    shift = -shift;
                    for(int i = FPGA_MAX_POINTS - shift - 1; i >= 0; i--) {
                        dataRel0[i + shift] = dataRel0[i];
                        dataRel1[i + shift] = dataRel1[i];
                    }
                } else {
                    for(int i = shift; i < FPGA_MAX_POINTS; i++) {
                        dataRel0[i - shift] = dataRel0[i];
                        dataRel1[i - shift] = dataRel1[i];
                    }
                }
            }

            /*
            if(!GetPeackDetEnable() && necessaryShift) {
                if(GetTBase() == TBase_200ns || GetTBase() == TBase_500ns) {
                    for(int i = FPGA_MAX_POINTS - 2; i >= 0; i--) {
                        dataRel0[i + 1] = dataRel0[i];
                        dataRel1[i + 1] = dataRel1[i];
                    }
                } else {
                    for(int i = 1; i < FPGA_MAX_POINTS; i++) {
                        dataRel0[i - 1] = dataRel0[i];
                        dataRel1[i - 1] = dataRel1[i];
                    }
                }
            }
            */
        }
    } while(false);

    InverseDataIsNecessary(Chan0, dataRel0);
    InverseDataIsNecessary(Chan1, dataRel1);

    ApplySmoothlyRange(Chan0, dataRel0);
    ApplySmoothlyRange(Chan1, dataRel1);

    DS_AddData(dataRel0, dataRel1);
    inProcessingOfRead = false;
}

void FPGA_SetAdditionShift(int shift) {
    additionShift = shift;
}

bool CalculateGate(uint16 rand, uint16 *eMin, uint16 *eMax) {

    if(firstAfterWrite) {
        firstAfterWrite = false;
        return false;
    }
    
    if(rand < 500 || rand > 3500) {
        Log_Write("������!!! ������� %d", rand);
        return false;
    }
    
    static const int numValues = 1000;

    static float minGate = 0.0f;
    static float maxGate = 0.0f;
    static int numElements = 0;
    static uint16 min = 0xffff;
    static uint16 max = 0;

    numElements++;
    if(rand < min) {
        min = rand;
    }
    if(rand > max) {
        max = rand;
    }

    if(minGate == 0) {
        *eMin = min;
        *eMax = max;
        //Log_Write("%u ... %u", min, max);
        if(numElements < numValues) {
            return true;
        }
        minGate = min;
        maxGate = max;
        numElements = 0;
        min = 0xffff;
        max = 0;
    }

    if(numElements == numValues) {
        minGate = 0.9f * minGate + 0.1f * min;
        maxGate = 0.9f * maxGate + 0.1f * max;
        //Log_Write("%.0f ... %.0f, min = %u, max = %u,  t = %.1f ���", minGate, maxGate, min, max, timeBetweenStarts);
        numElements = 0;
        min = 0xffff;
        max = 0;
    }
    *eMin = minGate;
    *eMax = maxGate;

    return true;
}

int CalculateShift() {
    uint16 rand = HAL_ADC_GetValue();
    uint16 min = 0;
    uint16 max = 0;
    if(!CalculateGate(rand, &min, &max)) {
        return NULL_TSHIFT;
    }
    float tin = (float)(rand - min) / (max - min) * 10e-9;
    int retValue = tin / 10e-9 * Kr[GetTBase()];
    return retValue;
}

void FPGA_WriteToHardware(uint8 *address, uint8 value, bool restart) {

    firstAfterWrite = true;
    if(restart) {
        if(inProcessingOfRead) {
            FPGA_Stop(true);
            inProcessingOfRead = false;
            FSMC_Write(address, value);
            FPGA_Start();
        } else {
            if(stateFPGA != StateFPGA_Stop) {
                FPGA_Stop(true);
                FSMC_Write(address, value);
                FPGA_Start();
            } else {
                FSMC_Write(address, value);
            }
        }
    } else {
        FSMC_Write(address, value);
    }
}

void ReadPoint() {
    if(_GET_BIT(ReadFlag(), BIT_POINT_READY)) {
        Display_AddPoint(Chan1, FSMC_Read(RD_ADC_B2), FSMC_Read(RD_ADC_B1));
        Display_AddPoint(Chan0, FSMC_Read(RD_ADC_A2), FSMC_Read(RD_ADC_A1));
    }
}

void FPGA_SaveState() {
    state.state = stateFPGA;
    Settings_StoreIn(&storingSettings);
}

void FPGA_RestoreState() {
    Settings_RestoreFrom(&storingSettings);
    FPGA_LoadSettings();
    if(state.state != StateFPGA_Stop) {
        state.state = StateFPGA_Stop;
        FPGA_OnPressStartStop();
    }
}

static bool readPeriod = false;                     ///< ������������� � true ���� ��������, ��� ������� ����� ������� �� �������� �������

void ReadFreq() {
    freqFPGA.byte[0] = FSMC_Read(RD_ADDR_FREQ_LOW);
    freqFPGA.byte[1] = FSMC_Read(RD_ADDR_FREQ_MID);
    freqFPGA.byte[2] = FSMC_Read(RD_ADDR_FREQ_HI);
    if(freqFPGA.word < 1000) {
        readPeriod = true;
    } else {
        freq = freqFPGA.word * 10;
    }
}

void ReadPeriod() {
    periodFPGA.byte[0] = FSMC_Read(RD_ADDR_PERIOD_LOW_LOW);
    periodFPGA.byte[1] = FSMC_Read(RD_ADDR_PERIOD_LOW);
    periodFPGA.byte[2] = FSMC_Read(RD_ADDR_PERIOD_MID);
    periodFPGA.byte[3] = FSMC_Read(RD_ADDR_PERIOD_HI);
    freq = 10e6 / (float)periodFPGA.word;
    readPeriod = false;
}

uint8 ReadFlag() {
    uint8 flag = FSMC_Read(RD_FL);
    if(!readPeriod) {
        if(_GET_BIT(flag, BIT_FREQ_READY)) {
            ReadFreq();
        }
    }
    if(readPeriod && _GET_BIT(flag, BIT_PERIOD_READY)) {
        ReadPeriod();
    }

    return flag;
}

float FPGA_GetFreq() {
    return freq;
}

void FPGA_ClearData() {
    for(int i = 0; i < FPGA_MAX_POINTS; i++) {
        dataRel0[i] = dataRel1[i] = 0;
    }
    timeClear = Timer_GetMS();
    countReads = 0;
}

bool FPGA_AllPointsRandomizer() {
    if(GetTBase() < TBase_100ns) {
        for(int i = 0; i < 281; i++) {
            if(dataRel0[i] == 0) {
                return false;
            }
        }
    }
    return true;
}

void InverseDataIsNecessary(Channel chan, uint8 *data) {
    if(IsChannelInverse(chan)) {
        for(int i = 0; i < FPGA_MAX_POINTS; i++) {
            data[i] = (uint8)((int)(2 * AVE_VALUE) - LimitationUInt8(data[i], MIN_VALUE, MAX_VALUE));
        }
    }
}

void ApplySmoothlyRange(Channel chan, uint8 *data) {
    if(IsSmoothlyRange(chan)) {
        float scale = GetSmoothlyRangeScale(chan);
        for(int i = 0; i < FPGA_MAX_POINTS; i++) {
            int point = (int)data[i] - AVE_VALUE;
            data[i] = LimitationUInt8(point * scale + AVE_VALUE, MIN_VALUE, MAX_VALUE);
        }
    }
}

void FPGA_SetNumberMeasuresForGates(int number) {
    numberMeasuresForGates = number;
}

void FPGA_StartAutoFind() {
	autoFindInProgress = true;
}

uint8 CalculateMin(Channel chan) {
    const uint8 *data = DS_GetData(chan, 0);
    int num = GetMemoryNumPoints(false);
    uint8 min = 255;
    for(int i = 0; i < num; i++) {
        if(data[i] < min) {
            min = data[i];
        }
    }
    return min;
}

uint8 CalculateMax(Channel chan) {
    const uint8 *data = DS_GetData(chan, 0);
    int num = GetMemoryNumPoints(false);
    uint8 max = 0;
    for(int i = 0; i < num; i++) {
        if(data[i] > max) {
            max = data[i];
        }
    }
    return max;
}

TBase CalculateTBase() {
    float freq = FPGA_GetFreq();
    if(freq > 50e6) {
        return TBase_2ns;
    } else if(freq > 40e6) {
        return TBase_5ns;
    } else if(freq > 20e6) {
        return TBase_10ns;
    } else if(freq > 10e6) {
        return TBase_20ns;
    } else if(freq > 3e6) {
        return TBase_50ns;
    } else if(freq > 1e6) {
        return TBase_100ns;
    } else if(freq > 700e3) {
        return TBase_200ns;
    } else if(freq > 300e3) {
        return TBase_500ns;
    } else if(freq > 100e3) {
        return TBase_1us;
    } else if(freq > 60e3) {
        return TBase_2us;
    } else if(freq > 30e3) {
        return TBase_5us;
    } else if(freq > 10e3) {
        return TBase_10us;
    } else if(freq > 5e3) {
        return TBase_20us;
    } else if(freq > 2e3) {
        return TBase_50us;
    } else if(freq > 1e3) {
        return TBase_100us;
    } else if(freq > 400) {
        return TBase_200us;
    } else if(freq > 150) {
        return TBase_500us;
    } else if(freq > 100) {
        return TBase_1ms;
    } else if(freq > 50) {
        return TBase_2ms;
    } else if(freq > 20) {
        return TBase_5ms;
    } else if(freq > 10) {
        return TBase_10ms;
    }
    return TBase_20ms;
}

bool FindWave(Channel chan) {
    FPGA_Stop(false);
    SetChannelEnable(chan, true);
    FPGA_SetRange(chan, Range_20V);
    FPGA_SetTrigSource((TrigSource)chan);
    FPGA_SetTrigLev((TrigSource)chan, TrigLevZero);
    FPGA_SetRShift(chan, RShiftZero);
    FPGA_SetModeCouple(chan, ModeCouple_AC);

    for(int i = RangeSize - 1; i >= 0; i--) {
        FPGA_SetRange(chan, (Range)i);
        FPGA_Start();
        while(!ProcessingData()) {};
        FPGA_Stop(false);

        if(CalculateMin(chan) < MIN_VALUE || CalculateMax(chan) > MAX_VALUE) {
            if(i < Range_20V) {
                i++;
            }
            FPGA_SetRange(chan, (Range)i);
            FPGA_SetTBase(CalculateTBase());
            FPGA_Start();
            while(!ProcessingData()) {};
            return true;
        }
    }

    return false;
}

void AutoFind() {
    FPGA_PeackDetEnable(true);
    FPGA_SetTBase(TBase_20ms);

    if(!FindWave(Chan0)) {
        FindWave(Chan1);
    }

    FPGA_PeackDetEnable(false);
    autoFindInProgress = false;
}

/** @} */


