#pragma once
#include "../defines.h"

bool ETHERNET_Init(void (*funcConnect)(int id), void (*funcReciever)(int id, const char *buffer, uint length));
bool ETHERNET_ProcessingInputBuffer(void);


