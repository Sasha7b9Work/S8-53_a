/// @file
 
#include "MenuItemsLogic.h"
#include "MenuFunctions.h"
#include "../Display/Display.h"
#include "../Display/DisplayDrawing.h"
#include "../Timer.h"
#include "../Log.h"
#include "../Settings/Settings.h"
#include "../Hardware/HAL.h"

/// ������������ ��� �������� ��������� �������� ItemChoice
typedef struct {
    ItemChoice* choice;             ///< ����� ItemChoice, ������� ��������� � ������ ������ � ��������. ���� 0 - ��� ��������.
    uint        timeStartMS;        ///< ����� ������ �������� choice.
} TimeStructChoice;

static TimeStructChoice tsChoice;

void Choice_StartIncrease(ItemChoice *choice) {
    if(!choice->funcOfActive) {
        choice->funcOnChanged(false);
    } else {
#ifdef DISPLAY_COLOR
        tsChoice.choice = choice;
        tsChoice.timeStartMS = Timer_GetMS();
#else
        Choice_Increase(choice);
#endif
    }
}

float Choice_StepIncrease(ItemChoice *choice) {
    static const float speed = 0.1f;
    if(tsChoice.choice == choice) {
        float delta = speed * (Timer_GetMS() - tsChoice.timeStartMS);
        if(delta == 0.0f) {
            return 0.001f;  // ������ � ��������� ������ ������ ����� ��������, ��� ������ 0 ��, �� �� ���������� ������� �����, ������ ��� ���� ����� �������� � ���, ��� �������� ���
        }
        if(delta > 12) {
            tsChoice.choice = 0;
            (*(choice->cell))++;
            if(*choice->cell > NumSubItems(choice) - 1) {
                *choice->cell = 0;
            }
            choice->funcOnChanged(choice->funcOfActive());
            Display_Redraw();
            return 0.0f;
        }
        return delta;
    }
    return 0.0f;
}

void Choice_Increase(ItemChoice *choice) {
    *choice->cell = (*choice->cell == NumSubItems(choice) - 1) ? 0 : (*choice->cell + 1);
    choice->funcOnChanged(choice->funcOfActive());
    Display_Redraw();
}

void Choice_Decrease(ItemChoice *choice) {
    *choice->cell = (*choice->cell == 0) ? (NumSubItems(choice) - 1) : (*choice->cell - 1);
    choice->funcOnChanged(choice->funcOfActive());
    Display_Redraw();
}

void Governor_StartIncrease(ItemGovernor *governor) {
#ifdef DISPLAY_COLOR
    if(governor->timeStruct->inMoveIncrease) {
        *governor->cell = Governor_NextValue(governor);
    } else {
        governor->timeStruct->timeStartMS = Timer_GetMS();
    }
    governor->timeStruct->inMoveIncrease = true;
    governor->timeStruct->inMoveDecrease = false;
#else
    *governor->cell = Governor_NextValue(governor);
    governor->funcOfChanged();
#endif
}

void Governor_StartDecrease(ItemGovernor *governor) {
#ifdef DISPLAY_COLOR
    if(governor->timeStruct->inMoveDecrease) {
        *governor->cell = Governor_PrevValue(governor);
    } else {
        governor->timeStruct->timeStartMS = Timer_GetMS();
    }
    governor->timeStruct->inMoveDecrease = true;
    governor->timeStruct->inMoveIncrease = false;
#else
    *governor->cell = Governor_PrevValue(governor);
    governor->funcOfChanged();
#endif
}

float Governor_Step(ItemGovernor *governor) {
    static const float speed = 0.05f;
    static const int numLines = 10;
    if(governor->timeStruct->inMoveDecrease)  {
        float delta = - speed * (Timer_GetMS() - governor->timeStruct->timeStartMS);
        if(delta == 0.0f) {
            return -0.001f;
        }
        if(delta < -numLines) {
            governor->timeStruct->inMoveDecrease = governor->timeStruct->inMoveIncrease = false;
            *governor->cell = Governor_PrevValue(governor);
            governor->funcOfChanged();
            return 0.0f;
        }
        return delta;
    }
    if(governor->timeStruct->inMoveIncrease) {
        float delta = speed * (Timer_GetMS() - governor->timeStruct->timeStartMS);
        if(delta == 0.0f) {
            return 0.001f;
        }
        if(delta > numLines) {
            governor->timeStruct->inMoveDecrease = governor->timeStruct->inMoveIncrease = false;
            *governor->cell = Governor_NextValue(governor);
            governor->funcOfChanged();
            return 0.0f;
        }
        return delta;
    }
    return 0.0f;
}

int16 Governor_NextValue(ItemGovernor *governor) {
    return (*governor->cell < governor->maxValue) ? *governor->cell + 1 : governor->minValue;
}

int16 Governor_PrevValue(ItemGovernor *governor) {
    return (*governor->cell > governor->minValue) ? *governor->cell - 1 : governor->maxValue;
}

void ItemTime_SetOpened(ItemTime *time) {
    *(time->seconds) = HAL_GetSeconds();
    *(time->minutes) = HAL_GetMinutes();
    *(time->hours) = HAL_GetHours();
    *(time->day) = HAL_GetDay();
    *(time->month) = HAL_GetMonth();
    *(time->year) = HAL_GetYear();
}

void ItemTime_SetNewTime(ItemTime *time) {

}

void ItemTime_SelectNextPosition(ItemTime *time) {
    CircleIncreaseInt8(time->curField, 0, 7);
    ResetFlash();
}

void ItemTime_IncCurrentPosition(ItemTime *time) {
    int max[] =   {0,          31,          12,      2099,          23,            59,            59};
    int min[] =   {0,          0,           0,       2000,           0,             0,             0};
    int *value[] = {0, time->day, time->month, time->year, time->hours, time->minutes, time->seconds};
    int position = *time->curField;
    if(position != iSET && position != iEXIT) {
        *(value[position]) = (*(value[position]))++;
        if(*value[position] > max[position]) {
            *value[position] = min[position];
        }
    }
}

void ItemTime_DecCurrentPosition(ItemTime *time) {
    int max[] = {0, 31, 12, 2099, 23, 59, 59};
    int min[] = {0,  0,  0, 2000,  0,  0,  0};
    int *value[] = {0, time->day, time->month, time->year, time->hours, time->minutes, time->seconds};
    int position = *time->curField;
    if(position != iSET && position != iEXIT) {
        (*(value[position]))--;
        if(*value[position] < min[position]) {
            *value[position] = max[position];
        }
    }
}

#ifdef DISPLAY_COLOR
void GovernorColor_Increase(ItemGovernorColor *governor) {
    ColorType *ct = governor->colorType;
    if(ct->currentField == 0) {
        ColorType_IncreaseBrightness(ct);
    } else {
        ColorType_IncreaseComponent(ct);
    }
    governor->funcOnChanged();
}

void GovernorColor_Decrease(ItemGovernorColor *governor) {
    ColorType *ct = governor->colorType;
    if(ct->currentField == 0) {
        ColorType_DecreaseBrightness(ct);
    } else {
        ColorType_DecreaseComponent(ct);
    }
    governor->funcOnChanged();
}
#endif
