/// @file

#include "../Panel/Controls.h"
#include "Settings/SettingsTypes.h"
#include "../Math/Measures.h"
#include "../Tables.h"
#include "MenuDrawing.h"
#include "MenuItemsGraphics.h"
#include "Menu.h"
#include "MenuFunctions.h"
#include "MenuItemsLogic.h"
#include "../Display/Display.h"
#include "../Display/DisplayDrawing.h"
#include "../Display/DisplayDrawingCol.h"
#include "../Display/Colors.h"
#include "../Settings/Settings.h"
#include "../Math/GlobalFunctions.h"
#include "../Math/Measures.h"
#include "../Timer.h"
#include "../Log.h"
#include "Pages/PageDisplay.h"

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static void DrawOpenedPage(Page *page, int layer, int yTop);
static void DrawTitlePage(Page *page, int layer, int yTop, int height, bool shade);
static void DrawItemsPage(Page *page, int layer, int yTop);
static void DrawPagesUGO(Page *page, int right, int bottom, Color color);
static void DrawSmallButtons(void);
static int  CalculateX(int layer);
static void ResetItemsUnderButton(void);
static int  ItemOpenedPosY(void *item);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static void *itemUnderButton[B_NumButtons] = {0};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
PanelButton GetFuncButtonFromY(int _y) {
    int y = GRID_TOP + GRID_HEIGHT / 12;
    int step = GRID_HEIGHT / 6;
    PanelButton button = B_Menu;
    for(int i = 0; i < 6; i++) {
        if(_y < y) {
            return button;
        }
        button++;
        y += step;
    }
    return  B_F5;
}

void Menu_Draw() {
    if(MenuIsShown() || TypeMenuItem(OpenedItem()) != TypeItem_Page) {
        ResetItemsUnderButton();
        if(MenuIsMinimize()) {
            DrawSmallButtons();
        } else {
            void *item = OpenedItem();
            if(MenuIsShown()) {
                if(TypeMenuItem(item) == TypeItem_Page) {
                    DrawOpenedPage(item, 0, GRID_TOP);
                } else {
                    DrawOpenedPage(Keeper(item), 0, GRID_TOP);
                }
            } else {
                if(TypeMenuItem(item) == TypeItem_Choice) {
                    ItemChoice_Draw(item, CalculateX(0), GridTop(), true);
                } else if(TypeMenuItem(item) == TypeItem_Governor) {
                    ItemGovernor_Draw(item, CalculateX(0), GridTop(), true);
                }
            }
        }
    }
}

void DrawOpenedPage(Page *page, int layer, int yTop) {
    DrawTitlePage(page, layer, yTop, HeightOpenedItem(page), CurrentItemIsOpened(Name(page)));
    DrawItemsPage(page, layer, yTop + MP_TITLE_HEIGHT);
    if(CurrentItemIsOpened(Name(page))) {
        int8 posCurItem = PosCurrentItem(page);
        void *item = Item(page, posCurItem);
        for(int i = 0; i < 5; i++) {
            if(itemUnderButton[i + B_F1] != item) {
                itemUnderButton[i + B_F1] = 0;
            }
        }
        TypeItem type = TypeMenuItem(item);
        if(type == TypeItem_Choice) {
            ItemChoice_Draw(item, CalculateX(1), ItemOpenedPosY(item), true);
        } else if(type == TypeItem_Governor) {
            ItemGovernor_Draw(item, CalculateX(1), ItemOpenedPosY(item), true);
        } else if(type == TypeItem_GovernorColor) {
#ifdef DISPLAY_COLOR
            GovernorColor_Draw(item, CalculateX(1), ItemOpenedPosY(item), true);
#endif
        } else if(type == TypeItem_Time) {
            ItemTime_Draw(item, CalculateX(1), ItemOpenedPosY(item), true);
        }
    }
}

void DrawTitlePage(Page *page, int layer, int yTop, int height, bool shade) {
    int x = CalculateX(layer);
    FillRegion(x - 1, yTop, MP_TITLE_WIDTH + 2, height + 2, ColorBack());
    DrawRectangle(x, yTop, MP_TITLE_WIDTH + 1, height + 1, ColorBorderMenu(shade));
    DrawVolumeButton(x + 1, yTop + 1, MP_TITLE_WIDTH - 1, MP_TITLE_HEIGHT - 1, shade ? 2 : 3, shade ? ColorMenuTitleLessBright() : ColorMenuTitle(false), 
        shade ? ColorMenuItemBrighter() : ColorMenuTitleBrighter(), shade ? ColorMenuItemLessBright() : ColorMenuTitleLessBright(), shade, false);

#ifdef DISPLAY_COLOR
    if(shade) {
        FillRegion(x + 4, yTop + 4, MP_TITLE_WIDTH - 7, MP_TITLE_HEIGHT - 7, CELL_BACK);
    }
#endif
    
    DrawVLine(x, yTop, yTop + HeightOpenedItem(page), ColorBorderMenu(false));
    int lengthText = LenghtText(TitleItem(page));
    bool condDrawRSet = NumSubPages(page) > 1 && TypeMenuItem(CurrentItem()) != TypeItem_Governor;
    int delta = condDrawRSet ? -10 : 0;
    Color colorText = shade ? LightShadingTextColor() : COLOR_BLACK;
    x = DrawStringInCenterRect(x, yTop, MP_TITLE_WIDTH + 2 + delta, MP_TITLE_HEIGHT, TitleItem(page), colorText, shade);
    if(condDrawRSet) {
        Draw4SymbolsInRect(x + 4, yTop + 11, GetSymbolForGovernor(NumCurrentSubPage(page)), colorText);
    }

    itemUnderButton[GetFuncButtonFromY(yTop)] = page;

#ifdef DISPLAY_COLOR
    delta = 0;
#else
    delta = -2;
#endif
    
    DrawPagesUGO(page, CalculateX(layer) + MP_TITLE_WIDTH - 3 + delta, yTop + MP_TITLE_HEIGHT - 2 + delta, colorText);
}

void DrawPagesUGO(Page *page, int right, int bottom, Color color) {
    int size = 4;
    int delta = 2;
    
    int allPages = ( NumItemsInPage(page)- 1) / MENU_ITEMS_ON_DISPLAY + 1;
    int currentPage = NumCurrentSubPage(page);

    int left = right - (size + 1) * allPages - delta + (3 - allPages);
    int top = bottom - size - delta;

    for(int p = 0; p < allPages; p++) {
        int x = left + p * (size + 2);
        if(p == currentPage) {
            FillRegion(x, top, size, size, color);
        } else {
            DrawRectangle(x, top, size, size, color);
        }
    }
}

static void DrawGovernor(void* item, int x, int y) {
    ItemGovernor_Draw(item, x, y, false);
}

static void DrawChoice(void *item, int x, int y) {
    ItemChoice_Draw(item, x, y, false);
}

static void DrawTime(void *item, int x, int y) {
    ItemTime_Draw(item, x, y, false);
}

#ifdef DISPLAY_COLOR
static void DrawGovernorColor(void *item, int x, int y) {
    GovernorColor_Draw(item, x, y, false);
}
#endif

static void DrawButton(void *item, int x, int y) {
    ItemButton_Draw(item, x, y);
}

static void DrawPage(void *item, int x, int y) {
    ItemPage_Draw(item, x, y);
}

void DrawItemsPage(Page *page, int layer, int yTop) {
    void (*funcOfDraw[TypeItem_NumberItems])(void*, int, int) = {  
        EmptyFuncpVII,
        DrawChoice,
        DrawButton,
        DrawPage,
        DrawGovernor,
        DrawTime,
        EmptyFuncpVII,
        EmptyFuncpVII,
#ifdef DISPLAY_COLOR
        DrawGovernorColor
#else
        EmptyFuncpVII
#endif
        };
    int8 posFirstItem = PosItemOnTop(page);
    int8 posLastItem = LimitationInt(posFirstItem + MENU_ITEMS_ON_DISPLAY - 1, 0, NumItemsInPage(page) - 1);
    int count = 0;
    for(int8 posItem = posFirstItem; posItem <= posLastItem; posItem++) {
        TypeItem type = TypeMenuItem(Item(page, posItem));
        int top = yTop + MI_HEIGHT * count;
        funcOfDraw[type](Item(page, posItem), CalculateX(layer), top);
        count++;
        itemUnderButton[GetFuncButtonFromY(top)] = Item(page, posItem);
    }
}

void DrawSmallButtons() {
    int x = 299;
    int y0 = GridTop() + 7;
    int dY = MI_HEIGHT;
    int width = 19;
    for(int i = 0; i < 6; i++) {
        const SmallButton *button = GetSmallButton((PanelButton)(i + B_Menu));
        if(button != 0) {
            DrawRectangle(x, y0 + dY * i, width, width, ColorFill());
            button->funcOnDraw(x, y0 + dY * i);
        }
    }
}

int CalculateX(int layer) {
    return MP_X - layer * GRID_DELTA / 4 + (GridSizeChanged() && MenuIsShown() ? 80 : 0);
}

bool IsShade(void* item) {
    return CurrentItemIsOpened(Name(Keeper(item))) && (item != OpenedItem());
}

bool IsPressed(void* item) {
    return item == Menu_ItemUnderKey();
}

void* ItemUnderButton(PanelButton button) {
    return itemUnderButton[button];
}

void ResetItemsUnderButton() {
    for(int i = 0; i < B_NumButtons; i++) {
        itemUnderButton[i] = 0;
    }
}

int ItemOpenedPosY(void *item) {
    Page *page = Keeper(item);
    int8 posCurItem = PosCurrentItem(page);
    int y = GRID_TOP + (posCurItem % MENU_ITEMS_ON_DISPLAY) * MI_HEIGHT + MP_TITLE_HEIGHT;
    if(y + HeightOpenedItem(item) > GRID_BOTTOM) {
        y = GRID_BOTTOM - HeightOpenedItem(item) - 2;
    }
    return y + 1;
}

