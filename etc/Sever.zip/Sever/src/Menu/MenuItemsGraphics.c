// @file

#include "MenuItemsGraphics.h"
#include "MenuDrawing.h"
#include "MenuFunctions.h"
#include "MenuItemsLogic.h"
#include "Menu.h"
#include "../Hardware/HAL.h"
#include "../Display/DisplayDrawing.h"
#include "../Display/Colors.h"
#include "../Display/Display.h"
#include "../Display/DisplayDrawingCol.h"
#include "../Settings/Settings.h"
#include "../Math/GlobalFunctions.h"
#include "../Log.h"

#ifdef DISPLAY_COLOR
#include "Pages/PageDisplay.h"
#endif

#include <string.h>

void DrawGovernorChoiceColorHiPart(void *item, int x, int y, bool pressed, bool shade, bool opened) {

    int delta = pressed && !shade ? 1 : 0;

    int width = MI_WIDTH_VALUE;

#ifdef DISPLAY_COLOR
    Color color = shade ? ColorMenuTitleLessBright() : COLOR_WHITE;
    int dHeight = 0;
    DrawHLine(y + 1, x, x + width + 3, ColorBorderMenu(false));
    DrawVolumeButton(x + 1, y + 2, width + 2, MI_HEIGHT_VALUE + 3 + dHeight, 2, ColorMenuItem(false), 
        ColorMenuItemBrighter(), ColorMenuItemLessBright(), pressed, shade);
#else
    Color color = ColorFill();
    delta++;
    int dHeight = 2;
    if(shade) {
        DrawRectangle(x + 2, y + 3, width, MI_HEIGHT_VALUE + 1 + dHeight, ColorFill());
        FillRegion(x + 4, y + 5, width - 3, MI_HEIGHT_VALUE - 2 + dHeight, CELL_FILL);
    } else {
        DrawVolumeButton(x + 1, y + 2, width + 2, MI_HEIGHT_VALUE + 3 + dHeight, 2, ColorMenuItem(false), 
            ColorMenuItemBrighter(), ColorMenuItemLessBright(), pressed, shade);
    }
#endif

    Display_DrawText(x + 6 + delta, y + 6 + delta, TitleItem(item), color);
}

void DrawGovernorLowPart(ItemGovernor *governor, int x, int y, bool pressed, bool shade) {

    int enterX = x;
    Color colorTextDown = ColorBack();

#ifdef DISPLAY_COLOR
    DrawVolumeButton(x + 1, y + 17, MI_WIDTH_VALUE + 2, MI_HEIGHT_VALUE + 3, 2, ColorMenuField(), 
        ColorMenuItemBrighter(), ColorMenuItemLessBright(), true, shade);
    if(shade) {
        colorTextDown = ColorMenuItem(false);
    }
#else
    FillRegion(x + 2, y + 19, MI_WIDTH_VALUE, MI_HEIGHT_VALUE, (shade || !governor->funcOfActive()) ? CELL_FILL : COLOR_BLACK);
#endif

    x = Display_DrawText(x + 4, y + 21, "\x80", colorTextDown);
    if(OpenedItem() != governor) {
        float delta = Governor_Step(governor);
        if(delta == 0.0f) {
            x = Display_DrawText(x + 1, y + 21, Int2String(*(governor->cell), false, 1), colorTextDown);
        } else {
#ifdef DISPLAY_COLOR
            int drawX = x + 1;
            int limX = x + 1;
            int limY = y + 19;
            int limWidth = MI_WIDTH_VALUE;
            int limHeight = MI_HEIGHT_VALUE - 1;
            if(delta > 0.0f) {
                x = DrawTextWithLimitation(drawX, y + 21 - delta, Int2String(*(governor->cell), false, 1), 
                                            ColorBack(), limX, limY, limWidth, limHeight);
                DrawTextWithLimitation(drawX, y + 21 + 10 - delta, Int2String(Governor_NextValue(governor), false, 1),
                                            ColorBack(), limX, limY, limWidth, limHeight);
            }
            if(delta < 0.0f) {
                x = DrawTextWithLimitation(drawX, y + 21 - delta, Int2String(*(governor->cell), false, 1), 
                                            ColorBack(), limX, limY, limWidth, limHeight);
                DrawTextWithLimitation(drawX, y + 21 - 10 - delta, Int2String(Governor_PrevValue(governor), false, 1),
                    ColorBack(), limX, limY, limWidth, limHeight);
            }
#endif
        }
    } else {
        x = Display_DrawText(x + 1, y + 21, Int2String(*(governor->cell), false, 1), ColorFill());
    }
    x = Display_DrawText(x + 1, y + 21, "\x81", colorTextDown);
    if(CurrentItem() == governor) {
        Draw4SymbolsInRect(enterX + MI_WIDTH - 14, y + 20, GetSymbolForGovernor(*(governor->cell)), colorTextDown);
    }
}

void Governor_DrawClosed(ItemGovernor *governor, int x, int y) {
    bool pressed = IsPressed(governor);
    bool shade = IsShade(governor) || !ItemIsAcitve(governor);
    DrawGovernorLowPart(governor, x, y, pressed, shade);
    DrawGovernorChoiceColorHiPart(governor, x, y, pressed, shade, false);
}

void DrawGovernorValue(int x, int y, ItemGovernor *governor) {
    static const int dX = 6;
    int startX = x + 40;
    int16 value = *governor->cell;
    int signGovernor = *governor->cell < 0 ? -1 : 1;
    if(signGovernor == -1) {
        value = -value;
    }
    SetFont(TypeFont_5);
    bool sign = governor->minValue < 0;
    Display_DrawText(x + 55, y - 5, Int2String(governor->maxValue, sign, 1), COLOR_BLACK);
    Display_DrawText(x + 55, y + 2, Int2String(governor->minValue, sign, 1), COLOR_BLACK);
    SetFont(TypeFont_8);
    for(int i = 0; i < NumDigitsInGovernor(governor); i++) {
        int16 rest = value % 10;
        value /= 10;
        if(*governor->curDigit == i) {
            FillRegion(startX - 1, y, 5, 9, COLOR_BLACK);
        }
        if(!(rest == 0 && value == 0) || (*governor->cell == 0 && i == 0)) {
            Display_DrawChar(startX, y, rest + 48, *governor->curDigit == i ? COLOR_WHITE : COLOR_BLACK);
        }
        Display_DrawLine(startX, y + 9, startX + 3, y + 9, COLOR_BLACK);
        startX -= dX;
    }

    if(sign) {
        Display_DrawChar(startX - 1, y, signGovernor < 0 ? '\x9b' : '\x9a', COLOR_BLACK);
    }
}

void Governor_DrawOpened(ItemGovernor *governor, int x, int y) {
    FillRegion(x - 1, y - 1, MI_WIDTH + 2, MI_HEIGHT + 2, COLOR_WHITE);
    DrawRectangle(x , y, MI_WIDTH, MI_HEIGHT, COLOR_BLACK);
    Display_DrawLine(x, y + MI_HEIGHT / 2, x + MI_WIDTH, y + MI_HEIGHT / 2, COLOR_BLACK);
    DrawStringInCenterRect(x, y + 1, MI_WIDTH, MI_HEIGHT / 2, TitleItem(governor), COLOR_BLACK, false);
    DrawGovernorValue(x, y + 20, governor);
}

void ItemGovernor_Draw(ItemGovernor *governor, int x, int y, bool opened) {
    if(opened) {
        Governor_DrawOpened(governor, x, y);
    } else {
        Governor_DrawClosed(governor, x, y);
    }
}

#ifdef DISPLAY_COLOR
void DrawGovernorColorValue(int x, int y, ItemGovernorColor *govColor, int delta) {
    ColorType *ct = govColor->colorType;
    int8 field = ct->currentField;
    char *texts[4] = {"��", "��", "��", "��"};
    uint16 color = GetColorValue(ct->color);
    int red = R_FROM_COLOR(color);
    int green = G_FROM_COLOR(color);
    int blue = B_FROM_COLOR(color);
    if(!ct->alreadyUsed) {
        ColorType_Init(ct);
    }

    int16 vals[4] = {ct->brightness * 100, blue, green, red};

    FillRegion(x, y, MI_WIDTH + delta - 2, MI_HEIGHT / 2 - 3, COLOR_BLACK);
    x += 92;
    
    for(int i = 0; i < 4; i++) {
        Color colorBack = (field == i) ? COLOR_WHITE : COLOR_BLACK;
        Color colorDraw = (field == i) ? COLOR_BLACK : COLOR_WHITE;
        FillRegion(x - 1, y + 1, 29, 10, colorBack);
        Display_DrawText(x, y + 2, texts[i], colorDraw);
        Display_DrawText(x + 14, y + 2, Int2String(vals[i], false, 1), colorDraw);
        x -= 30;
    }
    
}

void GovernorColor_DrawOpened(ItemGovernorColor *gov, int x, int y) {
    static const int delta = 43;
    x -= delta;
    ColorType_Init(gov->colorType);
    DrawRectangle(x - 1, y - 1, MI_WIDTH + delta + 2, MI_HEIGHT + 2, COLOR_BLACK);
    DrawRectangle(x, y, MI_WIDTH + delta, MI_HEIGHT, ColorMenuTitle(false));
    DrawVolumeButton(x + 1, y + 1, MI_WIDTH_VALUE + 2 + delta, MI_HEIGHT_VALUE + 3, 2, ColorMenuItem(false), 
        ColorMenuItemBrighter(), ColorMenuItemLessBright(), IsPressed(gov), IsShade(gov));
    DrawHLine(y + MI_HEIGHT / 2 + 2, x, x + MI_WIDTH + delta, ColorMenuTitle(false));
    DrawStringInCenterRect(x + (IsPressed(gov) ? 2 : 1), y + (IsPressed(gov) ? 2 : 1), MI_WIDTH + delta, MI_HEIGHT / 2 + 2, TitleItem(gov), COLOR_WHITE, false);
    DrawGovernorColorValue(x + 1, y + 19, gov, delta);
}

void GovernorColor_DrawClosed(ItemGovernorColor *gov, int x, int y) {
    ColorType_Init(gov->colorType);
    DrawGovernorChoiceColorHiPart(gov, x, y, IsPressed(gov), IsShade(gov) || !ItemIsAcitve(gov), true);
    FillRegion(x + 2, y + 20, MI_WIDTH_VALUE, MI_HEIGHT_VALUE - 1, gov->colorType->color);
}

void GovernorColor_Draw(ItemGovernorColor *govColor, int x, int y, bool opened) {
    if(opened) {
        GovernorColor_DrawOpened(govColor, x, y);
    } else {
        GovernorColor_DrawClosed(govColor, x, y);
    }
}
#endif

void Choice_DrawOpened(ItemChoice *choice, int x, int y) {
    int height = HeightOpenedItem(choice);

#ifdef DISPLAY_COLOR
    DrawRectangle(x - 1, y - 1, MP_TITLE_WIDTH + 2, height + 3, ColorBack());
    int dY = 0;
#else
    FillRegion(x - 2, y - 1, MP_TITLE_WIDTH + 3, height + 3, ColorBack());
    int dY = 1;
#endif
    
    DrawGovernorChoiceColorHiPart(choice, x - 1, y - 1, IsPressed(choice), false, true);
    DrawRectangle(x - 1, y, MP_TITLE_WIDTH + 1, height + 1, ColorMenuTitle(false));
 
    Draw4SymbolsInRect(x + MI_WIDTH - 15, y + 4 + dY, GetSymbolForGovernor(*choice->cell), ColorFill());
#ifdef DISPLAY_COLOR
    DrawHLine(y + MOI_HEIGHT_TITLE - 1, x, x + MOI_WIDTH, ColorMenuTitle(false));
    DrawVolumeButton(x + 1, y + MOI_HEIGHT_TITLE, MOI_WIDTH - 2, height - MOI_HEIGHT_TITLE, 1, COLOR_BLACK, ColorMenuTitleBrighter(),
                        ColorMenuTitleLessBright(), false, false);
    int index = *((int8*)choice->cell);
    for(int i = 0; i < NumSubItems(choice); i++) {
        int yItem = y + MOI_HEIGHT_TITLE + i * MOSI_HEIGHT + 1;
        bool pressed = i == index;
        if(pressed) {
            DrawVolumeButton(x + 1, yItem, MOI_WIDTH - 2 , MOSI_HEIGHT - 2, 2, ColorMenuField(), ColorMenuTitleBrighter(),
                ColorMenuTitleLessBright(), pressed, false);
        }
        Display_DrawText(x + 4, yItem + 2, NameSubItem(choice, i), pressed ? COLOR_BLACK : ColorMenuField());
    }
#else
    DrawHLine(y + MOI_HEIGHT_TITLE + 1, x, x + MOI_WIDTH, ColorFill());
    for(int i = 0; i < NumSubItems(choice); i++) {
        bool pressed = i == (*((int8*)choice->cell));
        int yItem = y + MOI_HEIGHT_TITLE + i * (MOSI_HEIGHT - 4) + 3;
        Color color = ColorFill();
        if(pressed) {
            FillRegion(x + 1, yItem, MOI_WIDTH - 3, MOSI_HEIGHT - 6, ColorFill());
            color = ColorBack();
        }
        Display_DrawText(x + 3, yItem, NameSubItem(choice, i), color);
    }
#endif
}

void ItemChoice_DrawClosed(ItemChoice *choice, int x, int y) {
    bool pressed = IsPressed(choice);
    bool shade = IsShade(choice) || ! choice->funcOfActive();
        
#ifdef DISPLAY_COLOR
    DrawVolumeButton(x + 1, y + 17, MI_WIDTH_VALUE + 2, MI_HEIGHT_VALUE + 3, 2, shade ? ColorMenuTitleLessBright() : ColorMenuField(), 
        ColorMenuItemBrighter(), ColorMenuItemLessBright(), true, shade);
    int delta = 0;
#else
    if(shade) {
        FillRegion(x + 2, y + 21, MI_WIDTH_VALUE + 1, MI_HEIGHT_VALUE + 1, CELL_BACK);
    } else {
        FillRegion(x + 2, y + 21, MI_WIDTH_VALUE, MI_HEIGHT_VALUE - 2, ColorFill());
    }
    int delta = 1;
#endif

    float deltaY = Choice_StepIncrease(choice);
    Color colorText = shade ? LightShadingTextColor() : ColorBack();
    if(deltaY == 0.0f) {
        Display_DrawText(x + 4, y + 21 + delta, NameCurrentSubItem(choice), colorText);
    } else {
#ifdef DISPLAY_COLOR
        DrawTextWithLimitation(x + 4, y + 21 - deltaY + delta, NameCurrentSubItem(choice), colorText, x, y + 19, MI_WIDTH_VALUE, MI_HEIGHT_VALUE - 1);
        DrawTextWithLimitation(x + 4, y + 21 + 12 - deltaY + delta, NameNextSubItem(choice), colorText, x, y + 19, MI_WIDTH_VALUE, MI_HEIGHT_VALUE - 1);
        DrawHLine(y + 31 - deltaY, x + 3, x + MI_WIDTH_VALUE + 1, COLOR_BLACK);
#endif
    }
#ifdef DISPLAY_COLOR
    DrawHLine(y + MI_HEIGHT + 1, x, x + MI_WIDTH, ColorBorderMenu(false));
#endif

    if(choice->funcForDraw) {
        choice->funcForDraw(x, y);
    }
    DrawGovernorChoiceColorHiPart(choice, x, y, pressed, shade, false);
}

void ItemChoice_Draw(ItemChoice *choice, int x, int y, bool opened) {
    if(opened) {
        Choice_DrawOpened(choice, x, y);
    } else {
        ItemChoice_DrawClosed(choice, x, y);
    }
}

void ItemTime_DrawOpened(ItemTime *time, int x, int y) {
    int width = MI_WIDTH_VALUE + 3;
    int height = 60;
#ifdef DISPLAY_COLOR
    DrawRectangle(x - 1, y - 1, width + 2, height + 3, ColorBack());
#else
    FillRegion(x - 2, y - 1, width + 3, height + 3, ColorBack());
#endif
    DrawGovernorChoiceColorHiPart(time, x - 1, y - 1, IsPressed(time), false, true);

    DrawRectangle(x - 1, y, width + 1, height + 1, ColorFill());

    int y0 = 20;
    int y1 = 30;
    int y2 = 40;
    int y3 = 50;

    int x0 = 3;
    int dX = 13;
    int wS = 10;

    struct StructPaint {
        int x;
        int y;
        int width;
    } strPaint[8] = {
        {x0,            y3, 60},    // �� ���������
        {x0,            y0, wS},    // ����
        {x0 + dX,       y0, wS},    // �����
        {x0 + 2 * dX,   y0, 20},    // ���
        {x0,            y1, wS},    // ����
        {x0 + dX,       y1, wS},    // ���
        {x0 + 2 * dX,   y1, wS},    // ���
        {x0,            y2, 46}     // ���������
    };

    char strI[8][20];
    strcpy(strI[iEXIT], "�� ���������");
    strcpy(strI[iDAY], Int2String(*time->day, false, 1));
    strcpy(strI[iMONTH], Int2String(*time->month, false, 1));
    strcpy(strI[iYEAR], Int2String(*time->year, false, 1));
    strcpy(strI[iHOURS], Int2String(*time->hours, false, 1));
    strcpy(strI[iMIN], Int2String(*time->minutes, false, 1));
    strcpy(strI[iSEC], Int2String(*time->seconds, false, 1));

    strcpy(strI[iSET], "���������");

    for(int i = 0; i < 8; i++) {
        if(*time->curField == i) {
            FillRegion(x + strPaint[i].x - 1, y + strPaint[i].y, strPaint[i].width, 8, FLASH_10);
            Display_DrawText(x + strPaint[i].x, y + strPaint[i].y, strI[i], FLASH_01);
        } else {
            Display_DrawText(x + strPaint[i].x, y + strPaint[i].y, strI[i], ColorFill());
        }
    }
}

void ItemTime_DrawClosed(ItemTime *time, int x, int y) {
    bool pressed = IsPressed(time);
    bool shade = IsShade(time);
    DrawGovernorChoiceColorHiPart(time, x, y, pressed, shade, false);

#ifdef DISPLAY_COLOR
    DrawVolumeButton(x + 1, y + 17, MI_WIDTH_VALUE + 2, MI_HEIGHT_VALUE + 3, 2, shade ? ColorMenuTitleLessBright() : ColorMenuField(), 
        ColorMenuItemBrighter(), ColorMenuItemLessBright(), true, shade);
    //int delta = 0;
#else
    if(shade) {
        FillRegion(x + 2, y + 21, MI_WIDTH_VALUE + 1, MI_HEIGHT_VALUE + 1, CELL_BACK);
    } else {
        FillRegion(x + 2, y + 21, MI_WIDTH_VALUE, MI_HEIGHT_VALUE - 2, ColorFill());
    }
    //int delta = 1;
#endif

    int deltaField = 10;
    int deltaSeparator = 2;
    int startX = 3;
    y += 22;
    Display_DrawText(x + startX, y, Int2String(HAL_GetHours(), false, 2), ColorBack());
    Display_DrawText(x + startX + deltaField, y, ":", ColorBack());
    Display_DrawText(x + startX + deltaField + deltaSeparator, y, Int2String(HAL_GetMinutes(), false, 2), ColorBack());
    Display_DrawText(x + startX + 2 * deltaField + deltaSeparator, y, ":", ColorBack());
    Display_DrawText(x + startX + 2 * deltaField + 2 * deltaSeparator, y, Int2String(HAL_GetSeconds(), false, 2), ColorBack());

    startX = 45;
    Display_DrawText(x + startX, y, Int2String(HAL_GetDay(), false, 2), ColorBack());
    Display_DrawText(x + startX + deltaField, y, ":", ColorBack());
    Display_DrawText(x + startX + deltaField + deltaSeparator, y, Int2String(HAL_GetMonth(), false, 2), ColorBack());
    Display_DrawText(x + startX + 2 * deltaField + deltaSeparator, y, ":", ColorBack());
    Display_DrawText(x + startX + 2 * deltaField + 2 * deltaSeparator, y, Int2String(HAL_GetYear() - 2000, false, 2), ColorBack());
}

void ItemTime_Draw(ItemTime *time, int x, int y, bool opened) {
    if(opened) {
        ItemTime_DrawOpened(time, x, y);
    } else {
        ItemTime_DrawClosed(time, x, y);
    }
}

void ItemButton_Draw(ItemButton *button, int x, int y) {
    bool pressed = IsPressed(button);
    bool shade = IsShade(button) || !ItemIsAcitve(button);

#ifdef DISPLAY_COLOR
    DrawHLine(y + 1, x, x + MI_WIDTH, ColorMenuTitle(shade));
    Color color = shade ? COLOR_MENU_SHADOW : COLOR_WHITE;
    FillRegion(x + 1, y + 2, MI_WIDTH - 2, MI_HEIGHT - 2, ColorMenuItem(false));
    DrawVolumeButton(x + 4, y + 5, MI_WIDTH - 8, MI_HEIGHT - 8, 3, ColorMenuItem(false), ColorMenuItemBrighter(), 
                            ColorMenuItemLessBright(), pressed, shade);
#else
    if(shade) {
        FillRegion(x + 2, y + 3, MI_WIDTH - 3, MI_HEIGHT - 3, CELL_FILL);
    }
    Color color = shade ? LightShadingTextColor() : COLOR_BLACK;
    DrawVolumeButton(x + 2, y + 3, MI_WIDTH - 4, MI_HEIGHT - 4, 4, shade ? ColorMenuTitleLessBright() : ColorMenuItem(shade), ColorMenuItemBrighter(), 
        ColorMenuItemLessBright(), pressed, shade);
#endif

    int delta = (pressed && (!shade)) ? 2 : 1;
    
    DrawStringInCenterRect(x + delta, y + delta, MI_WIDTH, MI_HEIGHT, TitleItem(button), color,  false);
}

void ItemPage_Draw(Page *page, int x, int y) {
    bool isShade = IsShade(page) || !ItemIsAcitve(page);
    bool isPressed = IsPressed(page);
#ifdef DISPLAY_COLOR
    DrawHLine(y + 1, x, x + MI_WIDTH, ColorBorderMenu(false));
#else
    if(isShade) {
        FillRegion(x + 2, y + 3, MI_WIDTH - 3, MI_HEIGHT - 2, CELL_FILL);
    }
#endif
    DrawVolumeButton(x + 1, y + 2, MI_WIDTH - 2, MI_HEIGHT - 2, 2, isShade ? ColorMenuTitleLessBright() : ColorMenuItem(isShade), ColorMenuItemBrighter(), 
                        ColorMenuItemLessBright(), isPressed, isShade);
    Color colorText = isShade ? LightShadingTextColor() : COLOR_BLACK;
    int delta = 0;
    if(isPressed && (!isShade)) {
        colorText = ColorFill();
        delta = 1;
    }
    DrawStringInCenterRect(x + delta, y + delta, MI_WIDTH, MI_HEIGHT, TitleItem(page), colorText, IsShade(page));
}
