/// @file

#pragma once

#include "MenuItems.h"

#ifdef DISPLAY_COLOR
void GovernorColor_Draw(ItemGovernorColor *govColor, int x, int y, bool opened);
#endif

void ItemGovernor_Draw(ItemGovernor *governor, int x, int y, bool opened);
void ItemChoice_Draw(ItemChoice *choice, int x, int y, bool opened);
void ItemButton_Draw(ItemButton *button, int x, int y);
void ItemPage_Draw(Page *page, int x, int y);
void ItemTime_Draw(ItemTime *time, int x, int y, bool opened);
