#pragma once

void HelpContent_Init(int x, int y, int width, int height);
void HelpContent_Draw(void);
void HelpContent_RegSetLeft(void);
void HelpContent_RegSetRight(void);
void HelpContent_ButtonMenuDown(void);
void HelpContent_ButtonMenuUp(void);
void HelpContent_Button1Down(void);
void HelpContent_Button1Up(void);
void HelpContent_Button2Down(void);
void HelpContent_Button2Up(void);
void HelpContent_Button3Down(void);
void HelpContent_Button3Up(void);
void HelpContent_Button4Dow(void);
void HelpContent_Button4Up(void);
void HelpContent_Button5Down(void);
void HelpContent_Button5Up(void);
