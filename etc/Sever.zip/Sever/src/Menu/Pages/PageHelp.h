#pragma once

bool Help_IsShown(void);
void Help_ExitFromShown(void);
