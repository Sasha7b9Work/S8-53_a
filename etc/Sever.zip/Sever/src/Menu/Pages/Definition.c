/// @file

#include "../defines.h"
#include "../Settings/SettingsTypes.h"
#include "PageMemory.h"
#include "../FPGA/FPGA.h"
#include "../Display/Colors.h"
#include "../Display/Display.h"
#include "../Display/DisplayDrawing.h"
#include "../../Settings/Settings.h"
#include "PageHelp.h"

extern ItemChoice mcCursorsSource;
extern ItemChoice mcCursorsU;
extern ItemChoice mcCursorsT;
extern Settings set;

/** @addtogroup MENU_SMALL_BUTTON
    @{ */

void CalculateConditions(int16 pos0, int16 pos1, CursCntrl cursCntrl, bool *cond0, bool *cond1) {
    bool zeroLessFirst = pos0 < pos1;
    *cond0 = cursCntrl == CursCntrl_1_2 || (cursCntrl == CursCntrl_1 && zeroLessFirst) || (cursCntrl == CursCntrl_2 && !zeroLessFirst);
    *cond1 = cursCntrl == CursCntrl_1_2 || (cursCntrl == CursCntrl_1 && !zeroLessFirst) || (cursCntrl == CursCntrl_2 && zeroLessFirst);
}

/** @} */

int CalculateYforCurs(int y, bool top) {
    return top ? y + MI_HEIGHT / 2 + 4 : y + MI_HEIGHT - 2;
}

int CalculateXforCurs(int x, bool left) {
    return left ? x + MI_WIDTH - 20 : x + MI_WIDTH - 5;
}

void CalculateXY(int *x0, int *x1, int *y0, int *y1) {
    *x0 = CalculateXforCurs(*x0, true);
    *x1 = CalculateXforCurs(*x1, false);
    *y0 = CalculateYforCurs(*y0, true);
    *y1 = CalculateYforCurs(*y1, false);
}

void DrawMenuCursTime(int x, int y, bool left, bool right) {
    int x0 = x, x1 = x, y0 = y, y1 = y;
    CalculateXY(&x0, &x1, &y0, &y1);
    for(int i = 0; i < (left ? 3 : 1); i++) {
        DrawVLine(x0 + i, y0, y1, MenuIsMinimize() ? ColorFill() : ColorBack());
    }
    for(int i = 0; i < (right ? 3 : 1); i++) {
        DrawVLine(x1 - i, y0, y1, MenuIsMinimize() ? ColorFill() : ColorBack());
    }
}

void DrawMenuCursVoltage(int x, int y, bool top, bool bottom) {
    int x0 = x, x1 = x, y0 = y, y1 = y;
    CalculateXY(&x0, &x1, &y0, &y1);
    for(int i = 0; i < (top ? 3 : 1); i++) {
        DrawHLine(y0 + i, x0, x1, MenuIsMinimize() ? ColorFill() : ColorBack());
    }
    for(int i = 0; i < (bottom ? 3 : 1); i++) {
        DrawHLine(y1 - i, x0, x1, MenuIsMinimize() ? ColorFill() : ColorBack());
    }
}

/** @defgroup MENU ����
    @{ */

/** @} */

/** @defgroup MENU_SMALL_BUTTONS ��������� ������
    @ingroup MENU
    @{ */

bool runningFPGAbeforeSmallButtons = false;                      ///< ����� ����������� ���������� � ���, �������� �� ���� ����� ��������� � ����� ������ � �������.

void PressSmallButtonExit() {
    TypePageSB sbPage = GetMenuSmallButtonPage();
    if(sbPage == TypePageSB_MemInt || sbPage == TypePageSB_MemLatest) {   // ��� ������� ������ � ������� ����� �� ������ ����� ������ �������� ����������� � ����� ���������� ���������
        SetMemoryModeWork(ModeWork_Direct);
        if(runningFPGAbeforeSmallButtons) {
            FPGA_Start();
            runningFPGAbeforeSmallButtons = false;
        }
    } else if (sbPage == TypePageSB_Help) {
        Help_ExitFromShown();
    }

    Display_RemoveAddDrawFunction();

    SetPageSB(0);
}

void DrawSmallButtonExit(int x, int y) {
    SetFont(TypeFont_UGO2);
    Draw4SymbolsInRect(x + 2, y + 1, '\x2e', ColorFill());
    SetFont(TypeFont_8);
}
                                                                                                                
const SmallButton sbExit = {DrawSmallButtonExit, PressSmallButtonExit};                                                     ///< ����� �� ������ ����� ������.

/** @} */

const Page mainPage;

//#include "PageTrig.c"
//#include "PageTime.c"
#include "PageHelp.c"

extern const Page mpDisplay;
extern const Page mpCursors;
extern const Page mpChan0;
extern const Page mpChan1;
extern const Page mpMemory;
extern const Page mpMeasures;
extern const Page mpDebug;
extern const Page mpService;
extern const Page mpTime;
extern const Page mpTrig;

/** @defgroup MENU_ON_DISPLAY �������� ����
    @ingroup MENU
    @{ */

/// ���� 
const Page mainPage = {TypeItem_Page, 0, {"����", "MENU"}, "mainPage", "", TypePage_MainPage, EmptyFuncBV,
    {
        (void*)&mpDisplay,
        (void*)&mpChan0,
        (void*)&mpChan1,
        (void*)&mpTrig,
        (void*)&mpTime,
        (void*)&mpCursors,
        (void*)&mpMemory,
        (void*)&mpMeasures,
        (void*)&mpService,
        (void*)&mpHelp,
        (void*)&mpDebug
    }
};
/** @} */

const void *PageForButton(PanelButton button) {
    static const void *pages[] = {  
        0,                  // B_Empty
        (void*)&mpChan0,    // B_Channel0
        (void*)&mpService,  // B_Service
        (void*)&mpChan1,    // B_Channel1
        (void*)&mpDisplay,  // B_Display
        (void*)&mpTime,     // B_Time
        (void*)&mpMemory,   // B_Memory
        (void*)&mpTrig,     // B_Trig
        0,                  // B_Start
        (void*)&mpCursors,  // B_Cursors
        (void*)&mpMeasures, // B_Measures
        0,                  // B_Power
        0,                  // B_Help
        0,                  // B_Menu
        0,                  // B_F1
        0,                  // B_F2
        0,                  // B_F3
        0,                  // B_F4
        0,                  // B_F5
    };

    return pages[button];
}

bool IsMainPage(void *item) {
    return item == &mainPage;
}

const char* NameItemMenu(const void *address) {

    return ((Page*)address)->nameStruct;
}
