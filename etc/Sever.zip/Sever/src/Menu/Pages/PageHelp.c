/// @file

#include "../../Math/GlobalFunctions.h"

static bool helpIsShown = false;

void DrawSmallButtonHelpSectionOpen(int x, int y) {
    SetFont(TypeFont_UGO2);
    Draw4SymbolsInRect(x + 2, y + 2, '\x4a', ColorFill());
    SetFont(TypeFont_8);
}

void DrawSmallButtonHelpSectionClose(int x, int y) {
    SetFont(TypeFont_UGO2);
    Draw4SymbolsInRect(x + 2, y + 1, '\x48', ColorFill());
    SetFont(TypeFont_8);
}

void DrawSmallButtonHelpNextLink(int x, int y) {
    SetFont(TypeFont_UGO2);
    Draw4SymbolsInRect(x + 3, y + 2, '\x2a', ColorFill());
    SetFont(TypeFont_8);
}

void DrawSmallButtonHelpStringPrev(int x, int y) {
    SetFont(TypeFont_UGO2);
    Draw4SymbolsInRect(x + 2, y + 2, '\x4c', ColorFill());
    SetFont(TypeFont_8);
}

void DrawSmallButtonHelpStringNext(int x, int y) {
    SetFont(TypeFont_UGO2);
    Draw4SymbolsInRect(x + 2, y + 2, '\x4e', ColorFill());
    SetFont(TypeFont_8);
}

void PressSmallButtonHelpSectionOpen() {

}

void PressSmallButtonHelpSectionClose() {

}

void PressSmallButtonHelpNextLink() {

}

void PressSmallButtonHelpStringPrev() {

}

void PressSmallButtonHelpStringNext() {

}

void OnHelpRegSetLeft() {

}

void OnHelpRegSetRight() {

}

extern const SmallButton sbExit;

const SmallButton sbHelpSectionOpen = {DrawSmallButtonHelpSectionOpen, PressSmallButtonHelpSectionOpen};
const SmallButton sbHelpSectionClose = {DrawSmallButtonHelpSectionClose, PressSmallButtonHelpSectionClose};
const SmallButton sbHelpNextLink = {DrawSmallButtonHelpNextLink, PressSmallButtonHelpNextLink};
const SmallButton sbHelpStringPrev = {DrawSmallButtonHelpStringPrev, PressSmallButtonHelpStringPrev};
const SmallButton sbHelpStringNext = {DrawSmallButtonHelpStringNext, PressSmallButtonHelpStringNext};

const PageSB pageSBhelp = {
    TypePageSB_Help,
    {&sbExit, &sbHelpSectionOpen, &sbHelpSectionClose, &sbHelpNextLink, &sbHelpStringPrev, &sbHelpStringNext},
    OnHelpRegSetLeft,
    OnHelpRegSetRight
};

void OnPressHelpShow() {

    helpIsShown = true;

    FPGA_Stop(true);

    SetPageSB(&pageSBhelp);
}

/* ������ ************************************************************************************************************************************/
const Page mpHelp;

/* ������ - �������� */
const ItemButton mbHelpShow = {TypeItem_Button, &mpHelp, {"��������", "Show"}, "mbHelpShow", "", EmptyFuncBV, OnPressHelpShow, EmptyFuncVII};

static const Page mpHelp = {TypeItem_Page, &mainPage, {"������", "HELP"}, "mpHelp", "", TypePage_Help, EmptyFuncBV,
    {
        (void*)&mbHelpShow
    }
};

bool Help_IsShown() {
    return helpIsShown;
}

void Help_ExitFromShown() {
    helpIsShown = false;
    FPGA_Start();
}
