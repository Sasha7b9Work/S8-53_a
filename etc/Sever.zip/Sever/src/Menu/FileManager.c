/// @file

#include "FileManager.h"
#include "../Settings/Settings.h"
#include "../USB/usbh_usr.h"
#include "../Display/DisplayDrawing.h"
#include "../Display/Colors.h"
#include "../Display/Display.h"
#include "../Math/GlobalFunctions.h"
#include "../Log.h"
#include "Pages/PageMemory.h"
#include "../Hardware/HAL.h"

#include <string.h>

char* ConvertUnucodeToANSII(WCHAR *text) {
    static char buffer[100];
    int pointer = 0;
    while(*text) {
        if(*text > 255) {
            buffer[pointer] = ((*text) & 0xff00) >> 8;
        } else {
            buffer[pointer] = (*text) & 0xff;
        }
        pointer++;
    }
    buffer[pointer] = 0;
    return buffer;
}

//static char bufForFileNames[20][20] = {0};  ///< �������� ��� �� �������� �������� � ������.
static char bufForCurrentDir[50] = {0};
//static int numItem = 0;                     ///< ������� ������� �������� ��������.
static bool curDirectoryTheGet = false;     ///< ���� false - ������� ������� �� �������.
static int numItemsInDirectory = 0;
static bool numItmesInDirecoryGet = false;

void FM_Init() {
    curDirectoryTheGet = false;
}


void FM_DeInit() {

}

void FM_Draw() {
    if(!curDirectoryTheGet) {
        if(!FS_GetNameCurrentDir(bufForCurrentDir, 50)) {
            LOG_ERROR("�� ���� �������� � ������� ��� �������� ��������");
            curDirectoryTheGet = true;
        } else {
            curDirectoryTheGet = true;
        }
    }

    if(!numItmesInDirecoryGet) {
        numItemsInDirectory = FS_GetNumItemsInDir(bufForCurrentDir);
        numItmesInDirecoryGet = true;
    }

    FillRegion(GridLeft() + 1, GridTop() + 1, GridWidth() - 2, GridHeight() - 2, ColorBack());
    Display_DrawText(GridLeft() + 2, GridTop() + 2, bufForCurrentDir, ColorFill());
    Display_DrawText(GridRight() - 20, GridTop() + 2, Int2String(numItemsInDirectory, false, 1), ColorFill());
    //Display_DrawText(GridRight() - 40, GridTop() + 2, Int2String(uffs_get_items_num(), false, 1), ColorFill());

}

void FM_PressSB_MemExtLevelUp() {

}

void FM_PressSB_MemExtLevelDown() {

}

void FM_PressSB_MemExtNewFolder() {

}

void FM_RotateRegSetLeft() {

}

void FM_RotateRegSetRight() {

}

char* ExtractExtension(char *fileName) {
    static char buffer[5] = {0};
    int size = strlen(fileName);

    int pointer = 0;
    for(int i = size - 1; (i >= 0) && (pointer >= 0); i--) {
        buffer[pointer] = fileName[i];
    }

    return buffer;
}

char* ExtractNfirstSymbols(char *fileName, int N) {
    static const int LEN = 50;
    static char buffer[LEN] = {0};
    int size = strlen(fileName);

    int i = 0;
    for(; i < N; i++) {
        if(i < size) {
            buffer[i] = fileName[i];
        }
    }

    buffer[i] = 0;
    return buffer;
}

void FillFirstPastMask(char mask[20]) {
    mask[0] = 0;
    strcat(mask, Int2String(HAL_GetYear() - 2000, false, 2));
    strcat(mask, Int2String(HAL_GetMonth(), false, 2));
    strcat(mask, Int2String(HAL_GetDay(), false, 2));
}

bool FirstNsymbolsIsEquals(char *str1, char *str2, int num) {
    for(int i = 0; i < num; i++) {
        if(str1[i] != str2[i]) {
            return false;
        }
    }
    return true;
}

char* FM_GetNameForNewFile() {
    static char buffer[20] = "yymmdd00.bmp";
    static int number = 0;
    FillFirstPastMask(buffer);
    strcat(buffer, Int2String(number, false, 2));
    strcat(buffer, ".bmp");

    number++;
    if(number > 99) {
        number = 0;
    }
    return buffer;

    /*

    char *mask = GetFileNameMask();

    char currentDir[50];

    FS_GetNameCurrentDir(currentDir, 50);

    int numItems = FS_GetNumItemsInDir(currentDir);

    int number = 0;
    for(int i = 0; i < numItems; i++) {
        char name[20];
        uint8 attrib;
        FS_GetInfoAboutNextItem(name, &attrib);
        if(attrib & AM_DIR) {
            continue;
        }
        if(strcmp(ExtractExtension(name), ".bmp") != 0) {
            continue;
        }
        if(FirstNsymbolsIsEquals(name, buffer, 6)) {
            name[8] = 0;
            int value = 0;
            if(String2Int(buffer + 6, &value)) {
                if(value > number) {
                    number = value + 1;
                }
            }
        }
    }

    if(number > 99) {
        number = 0;
    }

    strcat(buffer, Int2String(number, false, 2));
    strcat(buffer, ".bmp");

    return buffer;
    */
}
