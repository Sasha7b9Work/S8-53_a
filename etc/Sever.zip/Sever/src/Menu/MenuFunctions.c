/// @file

#include "../defines.h"
#include "../Display/DisplayTypes.h"
#include "MenuItems.h"
#include "../Panel/Controls.h"
#include "MenuFunctions.h"
#include "MenuItemsLogic.h"
#include "Menu.h"
#include "Settings/SettingsTypes.h"
#include "../Math/Measures.h"
#include "../Tables.h"
#include "../Display/Display.h"
#include "../Display/DisplayDrawingCol.h"
#include "../Settings/Settings.h"
#include "../Math/GlobalFunctions.h"
#include "../Log.h"

extern const Page mainPage;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static void* RetLastOpened(Page *_page, TypeItem *_type);
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
TypeItem TypeMenuItem(void *address) {
    return address ? (*((TypeItem*)address)) : TypeItem_None;
}

bool    CurrentItemIsOpened(NamePage namePage) {
    bool retValue = _GET_BIT(MenuPosActItem(namePage), 7) == 1;
    return retValue;
}

int8    PosCurrentItem(const Page *page) {
    return MenuPosActItem(page->name) & 0x7f;
}

void    SetCurrentItem(const void *item, bool active) {
    if(item != 0) {
        Page *page = (Keeper(item));
        if(!active) {
            SetMenuPosActItem(page->name, 0x7f);
        } else {
            for(int i = 0; i < NumItemsInPage(page); i++) {
                if(Item(page, i) == item) {
                    SetMenuPosActItem(page->name, i);
                    return;
                }
            }
            LOG_ERROR("�� ���� ���������� �������� �������� %s", NameItemMenu(item));
        }
    }
}

TypeItem    TypeOpenedItem() {
    TypeItem type = TypeItem_None;
    void *item = RetLastOpened((Page*)&mainPage, &type);
    return type;
}

void*    OpenedItem() {
    TypeItem type = TypeItem_None;
    return RetLastOpened((Page*)&mainPage, &type);
}

void* Item(const Page *page, int numElement) {
    return page->items[numElement];
}

void*   CurrentItem() {
    TypeItem type = TypeItem_None;
    void *lastOpened = RetLastOpened((Page*)&mainPage, &type);
    int8 pos = PosCurrentItem(lastOpened);
    if(type == TypeItem_Page && pos != 0x7f) {
        return Item(lastOpened, pos);
    }
    return lastOpened;
}

int HeightOpenedItem(void *item) {
    TypeItem type = TypeMenuItem(item);
    if(type == TypeItem_Page) {
        int numItems = NumItemsInPage(item) - NumCurrentSubPage(item) * MENU_ITEMS_ON_DISPLAY;
        numItems = LimitationInt(numItems, 0, MENU_ITEMS_ON_DISPLAY);
        return MP_TITLE_HEIGHT + MI_HEIGHT * numItems;
    } else if(type == TypeItem_Choice) {
#ifdef DISPLAY_COLOR
            return MOI_HEIGHT_TITLE + NumSubItems(item) * MOSI_HEIGHT - 1;
#else
        return MOI_HEIGHT_TITLE + NumSubItems(item) * (MOSI_HEIGHT - 4) + 2;
#endif
    }
    return MI_HEIGHT;
}

int    NumCurrentSubPage(Page *page) {
    return MenuCurrentSubPage(page->name);
}

const char* TitleItem(void *item) {
    return ((Page*)item)->title[GetLanguage()];
}

int PosItemOnTop(Page *page) {
    return NumCurrentSubPage(page) * MENU_ITEMS_ON_DISPLAY;
}

bool IsFunctionalButton(PanelButton button) {
    return button >= B_F1 && button <= B_F5;
}

void SelectNextSubPage(const Page *page) {
    if(page && MenuCurrentSubPage(page->name) < NumSubPages(page) - 1) {
        SetMenuCurrentSubPage(page->name, MenuCurrentSubPage(page->name) + 1);
    }
}

void SelectPrevSubPage(const Page *page) {
    if(page && MenuCurrentSubPage(page->name) > 0) {
        SetMenuCurrentSubPage(page->name, MenuCurrentSubPage(page->name) - 1);
    }
}

int NumSubPages(const Page *page) {
    return (NumItemsInPage(page) - 1) / MENU_ITEMS_ON_DISPLAY + 1;
}

void* RetLastOpened(Page *page, TypeItem *type) {
    if(CurrentItemIsOpened(Name(page))) {
        int8 posActItem = PosCurrentItem(page);
        void *item = Item(page, posActItem);
        TypeItem typeLocal = TypeMenuItem(Item(page, posActItem));
        if(typeLocal == TypeItem_Choice) {
            *type = TypeItem_Choice;
            return item;
        } else if(typeLocal == TypeItem_Governor) {
            *type = TypeItem_Governor;
            return item;
        }  else if(typeLocal == TypeItem_GovernorColor) {
            *type = TypeItem_GovernorColor;
            return item;
        } else if(typeLocal == TypeItem_Time) {
            *type = TypeItem_Time;
            return item;
        } else if(typeLocal == TypeItem_IP) {
            *type = TypeItem_IP;
            return item;
        } else if(typeLocal == TypeItem_Page) {
            return RetLastOpened(item, type);
        }
    }
    *type = TypeItem_Page;
    return page;
}

void CloseOpenedItem() {
    void *item = OpenedItem();
    //Log_Write("Open %s", NameItemMenu(item));
    if(TypeOpenedItem() == TypeItem_Page) {
        NamePage name = Keeper(item)->name;
        SetMenuPosActItem(name, MenuPosActItem(name) & 0x7f);
        if(item == &mainPage) {
            ShowMenu(false);
        }
    } else {
        OpenItem(item, false);
    } 
}

void OpenItem(const void *item, bool open) {
    if(item) {
        Page *page = Keeper(item);
        SetMenuPosActItem(Name(page), open ? (PosCurrentItem(page) | 0x80) : (PosCurrentItem(page) & 0x7f));
    }
}

bool ItemIsOpened(void *item) {
    TypeItem type = TypeMenuItem(item);
    Page *page = Keeper(item);
    if(type == TypeItem_Page) {
        return CurrentItemIsOpened(Name(Keeper(item)));
    }
    return (MenuPosActItem(page->name) & 0x80) != 0;
}

Page* Keeper(const void *item) {
    const Page* page = ((Page*)(item))->keeper;
    return (void*)page;
}

NamePage Name(const Page *page) {
    if(TypeMenuItem((void*)page) != TypeItem_Page) {
        return TypePage_NoPage;
    }
    return page->name;
}

bool ItemIsAcitve(void *item) {
    TypeItem type = TypeMenuItem(item);
    if(type == TypeItem_Choice) {
        return ((ItemChoice*)(item))->funcOfActive();
    } else if(type == TypeItem_Page) {
        return ((Page*)(item))->funcOfActive();
    } else if(type == TypeItem_Button) {
        return ((ItemButton*)(item))->funcOfActive();
    } else if(type == TypeItem_Governor) {
        return ((ItemGovernor*)(item))->funcOfActive();
    }

    return true;
}

int NumSubItems(ItemChoice *choice) {
    int i = 0;
    for(; i < MAX_NUM_SUBITEMS_IN_CHOICE; i++) {
        if(choice->names[i][GetLanguage()] == 0) {
            return i;
        }
    }
    return i;
}

int NumItemsInPage(const Page * const page) {
    int i = 0;
    for(; i < MAX_NUM_ITEMS_IN_PAGE; i++) {
        if(Item(page, i) == 0) {
            return i;
        }
    }
    return i;
}

const char* NameCurrentSubItem(ItemChoice *choice) {
    return (choice->cell == 0) ? "" : choice->names[*choice->cell][GetLanguage()];
}

const char* NameSubItem(ItemChoice *choice, int i) {
    return choice->names[i][GetLanguage()];
}

const char* NameNextSubItem(ItemChoice *choice) {
    if(choice->cell == 0) {
        return "";
    }
    if((*choice->cell) < (NumSubItems(choice) - 1)) {
        return choice->names[*choice->cell + 1][GetLanguage()];
    }
    return choice->names[0][GetLanguage()];
}

void IncreaseItem(void *item) {
    TypeItem type = TypeMenuItem(item);
    if(type == TypeItem_Choice) {
        Choice_Increase(item);
    } else if(type == TypeItem_Governor) {
        ItemGovernor *governor = (ItemGovernor*)item;
        if(OpenedItem() != governor) {
            Governor_StartIncrease(governor);
        } else {
            int temp = *governor->cell;
            temp += Pow10(*governor->curDigit);
            if(temp <= governor->maxValue) {
                *governor->cell = temp;
                governor->funcOfChanged();
            }
        }
    } else if(type == TypeItem_GovernorColor) {
#ifdef DISPLAY_COLOR
        GovernorColor_Increase(item);
#endif
    }
}

void DecreaseItem(void *item) {
    TypeItem type = TypeMenuItem(item);
    if(type == TypeItem_Choice) {
        Choice_Decrease(item);
    } else if(type == TypeItem_Governor) {
        ItemGovernor *governor = (ItemGovernor*)item;
        if(OpenedItem() != governor) {
            Governor_StartDecrease(governor);
        } else {
            int temp = *governor->cell;
            temp -= Pow10(*governor->curDigit);
            if(temp >= governor->minValue) {
                *governor->cell = temp;
                governor->funcOfChanged();
            }
        }
    } else if(type == TypeItem_GovernorColor) {
#ifdef DISPLAY_COLOR
        GovernorColor_Decrease(item);
#endif
    }
}

int NumDigitsInGovernor(ItemGovernor *governor) {
    int min = NumDigitsInNumber(FabsInt(governor->minValue));
    int max = NumDigitsInNumber(FabsInt(governor->maxValue));
    if(min > max) {
        max = min;
    }
    return max;
}

