/// @file

#include "GlobalFunctions.h"
#include "../Settings/Settings.h"
#include "../Log.h"

#include <math.h>
#include <stdio.h>
#include <string.h>

int Pow10(int pow) {
    int retValue = 1;

    while(pow--) {
        retValue *= 10;
    }
    
    return retValue;
}

int NumDigitsInNumber(int value) {
    value = FabsInt(value);
    int num = 1;
    while((value /= 10) > 0) {
        num++;
    }
    return num;
}

int FabsInt(int value) {
    return value >= 0 ? value : -value;
}

int LimitationInt(int value, int min, int max) {
    if(value <= min) {
        return min;
    }
    if(value >= max) {
        return max;
    }
    return value;
}

uint8 LimitationUInt8(uint8 value, uint8 min, uint8 max) {
    if(value <= min) {
        return min;
    }
    if(value >= max) {
        return max;
    }
    return value;
}

int16 LimitationInt16(int16 value, int16 min, int16 max) {
    if(value <= min) {
        return min;
    }
    if(value >= max) {
        return max;
    }
    return value;
}

char* FloatFract2String(float value, bool alwaysSign) {
    return Float2String(value, alwaysSign, 4);
}

char* Float2String(float value, bool alwaysSign, int numDigits) {
    static char buffer[20];
    buffer[0] = 0;
    char *pBuffer = buffer;

    if(value == ERROR_VALUE_FLOAT) {
        strcat(buffer, ERROR_STRING_VALUE);
        return buffer;
    }

    if(!alwaysSign) {
        if(value < 0) {
            *pBuffer = '-';
            pBuffer++;
        }
    } else {
        *pBuffer = value < 0 ? '-' : '+';
        pBuffer++;
    }

    char format[] = "%4.2f\0\0";

    format[1] = (char)numDigits + 0x30;

    float fabsValue = fabs(value);

    int numDigitsInInt = 0;
    if(fabsValue > 9999) {
        numDigitsInInt = 5;
    } else if(fabsValue > 999) {
        numDigitsInInt = 4;
    } else if(fabsValue > 99) {
        numDigitsInInt = 3;
    } else if(fabsValue > 9) {
        numDigitsInInt = 2;
    } else {
        numDigitsInInt = 1;
    }

    format[3] = (numDigits - numDigitsInInt) + 0x30;
    if(numDigits == numDigitsInInt) {
        format[5] = '.';
    }

    sprintf(pBuffer, format, fabsValue);

    bool signExist = alwaysSign || value < 0;
    while(strlen(buffer) < numDigits + (signExist ? 2 : 1)) {
        strcat(buffer, "0");
    }

    return buffer;
}

char* Int2String(int value, bool alwaysSign, int numMinFields) {
    static char buffer[20];
    char format[20] = "%";
    sprintf(&(format[1]), "0%d", numMinFields);
    strcat(format, "d");
    if(alwaysSign && value >= 0) {
        buffer[0] = '+';
        sprintf(buffer + 1, format, value);
    } else {
        sprintf(buffer, format, value);
    }
    return buffer;
}

bool String2Int(char *str, int *value) {
    int length = strlen(str);
    *value = 0;
    int pow = 1;
    for(int i = length - 1; i >= 0; i--) {
        int val = str[i] & (~(0x30));
        if(val < 0 || val > 9) {
            return false;
        }
        *value += val * Pow10(pow);
        pow *= 10;
    }
    return true;
}

char*    Bin2String(uint8 value) {
    static char buffer[9] = {0};
    for(int bit = 0; bit < 8; bit++) {
        buffer[7 - bit] = _GET_BIT(value, bit) ? '1' : '0';
    }
    return buffer;
}

char*   Bin2String16(uint16 value) {
    static char buffer[19] = {0};
    strcpy(buffer, Bin2String(value >> 8));
    strcpy((buffer[8] = ' ', buffer + 9), Bin2String((uint8)value));
    return buffer;
}

char* Hex8toString(uint8 value) {
    static char buffer[3] = {0};
    sprintf(value < 16 ? (buffer[0] = '0', buffer + 1) :  (buffer), "%x", value);
    return buffer;
}

char*    Voltage2String(float voltage, bool alwaysSign) {
    const int LEN_BUFFER = 20;
    static char buffer[LEN_BUFFER];
    buffer[0] = 0;
    char *suffix;
    if(voltage == ERROR_VALUE_FLOAT) {
        strcat(buffer, ERROR_STRING_VALUE);
        return buffer;
    } else if(fabs(voltage) + 0.5e-4 < 1e-3) {
        suffix = GetLanguage() == Russian ? "\x10���" : "\x10uV";
        voltage *= 1e6;
    } else if(fabs(voltage) + 0.5e-4 < 1) {
        suffix = GetLanguage() == Russian ? "\x10��" : "\x10mV" ;
        voltage *= 1e3;
    } else if(fabs(voltage) + 0.5e-4 < 1000) {
        suffix = GetLanguage() == Russian ? "\x10�" : "\x10V";
    } else {
        suffix = GetLanguage() == Russian ? "\x10��" : "\x10kV";
        voltage *= 1e-3;
    }

    strcat(buffer, Float2String(voltage, alwaysSign, 4));
    strcat(buffer, suffix);
    return buffer;
}

char* Time2String(float time, bool alwaysSign) {
    static char buffer[20];
    buffer[0] = 0;
    char *suffix = 0;
    if(time == ERROR_VALUE_FLOAT) {
        strcat(buffer, ERROR_STRING_VALUE);
        return buffer;
    } else if(fabs(time) + 0.5e-10 < 1e-6) {
        suffix = GetLanguage() == Russian ? "��" : "ns";
        time *= 1e9;
    } else if(fabs(time) + 0.5e-7 < 1e-3) {
        suffix = GetLanguage() == Russian ? "���" : "us";
        time *= 1e6;
    } else if(fabs(time) + 0.5e-3 < 1) {
        suffix = GetLanguage() == Russian ? "��" : "ms";
        time *= 1e3;
    } else {
        suffix = GetLanguage() == Russian ? "�" : "s";
    }

    strcat(buffer, Float2String(time, alwaysSign, 4));
    strcat(buffer, suffix);
    return buffer;
}

char* Freq2String(float freq, bool alwaysSign) {
    static char buffer[20];
    buffer[0] = 0;
    char *suffix = 0;
    if(freq == ERROR_VALUE_FLOAT) {
        strcat(buffer, ERROR_STRING_VALUE);
        return buffer;
    } if(freq >= 1e6) {
        suffix = GetLanguage() == Russian ? "���" : "MHz";
        freq /= 1e6;
    } else if(freq >= 1e3) {
        suffix = GetLanguage() == Russian ? "���" : "kHz";
        freq /= 1e3;
    } else {
        suffix = GetLanguage() == Russian ? "��" : "Hz";
    }
    strcat(buffer, Float2String(freq, false, 4));
    strcat(buffer, suffix);
    return buffer;
}

bool IntInRange(int value, int min, int max) {
    return (value >= min) && (value <= max);
}

float MaxFloat(float val1, float val2, float val3) {
    float retValue = val1;
    if(val2 > retValue) {
        retValue = val2;
    }
    if(val3 > retValue) {
        retValue = val3;
    }
    return retValue;
}

int8 CircleIncreaseInt8(int8 *val, int8 min, int8 max) {
    (*val)++;
    if((*val) > max) {
        (*val) = min;
    }
    return (*val);
}

int16 CircleIncreaseInt16(int16 *val, int16 min, int16 max) {
    (*val)++;
    if((*val) > max) {
        (*val) = min;
    }
    return (*val);
}

int8 CircleDecreaseInt8(int8 *val, int8 min, int8 max) {
    (*val)--;
    if((*val) < min) {
        (*val) = max;
    }
    return *val;
}

int16 CircleDecreaseInt16(int16 *val, int16 min, int16 max) {
    (*val)--;
    if((*val) < min) {
        (*val) = max;
    }
    return (*val);
}

float CircleAddFloat(float *val, float delta, float min, float max) {
    *val += delta;
    if(*val > max) {
        *val = min;
    }
    return *val;
}

float CircleSubFloat(float *val, float delta, float min, float max) {
    *val -= delta;
    if(*val < min) {
        *val = max;
    }
    return *val;
}

void AddLimitationFloat(float *val, float delta, float min, float max) {
    float sum = *val + delta;
    if(sum < min) {
        *val = min;
    } else if(sum > max) {
        *val = max;
    } else {
        *val = sum;
    }
}

void SwapInt(int *value0, int *value1) {
    int temp = *value0;
    *value0 = *value1;
    *value1 = temp;
}

void SortInt(int *value0, int *value1) {
    if(*value1 < *value0) {
        SwapInt(value0,  value1);
    }
}

char GetSymbolForGovernor(int value) {
    static const char chars[] = {'\xaa', '\xac', '\x8c', '\x0e'};
    while(value < 0) {
        value += 4;
    }
    return chars[value % 4];
}

void EmptyFuncVV() { }

void EmptyFuncVpV(void *empty) { }

bool EmptyFuncBV(void) { return true; }

void EmptyFuncVII(int i, int ii) { }

void EmptyFuncpVII(void *v, int i, int ii) { }

void EmptyFuncVI16(int16 i) {}

void EmptyFuncVB(bool b) {}

void IntToStrCat(char *_buffer, int _value) {
    static const int LENGHT = 10;
    char buffer[LENGHT];
    for(int i = 0; i < LENGHT; i++) {
        buffer[i] = 0;
    }
    int pointer = LENGHT -1;

    while(_value > 0) {
        buffer[pointer] = (unsigned char)(_value % 10);
        _value /= 10;
        pointer--;
    }

    while(*_buffer) {
        _buffer++;
    }
    int i = 0;

    for(; i < LENGHT; i++) {
        if(buffer[i] > 0) {
            break;
        }
    }

    for(; i < LENGHT; i++) {
        *_buffer = 0x30 | buffer[i];
        _buffer++;
    }

    *_buffer = 0;
}
