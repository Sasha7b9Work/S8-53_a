import os

output = ("TablesSIN.c", "w")

output.write("const float sinDelta2[2]
