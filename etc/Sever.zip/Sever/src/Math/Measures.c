/// @file

#include "Measures.h"
#include "../Settings/SettingsTypes.h"
#include "../Menu/Pages/PageMeasures.h"
#include "../Settings/Settings.h"
#include "../Display/DisplayDrawing.h"
#include "../Display/Display.h"
#include "../Display/Colors.h"

#include <stdio.h>

typedef struct {
    const char *name;
    const char UGO;
} StructMeasure;

static const StructMeasure measures[Measure_NumMeasures] = {
    {"",            '\x00'},
    {"U ����",      '\x20'},
    {"U ���",       '\x25'},
    {"U ���",       '\x2a'},
    {"U ���� ���",  '\x40'},
    {"U ��� ���",   '\x45'},
    {"U ����",      '\x4a'},
    {"U ��",        '\x60'},
    {"U ���",       '\x65'},
    /*
    {"������+",     '\x6a'},
    {"������-",     '\x80'},
    */
    {"������",      '\x85'},
    {"�������",     '\x8a'},
    /*
    {"�� ������",   '\xa0'},
    {"�� �����",    '\xa5'},
    */
    {"����+",       '\xaa'},
    {"����-",       '\xc0'},
    {"������+",     '\xc5'},
    {"������-",     '\xca'},
    {"��������\xa7",'\xe0'},
    {"��������\xa6",'\xe5'},
    {"����\xa7",    '\xe0'},
    {"����\xa6",    '\xe5'}
};

static int posActive = 0;
static bool pageChoiceIsActive = false;
static int posOnPageChoice = 0;

bool Measure_IsActive(int row, int col) {
    if(posActive >= Measure_NumCols() * Measure_NumRows()) {
        posActive = 0;
    }
    return (row * Measure_NumCols() + col) == posActive;
}

void Measure_GetActive(int *row, int *col) {
    *row = posActive / Measure_NumCols();
    *col = posActive - (*row) * Measure_NumCols();
}

void Measure_SetActive(int row, int col) {
    posActive = row * Measure_NumCols() + col;
}

char  Measure_GetChar(Measure measure) {
    return measures[measure].UGO;
}

int Measure_GetDY() {
    if(GetMeasuresSource() == Chan1_2) {
        return 30;
    }
    return 21;
}

int Measure_GetDX() {
    return GRID_WIDTH / 5; 
}

const char* Measure_Name(int row, int col) {
    return measures[GetMeasure(row * Measure_NumCols() + col)].name;
}

Measure Measure_Type(int row, int col) {
    return GetMeasure(row * Measure_NumCols() + col);
}

int Measure_GetTopTable() {
    if(GetMeasuresNumber() == MN_6_1 || GetMeasuresNumber() == MN_6_2) {
        return GRID_BOTTOM - Measure_GetDY() * 6;
    }
    return GRID_BOTTOM - Measure_NumRows() * Measure_GetDY();
}

int Measure_NumCols() {
    int cols[] = {1, 2, 5, 5, 5};
    return cols[GetMeasuresNumber()];
}

int Measure_NumRows() {
    int rows[] = {6, 6, 1, 2, 3};
    return rows[GetMeasuresNumber()];
}

int Measure_GetDeltaGridLeft() {
    if(IsShownMeasures() && GetMeasuresModeViewSignals() == ModeViewSignals_Compress) {
        if(GetMeasuresNumber() == MN_6_1) {
            return Measure_GetDX();
        } else if(GetMeasuresNumber() == MN_6_2) {
            return Measure_GetDX() * 2;
        }
    }
    return 0;
}

int Measure_GetDeltaGridBottom() {
    if(IsShownMeasures() && GetMeasuresModeViewSignals() == ModeViewSignals_Compress) {
        if(GetMeasuresNumber() == MN_1_5) {
            return Measure_GetDY();
        } else if(GetMeasuresNumber() == MN_2_5) {
            return Measure_GetDY() * 2;
        } else if(GetMeasuresNumber() == MN_3_5) {
            return Measure_GetDY() * 3;
        }
    }
    return 0;
}

void Measure_RotateRegSetLeft() {
    if(pageChoiceIsActive) {
        posOnPageChoice--;
        if(posOnPageChoice < 0) {
            posOnPageChoice = Measure_NumMeasures - 1;
        }
        SetMeasure(posActive, (Measure)posOnPageChoice);
        ResetFlash();
    } else {
        int row = 0;
        int col = 0;
        Measure_GetActive(&row, &col);
        col--;
        if(col < 0) {
            col = Measure_NumCols() - 1;
            row--;
            if(row < 0) {
                row = Measure_NumRows() - 1;
            }
        }
        Measure_SetActive(row, col);
    }
}

void Measure_RotateRegSetRight() {
    if(pageChoiceIsActive) {
        posOnPageChoice++;
        if(posOnPageChoice == Measure_NumMeasures) {
            posOnPageChoice = 0;
        }
        SetMeasure(posActive, (Measure)posOnPageChoice);
        ResetFlash();
    } else {
        int row = 0;
        int col = 0;
        Measure_GetActive(&row, &col);
        col++;
        if(col >= Measure_NumCols()) {
            col = 0;
            row++;
            if(row >= Measure_NumRows()) {
                row = 0;
            }
        }
        Measure_SetActive(row, col);
    }
}

void Measure_ShorPressOnSmallButtonSettings() {
    pageChoiceIsActive = !pageChoiceIsActive;
    if(pageChoiceIsActive) {
        posOnPageChoice = GetMeasure(posActive);
    }
}

void Measure_ShortPressOnSmallButonMarker() {
    if(GetMeasure(posActive) == GetMarkedMeasure()) {
        SetMarkedMeasure(Measure_None);
    } else {
        SetMarkedMeasure(GetMeasure(posActive));
    }
}

bool Measure_PageChoiceIsActive() {
    return pageChoiceIsActive;
}

void Measure_DrawPageChoice() {
    if(!pageChoiceIsActive) {
        return;
    }
    int x = (GetMeasuresNumber() < MN_1_5) ? (GridRight() - 3 * GRID_WIDTH / 5) : GridLeft();
    int y = GRID_TOP;
    int dX = GRID_WIDTH / 5;
    int dY = 22;
    int maxRow = (GetMeasuresNumber() < MN_1_5) ? 8 : 5;
    int maxCol = (GetMeasuresNumber() < MN_1_5) ? 3 : 5;
    Measure meas = Measure_None;
    SetFont(TypeFont_UGO);
    for(int row = 0; row < maxRow; row++) {
        for(int col = 0; col < maxCol; col++) {
            if(meas >= Measure_NumMeasures) {
                break;
            }
            int x0 = x + col * dX;
            int y0 = y + row * dY;
            bool active = meas == posOnPageChoice;
            DrawRectangle(x0, y0, dX, dY, ColorFill());
            FillRegion(x0 + 1, y0 + 1, dX - 2, dY - 2, active ? FLASH_10 : ColorBack());
            Draw10SymbolsInRect(x0 + 2, y0 + 1, Measure_GetChar(meas), active ? FLASH_01 : ColorFill());
            if(meas < Measure_NumMeasures) {
                SetFont(TypeFont_5);
                DrawTextRelativelyRight(x0 + dX, y0 + 12, measures[meas].name, active ? FLASH_01 : ColorFill());
                SetFont(TypeFont_UGO);
            }
            meas++;
        }
    }
    SetFont(TypeFont_8);
}
