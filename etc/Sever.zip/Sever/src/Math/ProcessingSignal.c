/// @file

#include "ProcessingSignal.h"
#include "Math.h"
#include "../FPGA/FPGA_Types.h"
#include "../Menu/Pages/PageDisplay.h"
#include "../Menu/Pages/PageMeasures.h"
#include "../Menu/Pages/PageMemory.h"
#include "../Log.h"
#include "../Timer.h"
#include "GlobalFunctions.h"
#include "../FPGA/FPGA.h"

#include <math.h>
#include <string.h>
#include <stdio.h>

static const DataSettings*    ds;
static const uint8*           data[2];

typedef struct {
    pFuncFchan  FuncCalculate;
    pFuncCFB    FucnConvertate;
    bool        showSign;
} MeasureCalculate;

typedef struct {
    float value[2];
} MeasureValue;

static float CalculateVoltageMax(Channel chan);
static float CalculateVoltageMin(Channel chan);
static float CalculateVoltagePic(Channel chan);
static float CalculateVoltageMaxSteady(Channel chan);
static float CalculateVoltageMinSteady(Channel chan);
static float CalculateVoltageAmpl(Channel chan);
static float CalculateVoltageAverage(Channel chan);
static float CalculateVoltageRMS(Channel chan);
static float CalculatePeriod(Channel chan);
static int   CalculatePeriodAccurately(Channel chan);   /// ����� ��������� ������ ��� ����� ����� �������� � ������ �������.
static float CalculateFreq(Channel chan);
static float CalculateDurationPlus(Channel chan);
static float CalculateDurationMinus(Channel chan);
static float CalculateSkvaznostPlus(Channel chan);
static float CalculateSkvaznostMinus(Channel chan);


static uint8 CalculateMin(Channel chan);
static uint8 CalculateMinSteady(Channel chan);
static uint8 CalculateMax(Channel chan);
static uint8 CalculateMaxSteady(Channel chan);
static uint8 CalculateAverage(Channel chan);
static uint8 CalculatePic(Channel chan);
static float CalculateDelayPlus(Channel chan);
static float CalculateDelayMinus(Channel chan);
static float CalculatePhazaPlus(Channel chan);
static float CalculatePhazaMinus(Channel chan);
static float FindIntersectionWithAveLine(Channel chan, int numIntersection, bool downToUp, uint8 aveValue);  ///< ����� ����� ����������� ������� �� ������� ������. numItersection - ���������� ����� �����������, ���������� � 1. downToTop - ���� true, ���� ����������� ������� �� ������� ������ ��� ����������� �� "-" � "+".

static const MeasureCalculate measures[Measure_NumMeasures]  = {
    {0, 0},
    {CalculateVoltageMax, Voltage2String, true},
    {CalculateVoltageMin, Voltage2String, true},
    {CalculateVoltagePic, Voltage2String, false},
    {CalculateVoltageMaxSteady, Voltage2String, true},
    {CalculateVoltageMinSteady, Voltage2String, true},
    {CalculateVoltageAmpl, Voltage2String, false},
    {CalculateVoltageAverage, Voltage2String, true},
    {CalculateVoltageRMS, Voltage2String, false},
    /*
    {0, 0, true},
    {0, 0, true},
    */
    {CalculatePeriod, Time2String, false},
    {CalculateFreq, Freq2String, false},
    /*
    {0, 0, false},
    {0, 0, false},
    */
    {CalculateDurationPlus, Time2String, false},
    {CalculateDurationMinus, Time2String, false},
    {CalculateSkvaznostPlus, FloatFract2String, false},
    {CalculateSkvaznostMinus, FloatFract2String, false},
    {CalculateDelayPlus, Time2String, false},
    {CalculateDelayMinus, Time2String, false},
    {CalculatePhazaPlus, FloatFract2String, false},
    {CalculatePhazaMinus, FloatFract2String, false}
};

static MeasureValue values[Measure_NumMeasures] = {{0.0f, 0.0f}};

static int markerHor[NumChannels][2] = {{ERROR_VALUE_INT}, {ERROR_VALUE_INT}};
static int markerVert[NumChannels][2] = {{ERROR_VALUE_INT}, {ERROR_VALUE_INT}};

static bool maxIsCalculating[2] = {false, false};
static bool minIsCalculating[2] = {false, false};
static bool maxSteadyIsCalculating[2] = {false, false};
static bool minSteadyIsCalculating[2] = {false, false};
static bool aveIsCalculating[2] = {false, false};
static bool intersectionIsFinded[2][2][3];      // 0-� ������ - ����� ������, 1-� ������ - false ��� true, 2-� ������ - ����� ����������� (1-� ��� ������).
static bool periodIsCaclulating[2] = {false, false};
static bool periodAccurateIsCalculating[2];
static bool picIsCalculating[2] = {false, false};

void Processing_CalculateMeasures() {

    if(!IsShownMeasures() || !ds) {
        return;
    }

    maxIsCalculating[0] = maxIsCalculating[1] = maxSteadyIsCalculating[0] = maxSteadyIsCalculating[1] = false;
    minIsCalculating[0] = minIsCalculating[1] = minSteadyIsCalculating[0] = minSteadyIsCalculating[1] = false;
    aveIsCalculating[0] = aveIsCalculating[1] = false;
    intersectionIsFinded[0][0][1] = intersectionIsFinded[0][0][2] =
    intersectionIsFinded[0][1][1] = intersectionIsFinded[0][1][2] = 
    intersectionIsFinded[1][0][1] = intersectionIsFinded[1][0][2] =
    intersectionIsFinded[1][1][1] = intersectionIsFinded[1][1][2] = false;
    periodIsCaclulating[0] = periodIsCaclulating[1] = false;
    periodAccurateIsCalculating[0] = periodAccurateIsCalculating[1] = false;
    picIsCalculating[0] = picIsCalculating[1] = false;

    for(int str = 0; str < Measure_NumRows(); str++) {
        for(int elem = 0; elem < Measure_NumCols(); elem++) {
            Measure meas = Measure_Type(str, elem);
            pFuncFchan func = measures[meas].FuncCalculate;
            if(func) {
                if(meas == GetMarkedMeasure() || GetMarkedMeasure() == Measure_None) {
                    markerVert[Chan0][0] = markerVert[Chan0][1] = markerVert[Chan1][0] = markerVert[Chan1][1] = ERROR_VALUE_INT;
                    markerHor[Chan0][0] = markerHor[Chan0][1] = markerHor[Chan1][0] = markerHor[Chan1][1] = ERROR_VALUE_INT;
                }
                if(GetMeasuresSource() == Chan0 || GetMeasuresSource() == Chan1_2) {
                    values[meas].value[0] = func(Chan0);
                }
                if(GetMeasuresSource() == Chan1 || GetMeasuresSource() == Chan1_2) {
                    values[meas].value[1] = func(Chan1);
                }
            }
        }
    }
}

float CalculateVoltageMax(Channel chan) {
    uint8 max = CalculateMax(chan);
    if(GetMarkedMeasure() == Measure_VoltageMax) {
        markerHor[chan][0] = max;
    }
    if(max == ERROR_VALUE_UINT8) {
        return ERROR_VALUE_FLOAT;
    }

    return Math_PointToVoltage(max, ds->range[chan], ds->rShift[chan]);
}

float CalculateVoltageMin(Channel chan) {
    uint8 min = CalculateMin(chan);
    if(GetMarkedMeasure() == Measure_VoltageMin) {
        markerHor[chan][0] = min;
    }
    if(min == ERROR_VALUE_UINT8) {
        return ERROR_VALUE_FLOAT;
    }

    return Math_PointToVoltage(min, ds->range[chan], ds->rShift[chan]);
}

float CalculateVoltagePic(Channel chan) {
    float max = CalculateVoltageMax(chan);
    float min = CalculateVoltageMin(chan);
    if(max == ERROR_VALUE_FLOAT || min == ERROR_VALUE_FLOAT) {
        return ERROR_VALUE_FLOAT;
    } else if(GetMarkedMeasure() == Measure_VoltagePic) {
        markerHor[chan][0] = CalculateMax(chan);
        markerHor[chan][1] = CalculateMin(chan);
    }
    return max - min;
}

float CalculateVoltageMinSteady(Channel chan) {
    uint8 min = CalculateMinSteady(chan);
    if(GetMarkedMeasure() == Measure_VoltageMinSteady) {
        markerHor[chan][0] = min;
    }
    if(min == ERROR_VALUE_UINT8) {
        return ERROR_VALUE_FLOAT;
    }

    return Math_PointToVoltage(min, ds->range[chan], ds->rShift[chan]);
}

float CalculateVoltageMaxSteady(Channel chan) {
    uint8 max = CalculateMaxSteady(chan);
    if(GetMarkedMeasure() == Measure_VoltageMaxSteady) {
        markerHor[chan][0] = max;
    }
    if(max == ERROR_VALUE_UINT8) {
        return ERROR_VALUE_FLOAT;
    }

    return Math_PointToVoltage(max, ds->range[chan], ds->rShift[chan]);
}

float CalculateVoltageAmpl(Channel chan) {
    float max = CalculateVoltageMaxSteady(chan);
    float min = CalculateVoltageMinSteady(chan);
    if(max == ERROR_VALUE_FLOAT || min == ERROR_VALUE_FLOAT) {
        return ERROR_VALUE_FLOAT;
    } else if(GetMarkedMeasure() == Measure_VoltageAmpl) {
        markerHor[chan][0] = CalculateMaxSteady(chan);
        markerHor[chan][1] = CalculateMinSteady(chan);
    }
    return max - min;
}

float CalculateVoltageAverage(Channel chan) {
    int period = CalculatePeriodAccurately(chan);
    if(period == ERROR_VALUE_INT) {
        return ERROR_VALUE_FLOAT;
    }

    int sum = 0;
    for(int i = 0; i < period; i++) {
        sum += data[chan][i];
    }

    uint8 aveRel = (float)sum / period;

    if(GetMarkedMeasure() == Measure_VoltageAverage) {
        markerHor[chan][0] = aveRel;
    }

    return Math_PointToVoltage(aveRel, ds->range[chan], ds->rShift[chan]);
}

float CalculateVoltageRMS(Channel chan) {
    int period = CalculatePeriodAccurately(chan);
    if(period == ERROR_VALUE_INT) {
        return ERROR_VALUE_FLOAT;
    }

    float rms = 0.0f;
    for(int i = 0; i < period; i++) {
        float volts = Math_PointToVoltage(data[chan][i], ds->range[chan], ds->rShift[chan]);
        rms +=  volts * volts;
    }

    if(GetMarkedMeasure() == Measure_VoltageRMS) {
        markerHor[chan][0] = Math_VoltageToPoint(sqrt(rms / period), ds->range[chan], ds->rShift[chan]);
    }

    return sqrt(rms / period);
}

float CalculatePeriod(Channel chan) {

    static float period[2] = {0.0f, 0.0f};

    if(!periodIsCaclulating[chan]) {

        uint8 aveValue = CalculateAverage(chan);
        if(aveValue == ERROR_VALUE_UINT8) {
            period[chan] = ERROR_VALUE_FLOAT;
        } else {
            float intersectionDownToTop = FindIntersectionWithAveLine(chan, 1, true, aveValue);
            float intersectionTopToDown = FindIntersectionWithAveLine(chan, 1, false, aveValue);

            float firstIntersection = intersectionDownToTop < intersectionTopToDown ? intersectionDownToTop : intersectionTopToDown;
            float secondIntersection = FindIntersectionWithAveLine(chan, 2, intersectionDownToTop < intersectionTopToDown, aveValue);

            float per = TShiftFract2Abs((secondIntersection - firstIntersection) / 2.0f, ds->tBase);
            
            float ratio = per / (1.0f / FPGA_GetFreq());

            if(ratio > 0.8f && ratio < 1.2f) {
                period[chan] = per;
                periodIsCaclulating[chan] = true;
            } else {
                period[chan] = ERROR_VALUE_FLOAT;
            }
        }
    }

    return period[chan];
}

int CalculatePeriodAccurately(Channel chan) {

    static int period[2];

    static int sums[FPGA_MAX_POINTS];

    if(!periodAccurateIsCalculating[chan]) {
        int numPoints = GetMemoryNumPoints(true);
        int delta = 0;
        period[chan] = 0;
        uint8 pic = CalculatePic(chan);
        if(pic == ERROR_VALUE_UINT8) {
            period[chan] = ERROR_VALUE_INT;
            goto exit_period;
        }
        delta = pic * 5;
        sums[0] = data[chan][0];
        for(int i = 1; i < numPoints; i++) {
            uint8 point = data[chan][i];
            if(point < MIN_VALUE || point >= MAX_VALUE) {
                period[chan] = ERROR_VALUE_INT;
                goto exit_period;
            }
            sums[i] = sums[i - 1] + point;
        }

        for(int nextPeriod = 10; nextPeriod < (GetMemoryNumPoints(true) * 0.8f); nextPeriod++) {
            int sum = sums[nextPeriod - 1];

            int maxDelta = 0;
            for(int start = 1; start < GetMemoryNumPoints(true) - nextPeriod; start++) {
                int nextSum = sums[start + nextPeriod] - sums[start];
                int nextDelta = FabsInt(sum - nextSum);
                if(nextDelta > delta) {
                    maxDelta = delta + 1;
                    break;
                } else if(nextDelta > maxDelta) {
                    maxDelta = nextDelta;
                }
            }

            if(maxDelta < delta) {
                delta = maxDelta;
                period[chan] = nextPeriod;
            }
        }

        if(period[chan] == 0) {
            period[chan] = ERROR_VALUE_INT;
        }
exit_period:
        periodAccurateIsCalculating[chan] = true;
    }

    return period[chan];
}

float CalculateFreq(Channel chan) {
    float period = CalculatePeriod(chan);
    return period == ERROR_VALUE_FLOAT ? ERROR_VALUE_FLOAT : 1.0f / period;
}

float FindIntersectionWithAveLine(Channel chan, int numIntersection, bool downToUp, uint8 aveValue) {
    
    static float retValue[2][2][3];

    int index1 = downToUp ? 1 : 0;

    if(!intersectionIsFinded[chan][index1][numIntersection]) {

        int num = 0;
        int x = 0;

        if(downToUp) {
            while((num < numIntersection) && (x < GetMemoryNumPoints(true) - 1)) {
                if(data[chan][x] < aveValue && data[chan][x + 1] >= aveValue) {
                    num++;
                }
                x++;
            }
        } else {
            while((num < numIntersection) && (x < GetMemoryNumPoints(true) - 1)) {
                if(data[chan][x] > aveValue && data[chan][x + 1] <= aveValue) {
                    num++;
                }
                x++;
            }
        }
        x--;

        retValue[chan][index1][numIntersection] = num < numIntersection ? ERROR_VALUE_FLOAT : Math_GetIntersectionWithHorizontalLine(x, data[chan][x], x + 1, data[chan][x + 1], aveValue);

        intersectionIsFinded[chan][index1][numIntersection] = true;
    }

    return retValue[chan][index1][numIntersection];
}

float CalculateDurationPlus(Channel chan) {
    uint8 aveValue = CalculateAverage(chan);
    if(aveValue == ERROR_VALUE_UINT8) {
        return ERROR_VALUE_FLOAT;
    }

    float firstIntersection = FindIntersectionWithAveLine(chan, 1, true, aveValue);
    float secondIntersection = FindIntersectionWithAveLine(chan, 1, false, aveValue);
    if(secondIntersection < firstIntersection) {
        secondIntersection = FindIntersectionWithAveLine(chan, 2, false, aveValue);
    }

    return TShiftFract2Abs((secondIntersection - firstIntersection) / 2.0f, ds->tBase);
}

float CalculateDurationMinus(Channel chan) {
    uint8 aveValue = CalculateAverage(chan);
    if(aveValue == ERROR_VALUE_UINT8) {
        return ERROR_VALUE_FLOAT;
    }

    float firstIntersection = FindIntersectionWithAveLine(chan, 1, false, aveValue);
    float secondIntersection = FindIntersectionWithAveLine(chan, 1, true, aveValue);
    if(secondIntersection < firstIntersection) {
        secondIntersection = FindIntersectionWithAveLine(chan, 2, true, aveValue);
    }

    return TShiftFract2Abs((secondIntersection - firstIntersection) / 2.0f, ds->tBase);
}

float CalculateSkvaznostPlus(Channel chan) {
    float period = CalculatePeriod(chan);
    float duration = CalculateDurationPlus(chan);
    if(period == ERROR_VALUE_FLOAT || duration == ERROR_VALUE_FLOAT) {
        return ERROR_VALUE_FLOAT;
    }
    return period / duration;
}

float CalculateSkvaznostMinus(Channel chan) {
    float period = CalculatePeriod(chan);
    float duration = CalculateDurationMinus(chan);
    if(period == ERROR_VALUE_FLOAT || duration == ERROR_VALUE_FLOAT) {
        return ERROR_VALUE_FLOAT;
    }
    return period / duration;
}

uint8 CalculateMin(Channel chan) {
    static uint8 min[2] = {255, 255};

    if(!minIsCalculating[chan]) {

        min[chan] = 255;

        int numPoints = GetMemoryNumPoints(true);
        for(int i = 0; i < numPoints; i++) {
            if(data[chan][i] < min[chan]) {
                min[chan] = data[chan][i];
            }
        }

        if(min[chan] < MIN_VALUE || min[chan] >= MAX_VALUE) {
            min[chan] = ERROR_VALUE_UINT8;
        }

        minIsCalculating[chan] = true;
    }

    return min[chan];
}

uint8 CalculateMinSteady(Channel chan) {
    static uint8 min[2] = {255, 255};

    if(!minSteadyIsCalculating[chan]) {
        uint8 aveValue = CalculateAverage(chan);
        if(aveValue == ERROR_VALUE_UINT8) {
            min[chan] = ERROR_VALUE_UINT8;
        } else {
            int sum = 0;
            int numPoints = GetMemoryNumPoints(true);
            int numSums = 0;
            for(int i = 0; i < numPoints; i++) {
                if(data[chan][i] < aveValue) {
                    sum += data[chan][i];
                    numSums++;
                }
            }
            min[chan] = sum / numSums;

            int numDeleted = 0;

			for(int i = 0; i < numPoints; i++) {
				if(fabs(data[chan][i] - min[chan]) > 10 && data[chan][i] < aveValue) {
					sum -= data[chan][i];
					numSums--;
                    numDeleted++;
				}
			}

			min[chan] = sum / numSums;

            if(numDeleted > numPoints / 4) {
                min[chan] = CalculateMin(chan);
            }
        }
        minSteadyIsCalculating[chan] = true;
    }

    return min[chan];
}

uint8 CalculateMaxSteady(Channel chan) {
    static uint8 max[2] = {255, 255};

    if(!maxSteadyIsCalculating[chan]) {
        uint8 aveValue = CalculateAverage(chan);
        if(aveValue == ERROR_VALUE_UINT8) {
            max[chan] = ERROR_VALUE_UINT8;
        } else {
            int sum = 0;
            int numPoints = GetMemoryNumPoints(true);
            int numSums = 0;
            for(int i = 0; i < numPoints; i++) {
                if(data[chan][i] > aveValue) {
                    sum += data[chan][i];
                    numSums++;
                }
            }
            max[chan] = sum / numSums;

            int numDeleted = 0;

			for(int i = 0; i < numPoints; i++) {
				if(fabs(data[chan][i] - max[chan]) > 10 && data[chan][i] > aveValue) {
					sum -= data[chan][i];
					numSums--;
                    numDeleted++;
				}
			}

			max[chan] = sum / numSums;

            if(numDeleted > numPoints / 4) {
                max[chan] = CalculateMax(chan);
            }
        }
        maxSteadyIsCalculating[chan] = true;
    }

    return max[chan];
}

uint8 CalculateMax(Channel chan) {
    static uint8 max[2] = {0, 0};

    if(!maxIsCalculating[chan]) {

        max[chan] = 0;

        int numPoints = GetMemoryNumPoints(true);
        for(int i = 0; i < numPoints; i++) {
            if(data[chan][i] > max[chan]) {
                max[chan] = data[chan][i];
            }
        }

        if(max[chan] >= MAX_VALUE) {
            max[chan] = ERROR_VALUE_UINT8;
        }

        maxIsCalculating[chan] = true;
    }

    return max[chan];
}

uint8 CalculateAverage(Channel chan) {
    static uint8 ave[2] = {0, 0};

    if(!aveIsCalculating[chan]) {
        ave[chan] = 0;
        uint8 min = CalculateMin(chan);
        uint8 max = CalculateMax(chan);
        if(min == ERROR_VALUE_UINT8 || max == ERROR_VALUE_UINT8) {
            ave[chan] = ERROR_VALUE_UINT8;
        } else {
           ave[chan] = (uint8)(((int)min + (int)max) / 2); 
        }

        aveIsCalculating[chan] = true;
    }
    return ave[chan];
}

uint8 CalculatePic(Channel chan) {
    static uint8 pic[2] = {0, 0};

    if(!picIsCalculating[chan]) {
        pic[chan] = 0;
        uint8 min = CalculateMin(chan);
        uint8 max = CalculateMax(chan);
        if(min == ERROR_VALUE_UINT8 || max == ERROR_VALUE_UINT8) {
            pic[chan] = ERROR_VALUE_UINT8;
        } else {
            pic[chan] = max - min;
        }
        picIsCalculating[chan] = true;
    }
    return pic[chan];
}

float CalculateDelayPlus(Channel chan) {
    float period0 = CalculatePeriod(Chan0);
    float period1 = CalculatePeriod(Chan1);

    if(period0 == ERROR_VALUE_FLOAT || period1 == ERROR_VALUE_FLOAT || !Math_FloatsIsEquals(period0, period1, 1.0f)) {
        return ERROR_VALUE_FLOAT;
    }

    uint8 average0 = CalculateAverage(Chan0);
    uint8 average1 = CalculateAverage(Chan1);

    float firstIntersection = 0.0f;
    float secondIntersection = 0.0f;
    uint8 averageFirst = chan == Chan0 ? average0 : average1;
    uint8 averageSecond = chan == Chan0 ? average1 : average0;
    Channel firstChannel = chan == Chan0 ? Chan0 : Chan1;
    Channel secondChannel = chan == Chan0 ? Chan1 : Chan0;

    firstIntersection = FindIntersectionWithAveLine(firstChannel, 1, true, averageFirst);
    secondIntersection = FindIntersectionWithAveLine(secondChannel, 1, true, averageSecond);
    if(secondIntersection < firstIntersection) {
        secondIntersection = FindIntersectionWithAveLine(secondChannel, 2, true, averageSecond);
    }

    return TShiftFract2Abs((secondIntersection - firstIntersection) / 2.0f, ds->tBase);
}

float CalculateDelayMinus(Channel chan) {
    float period0 = CalculatePeriod(Chan0);
    float period1 = CalculatePeriod(Chan1);

    if(period0 == ERROR_VALUE_FLOAT || period1 == ERROR_VALUE_FLOAT || !Math_FloatsIsEquals(period0, period1, 1.0f)) {
        return ERROR_VALUE_FLOAT;
    }

    uint8 average0 = CalculateAverage(Chan0);
    uint8 average1 = CalculateAverage(Chan1);

    float firstIntersection = 0.0f;
    float secondIntersection = 0.0f;
    uint8 averageFirst = chan == Chan0 ? average0 : average1;
    uint8 averageSecond = chan == Chan0 ? average1 : average0;
    Channel firstChannel = chan == Chan0 ? Chan0 : Chan1;
    Channel secondChannel = chan == Chan0 ? Chan1 : Chan0;

    firstIntersection = FindIntersectionWithAveLine(firstChannel, 1, false, averageFirst);
    secondIntersection = FindIntersectionWithAveLine(secondChannel, 1, false, averageSecond);
    if(secondIntersection < firstIntersection) {
        secondIntersection = FindIntersectionWithAveLine(secondChannel, 2, false, averageSecond);
    }

    return TShiftFract2Abs((secondIntersection - firstIntersection) / 2.0f, ds->tBase);
}

float CalculatePhazaPlus(Channel chan) {
    float delay = CalculateDelayPlus(chan);
    float period = CalculatePeriod(chan);
    if(delay == ERROR_VALUE_FLOAT || period == ERROR_VALUE_FLOAT) {
        return ERROR_VALUE_FLOAT;
    }
    return delay / period * 360.0f;
}

float CalculatePhazaMinus(Channel chan) {
    float delay = CalculateDelayMinus(chan);
    float period = CalculatePeriod(chan);
    if(delay == ERROR_VALUE_FLOAT || period == ERROR_VALUE_FLOAT) {
        return ERROR_VALUE_FLOAT;
    }
    return delay / period * 360.0f; 
}

void Processing_ResetSignal() {
    ds = 0;
    data[0] = data[1] = 0;
}

void Processing_SetSignal(const DataSettings *eDS, const uint8 *eData0, const uint8 *eData1) {
    ds = eDS;
    data[0] = eData0;
    data[1] = eData1;
}

const DataSettings* Processing_GetDataSettings() {
    return ds;
}

const uint8* Processing_GetData(Channel chan) {
    if(chan == Chan0 || chan == Chan1) {
        return data[chan];
    } else {
        LOG_ERROR("������������ ����� %d", chan);
    }
    return 0;
}

int16 Processing_GetCursU(Channel chan, int16 posCurT) {
    if(!data[chan]) {
        return -1;
    }
    
    int startPoint = 0;
    int endPoint = 0;
    GetPointsOnDisplay(&startPoint, &endPoint);

    return 200 - (data[chan])[startPoint + posCurT];
}

int16 Processing_GetCursT(Channel chan, int16 posCurU, int numCur) {
    if(!data[chan]) {
        return -1;
    }

    int startPoint = 0;
    int endPoint = 0;
    GetPointsOnDisplay(&startPoint, &endPoint);

    int16 prevData = 200 - (data[chan])[startPoint];

    int numIntersections = 0;

    for(int i = startPoint + 1; i < endPoint; i++) {
        int16 curData = 200 - (data[chan])[i];

        if(curData <= posCurU && prevData > posCurU) {
            if(numCur == 0) {
                return i - startPoint;
            } else {
                if(numIntersections == 0) {
                    numIntersections++;
                } else {
                    return i - startPoint;
                }
            }
        }

        if(curData >= posCurU && prevData < posCurU) {
            if(numCur == 0) {
                return i - startPoint;
            } else {
                if(numIntersections == 0) {
                    numIntersections++;
                } else {
                    return i - startPoint;
                }
            }
        }
        prevData = curData;
    }
    return 0;
}

void Processing_InterpolationSinX_X(uint8 data[FPGA_MAX_POINTS], TBase tBase) {
    static const int deltas[5] = {
        50, 20, 10, 5, 2
    };

    if(tBase > TBase_50ns) {
        LOG_ERROR("������. ������������ ������� �������");
        return;
    }

    int delta = deltas[tBase];

#define PI 3.141592653589793
    static const float deltasFI[5] = {
        PI / 2.0f,
        PI / 5.0f,
        PI / 10.0f,
        PI / 20.0f,
        PI / 50.0f
    };

    float deltaFI = deltasFI[tBase];
    
    static uint8 signedData[FPGA_MAX_POINTS / 2];
    int numSignedPoints = 0;
    int pos = 0;
    while(pos < FPGA_MAX_POINTS) {
        if(data[pos] > 0) {
            signedData[numSignedPoints] = data[pos];
            numSignedPoints++;
        }
        pos++;
    }

    float k = 2.0f * asin(1.0f);
    float invDelta = 1.0f / (float)delta;
    for(int i = 0; i < FPGA_MAX_POINTS; i++) {
        float value = 0.0f;
        if((i % delta) == 0) {
            value = signedData[i / delta];
        } else {
            float fi = deltaFI;
            for(int n = 0; n < numSignedPoints; n++) {
                float x = k *(invDelta * i - n);
                fi -= deltaFI;
                if(x == 0.0f) {
                    value += signedData[n] * 1.0f;
                } else {
                    value += signedData[n] * (sin(x) / x);
                }
            }
        }
        data[i] = (uint8)value;
    }
}

char* Processing_GetStringMeasure(Measure measure, Channel chan) {
    static char buffer[20];
    buffer[0] = '\0';
    sprintf(buffer, chan == Chan0 ? "1: " : "2: ");
    if(ds == 0) {
        strcat(buffer, "-.-");
    } else if(!ds->enable[chan]) {
    }
    else if(measures[measure].FuncCalculate) {
        strcat(buffer, measures[measure].FucnConvertate(values[measure].value[chan], measures[measure].showSign));
    }
    return buffer;
}

int Processing_GetMarkerHorizontal(Channel chan, int numMarker) {
    return markerHor[chan][numMarker] - MIN_VALUE;
}

int Processing_GetMarkerVertical(Channel chan, int numMarker) {
    return markerVert[chan][numMarker];
}
