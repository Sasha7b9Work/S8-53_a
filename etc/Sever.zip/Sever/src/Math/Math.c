/// @file

#include "Math.h"
#include "Display/Display.h"
#include "Settings/Settings.h"
#include "Log.h"
#include "FPGA/FPGA_Types.h"

#include <math.h>

static const float tableScalesRange[RangeSize] = {2e-3, 5e-3, 10e-3, 20e-3, 50e-3, 100e-3, 200e-3, 500e-3, 1.0f, 2.0f, 5.0f, 10.0f, 20.0f};
/*
static const float tableScalesTBase[TBaseSize] = 
    {2e-9, 5e-9, 10e-9, 20e-9, 50e-9, 100e-9, 200e-9, 500e-9,
    1e-6, 2e-6, 5e-6, 10e-6, 20e-6, 50e-6, 100e-6, 200e-6, 500e-6,
    1e-3, 2e-3, 5e-3, 10e-3, 20e-3, 50e-3, 100e-3, 200e-3, 500e-3,
    1.0f, 2.0f, 5.0f, 10.0f};
*/

static const float absStepRShift[] = {
    2e-3 / 20 / STEP_RSHIFT,
    5e-3 / 20 / STEP_RSHIFT,
    10e-3 / 20 / STEP_RSHIFT,
    20e-3 / 20 / STEP_RSHIFT,
    50e-3 / 20 / STEP_RSHIFT,
    100e-3 / 20 / STEP_RSHIFT,
    200e-3 / 20 / STEP_RSHIFT,
    500e-3 / 20 / STEP_RSHIFT,
    1.0 / 20 / STEP_RSHIFT,
    2.0 / 20 / STEP_RSHIFT,
    5.0 / 20 / STEP_RSHIFT,
    10.0 / 20 / STEP_RSHIFT,
    20.0 / 20 / STEP_RSHIFT
};

static const float voltsInPixel[] = {
    2e-3 / 20,
    5e-3 / 20,
    10e-3 / 20,
    20e-3 / 20,
    50e-3 / 20,
    100e-3 / 20,
    200e-3 / 20,
    500e-3 / 20,
    1.0 / 20,
    2.0 / 20,
    5.0 / 20,
    10.0 / 20,
    20.0 / 20
};

static const float absStepTShift[] = {
    2e-9 / 20, 5e-9 / 20, 10e-9 / 20, 20e-9 / 20, 50e-9 / 20, 100e-9 / 20, 200e-9 / 20, 500e-9 / 20,
    1e-6 / 20, 2e-6 / 20, 5e-6 / 20, 10e-6 / 20, 20e-6 / 20, 50e-6 / 20, 100e-6 / 20, 200e-6 / 20, 500e-6 / 20,
    1e-3 / 20, 2e-3 / 20, 5e-3 / 20, 10e-3 / 20, 20e-3 / 20, 50e-3 / 20, 100e-3 / 20, 200e-3 / 20, 500e-3 / 20,
    1.0 / 20, 2.0 / 20, 5.0 / 20, 10.0 / 20
};

float RShift2Abs(int16 rShift, Range range) {
    return -(RShiftZero - rShift) * absStepRShift[range];
};

int RShift2Rel(float rShiftAbs, Range range) {
    int retValue = RShiftZero + rShiftAbs / absStepRShift[range];
    if(retValue < RShiftMin) {
        retValue = RShiftMin;
    } else if(retValue > RShiftMax) {
        retValue = RShiftMax;
    }
    return retValue;
};

float TShift2Abs(int16 tShift, TBase tBase) {
    return absStepTShift[tBase] * tShift * 2;
};

float TShiftFract2Abs(float tShift, TBase tBase) {
    return absStepTShift[tBase] * tShift * 2;
}

int TShift2Rel(float tShiftAbs, TBase tBase) {
    return (int)(tShiftAbs / absStepTShift[tBase] / 2);
};

float Math_MaxVoltageOnScreen(Range range) {
    return tableScalesRange[range] * 5;
}

float Math_VoltageCursor(int shiftCurU, Range range) {
    return Math_MaxVoltageOnScreen(range) - shiftCurU * voltsInPixel[range];
}

float Math_TimeCursor(int shiftCurT, TBase tBase) {
    return shiftCurT * absStepTShift[tBase];
}

void Math_DataExtrapolation(uint8 *data, uint8 *there, int size) {
    int pointer = 0;
    while(there[pointer] == 0) {
        pointer++;
    }
    for(int i = 0; i < pointer; i++) {
        data[i] = data[pointer];
    }
    
    while(pointer < size) {
        while(there[pointer] != 0) {
            pointer++;
            if(pointer >= size) {
                return;
            }
        }
        pointer--;
        int pointer2 = pointer + 1;
        while(there[pointer2] == 0) {
            pointer2++;
            if(pointer2 >= size) {
                return;
            }
        }
        int deltaY = 
            pointer2 - 
        pointer;
        if(deltaY >= 2) {
            float deltaX = (float)(data[pointer2] - data[pointer]) / deltaY;
            for(int i = 1; i < deltaY; i++) {
                data[pointer + i] = data[pointer] + i * deltaX;
            }
        }
        pointer = pointer2 + 1;
    }
}

float Math_PointToVoltage(uint8 value, Range range, int16 rShift) {
    return (value - MIN_VALUE) * voltsInPixel[range] - Math_MaxVoltageOnScreen(range) - RShift2Abs(rShift, range);
}

uint8 Math_VoltageToPoint(float voltage, Range range, int16 rShift) {
    return (voltage + Math_MaxVoltageOnScreen(range) + RShift2Abs(rShift, range)) / voltsInPixel[range] + MIN_VALUE;
}

float Math_GetIntersectionWithHorizontalLine(int x0, int y0, int x1, int y1, int yHorLine) {
    if(y0 == y1) {
        return x1;
    }

    float k = (float)(y1 - y0) / (float)(x1 - x0);
    float retValue = (yHorLine - y0) / k + x0;

    return retValue;
}

bool Math_FloatsIsEquals(float value0, float value1, float epsilonPercents) {
    float max = fabs(value0) > fabs(value1) ? fabs(value0) : fabs(value1);

    float epsilonAbs = max / 100.0f * epsilonPercents;

    return fabs(value0 - value1) < epsilonAbs;
}

float Math_MinFrom3float(float value1, float value2, float value3) {
    float retValue = value1;
    if(value2 < retValue) {
        retValue = value2;
    }
    if(value3 < retValue) {
        retValue = value3;
    }
    return retValue;
}
