/// @file

#pragma once

#include "../defines.h"

typedef struct {
    uint8 width;
    uint8 bytes[8];
} Symbol;

typedef struct {
    int height;
    Symbol symbol[256];
} Font;
