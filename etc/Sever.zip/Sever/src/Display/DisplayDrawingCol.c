 /// @file

#include "../USB/v-com-api.h"
#include "../USB/usbh_usr.h"
#include "DisplayDrawingCol.h"
#include "DisplayDrawing.h"
#include "../Hardware/FSMC.h"
#include "../Settings/Settings.h"
#include "../Math/GlobalFunctions.h"
#include "../Log.h"
#include "../Timer.h"
#include "../Menu/FileManager.h"



#ifdef DISPLAY_COLOR
#include "../Menu/Pages/PageDisplay.h"
#endif

#include <stm32f2xx_gpio.h>

#ifdef DISPLAY_COLOR

typedef enum {
    SET_COLOR                   = 0x01,
    FILL_REGION                 = 0x02,
    SEND_TO_SCREEN              = 0x03,
    DRAW_HLINE                  = 0x04,
    DRAW_VLINE                  = 0x05,
    SET_POINT                   = 0x06,
    DRAW_SIGNAL_LINES           = 0x07,
    DRAW_TEXT                   = 0x08,
    SET_PALETTE                 = 0x09,
    SET_FONT                    = 0x0a,
    DRAW_HPOINT_LINE            = 0x0b,
    DRAW_VPOINT_LINE            = 0x0c,
    DRAW_VLINES_ARRAY           = 0x0d,
    DRAW_SIGNAL_POINTS          = 0x0e,
    SET_BRIGHTNESS              = 0x0f,
    DRAW_MULTI_HPOINT_LINES     = 0x10,
    DRAW_MULTI_HPOINT_LINES_2   = 0x11,
    DRAW_MULTI_VPOINT_LINES     = 0x12,
    LOAD_FONT                   = 0x13,
    DRAW_PICTURE                = 0x14,
    GET_POINT                   = 0x15,
    NUM_COMMANDS
} Command;

extern bool inverseColors;

static int counts[NUM_COMMANDS] = {0};
static int bytes[NUM_COMMANDS] = {0};

static uint16 colors[16] = {0};
static int numberColorsUsed = 0;
static uint16 prevColorValue = 0;
static bool needResetPalette = false;

static void SetPalette(uint8 numColor, uint16 color);
                                                        /// ������� ������ � ������� �������.
static void SendBytes(uint8 *bytes, int numBytes);
static void Get4Bytes(uint8 bytes[4]);
static uint8 GetOneByte(void);

void CD_ResetCounts() {
    for(int i = 0; i < NUM_COMMANDS; i++) {
        counts[i] = bytes[i] = 0;
    }
}

void CD_WriteCounts() {
    /*
    Log_Write("commands = %d, packets = %d, bytes = %d", countCommands, countPackets, countBytes);
    Log_Write("colors = %d, bytes = %d", counts[SET_COLOR], bytes[SET_COLOR]);
    Log_Write("points = %d, bytes = %d", counts[SET_POINT], bytes[SET_POINT]);
    Log_Write("hLines = %d, bytes = %d", counts[DRAW_VLINE], bytes[DRAW_VLINE]);
    Log_Write("fill = %d, bytes = %d", counts[FILL_REGION], bytes[FILL_REGION]);
    Log_Write("send = %d, bytes = %d", counts[SEND_TO_SCREEN], bytes[SEND_TO_SCREEN]);
    Log_Write("vLines = %d, bytes = %d", counts[DRAW_VLINE], bytes[DRAW_VLINE]);
    Log_Write("signalLines = %d, bytes = %d", counts[DRAW_SIGNAL_LINES], bytes[DRAW_SIGNAL_LINES]);
    Log_Write("text = %d, bytes = %d", counts[DRAW_TEXT], bytes[DRAW_TEXT]);
    Log_Write("palettes = %d, bytes = %d", counts[SET_PALETTE], bytes[SET_PALETTE]);
    Log_Write("font = %d, bytes = %d", counts[SET_FONT], bytes[SET_FONT]);
    Log_Write("hor. point line = %d, bytes = %d", counts[DRAW_HPOINT_LINE], bytes[DRAW_HPOINT_LINE]);
    Log_Write("vert. point line = %d, bytes = %d", counts[DRAW_VPOINT_LINE], bytes[DRAW_VPOINT_LINE]);
    Log_Write("lines for memory = %d, bytes = %d", counts[DRAW_VLINES_ARRAY], bytes[DRAW_VLINES_ARRAY]);
    Log_Write("signalPoints = %d, bytes = %d", counts[DRAW_SIGNAL_POINTS], bytes[DRAW_SIGNAL_POINTS]);
    */
}

void SetBrightnessCol(int16 brightness) {
    uint8 command[4];
    command[0] = SET_BRIGHTNESS;
    float recValue = 1601.0f;
    if(brightness < 100) {
        recValue = 64.0f + (600.0f - 63.0f) / 100.0f / 100.0f * brightness * brightness;
    }
    *((uint16*)(command + 1)) = (uint16)recValue;
    SendBytes(command, 4);
}

void BeginSceneCol() {
    if(needResetPalette) {
        numberColorsUsed = 0;
        needResetPalette = false;
    }
}

int NumberColorsInSceneCol() {
    return numberColorsUsed;
}

bool SetColor16(uint16 colorValue, const char *funcFrom) {
    if(numberColorsUsed > 0 && prevColorValue == colorValue) {
        return true;
    }
    uint8 command[4] = {SET_COLOR};
    for(int i = 0; i < numberColorsUsed; i++) {
        if(colors[i] == colorValue) {
            command[1] = i;
            SendBytes(command, 4);
            prevColorValue = colorValue;
            return true;
        }
    }
    if(numberColorsUsed == 16) {
        needResetPalette = true;
        return false;
    }
    SetPalette(numberColorsUsed, colorValue);
    command[1] = prevColorValue = colors[numberColorsUsed] = colorValue;
    SendBytes(command, 4);
    numberColorsUsed++;
    return true;
}

void SetPointCol(int x, int y, Color color) {
    SetColor16(GetColorValue(color), __FUNCTION__);
    SetPointWithDefaultColor(x, y);
}

void Get8Points(int x, int y, uint8 buffer[4]) {
    uint8 command[4];
    command[0] = GET_POINT;
    *((int16*)(command + 1)) = (int16)x;
    *(command + 3) = (int8)y;
    SendBytes(command, 4);
    Get4Bytes(buffer);
}

uint8 Get2Points(int x, int y) {
    static uint8 command[4] = {GET_POINT};
    *((int16*)(command + 1)) = (int16)x;
    *(command + 3) = (int8)y;
    SendBytes(command, 4);
    return GetOneByte();
}

Color GetColor(int x, int y) {

    uint8 command[4];
    command[0] = GET_POINT;
    *((int16*)(command + 1)) = (int16)x;
    *(command + 3) = (int8)y;
    SendBytes(command, 4);

    Get4Bytes(command);

    return (Color)(command[0] & 0x0f);
}

void SetPointWithDefaultColor(int x, int y) {
    uint8 command[4];
    command[0] = SET_POINT;
    *((int16*)(command + 1)) = (int16)x;
    *(command + 3) = (int8)y;
    counts[SET_POINT]++;
    bytes[SET_POINT] += 4;
    SendBytes(command, 4);
}

void DrawVLineArrayCol(int x, int numLines, uint8 *y0y1, Color color) {
    SetColor16(GetColorValue(color), __FUNCTION__);
    static uint8 command[255 * 2 + 4 + 4];
    command[0] = DRAW_VLINES_ARRAY;
    *((int16*)(command + 1)) = (int16)x;
	if(numLines > 255) {
		numLines = 255;
	}
	*(command + 3) = numLines;
    for(int i = 0; i < numLines; i ++) {
        *(command + 4 + i * 2) = *(y0y1 + i * 2);
        *(command + 4 + i * 2 + 1) = *(y0y1 + i * 2 + 1);
    }
    int numBytes = numLines * 2 + 4;
    while(numBytes % 4) {
        numBytes++;
    }
    
    SendBytes(command, numBytes);
}

void DrawHPointLineCol(int x, int y, int delta, int count, Color color, bool multi) {
    SetColor16(GetColorValue(color), __FUNCTION__);
    uint8 command[6];
    command[0] = multi ? DRAW_MULTI_HPOINT_LINES : DRAW_HPOINT_LINE;
    *((int16*)(command + 1)) = (int16)x;
    *(command + 3) = y;
    *(command + 4) = delta;
    *(command + 5) = count;
    counts[DRAW_HPOINT_LINE]++;
    bytes[DRAW_HPOINT_LINE] += 8;
    SendBytes(command, 6);
}

void DrawHLineCol(int y, int x0, int x1, Color color) {
    SetColor16(GetColorValue(color), __FUNCTION__);
    uint8 command[8];
    command[0] = DRAW_HLINE;
    *(command + 1) = (int8)y;
    *((int16*)(command + 2)) = (int16)x0;
    *((int16*)(command + 4)) = (int16)x1;
    SendBytes(command, 8);
}

void DrawVLineCol(int x, int y0, int y1, Color color ) {
    SetColor16(GetColorValue(color), __FUNCTION__);
    uint8 command[8];
    command[0] = DRAW_VLINE;
    *((int16*)(command + 1)) = (int16)x;
    *(command + 3) = (int8)y0;
    *(command + 4) = (int8)y1;
    SendBytes(command, 8);
}

void FillRegionCol(int x, int y, int width, int height, Color color) {
    SetColor16(GetColorValue(color), __FUNCTION__);
    uint8 command[8];
    command[0] = FILL_REGION;
    *((int16*)(command + 1)) = (int16)x;
    *(command + 3) = (int8)y;
    *((int16*)(command + 4)) = (int16)width;
    *(command + 6) = (int8)height;
    SendBytes(command, 8);
}

int DrawTextCol(int x, int y, const char* text, Color color) {
    int retValue = x;
    y += (8 - GetSizeFont());
    SetColor16(GetColorValue(color), __FUNCTION__);
    static uint8 command[50];
    command[0] = DRAW_TEXT;
    *((int16*)(command + 1)) = (int16)x;
    *(command + 3) = (int8)(y + 1);
    uint8 *pointer = command + 5;
    uint8 length = 0;

    int counter = 0;
    while(*text) {
        *pointer = (uint8)(*text);
        retValue += LenghtSymbol(*text);
        text++;
        pointer++;
        length++;
        counter++;
    }

    *pointer = 0;
    *(command + 4) = length;
    int numBytes = ((length + 4) / 4) * 4 + 4;
    SendBytes(command, numBytes);
    return retValue;
}

void DrawMultiHPointLineCol(int numLines, int x, uint8 y[], int delta, int count, Color color) {
    if(numLines > 20) {
        LOG_ERROR("����� ����� ������� ������� %d", numLines);
        return;
    }
    SetColor16(GetColorValue(color), __FUNCTION__);
    static uint8 command[30];
    command[0] = DRAW_MULTI_HPOINT_LINES_2;
    *(command + 1) = numLines;
    *((uint16*)(command + 2)) = x;
    *(command + 4) = count;
    *(command + 5) = delta;
    uint8 *pointer = command + 6;
    for(int i = 0; i < numLines; i++) {
        *pointer = y[i];
        pointer++;
    }
    int numBytes =  1 +     // command
                    1 +     // numLines
                    2 +     // x
                    numLines +    // numLines
                    1 +
                    1;
    while(numBytes % 4) {
        numBytes++;
    }
    SendBytes(command, numBytes);
}

void DrawMultiVPointLineCol(int numLines, int y, uint16 x[], int delta, int count, Color color) {
    if(numLines > 20) {
        LOG_ERROR("����� ����� ������� ������� %d", numLines);
        return;
    }
    SetColor16(GetColorValue(color), __FUNCTION__);
    static uint8 command[60];
    command[0] = DRAW_MULTI_VPOINT_LINES;
    *(command + 1) = numLines;
    *(command + 2) = y;
    *(command + 3) = count;
    *(command + 4) = delta;
    *(command + 5) = 0;
    uint8 *pointer = command + 6;
    for(int i = 0; i < numLines; i++) {
        *((uint16*)pointer) = x[i];
        pointer += 2;
    }
    int numBytes = 1 + 1 + 1 + numLines * 2 + 1 + 1;
    while(numBytes % 4) {
        numBytes++;
    }
    SendBytes(command, numBytes);
}

void DrawPicture() {
    static const int width = 320;
    static const int height = 240;

    uint8 command[4];
    command[0] = DRAW_PICTURE;
    *((uint16*)(command + 1)) = 0;
    *(command + 3) = 0;
    SendBytes(command, 4);
    *((uint16*)(command)) = width;
    *(command + 2) = height;
    *(command + 3) = 0;
    SendBytes(command, 4);
    for(int i = 0; i < width * height / 2 / 4; i++) {
        *(command) = 0x12;
        *(command + 1) = 0x12;
        *(command + 2) = 0x12;
        *(command + 3) = 0x12;
        SendBytes(command, 4);
    }
}

void DrawVPointLineCol(int x, int y, int delta, int count, Color color) {
    SetColor16(GetColorValue(color), __FUNCTION__);
    uint8 command[6];
    command[0] = DRAW_VPOINT_LINE;
    *((int16*)(command + 1)) = (int16)x;
    *(command + 3) = y;
    *(command + 4) = delta;
    *(command + 5) = count;
    counts[DRAW_VPOINT_LINE]++;
    bytes[DRAW_VPOINT_LINE] += 8;
    SendBytes(command, 6);
}

void DrawSignalCol(int x, uint8 data[281], bool modeLines, uint16 colorValue) {
    //Log_Write("Draw signal with color %d", colorValue);
    SetColor16(colorValue, __FUNCTION__);
    static uint8 command[284];
    command[0] = modeLines ? DRAW_SIGNAL_LINES : DRAW_SIGNAL_POINTS;
    *((int16*)(command + 1)) = (int16)x;
    for(int i = 0; i < 281; i++) {
        *(command + 3 + i) = data[i];
    }
    if(modeLines) {
        counts[DRAW_SIGNAL_LINES]++;
        bytes[DRAW_SIGNAL_LINES] += 284;
    } else {
        counts[DRAW_SIGNAL_POINTS]++;
        bytes[DRAW_SIGNAL_POINTS] += 284;
    }
    SendBytes(command, 284);
}

void DrawCharHardCol(int x, int y, char symbol, Color color) {
    char str[2] = {symbol, 0};
    Display_DrawText(x, y, str, color);
}

void SetFontCol(TypeFont typeFont) {
    uint8 command[4];
    command[0] = SET_FONT;
    command[1] = (uint8)typeFont;
    counts[SET_FONT]++;
    bytes[SET_FONT] += 4;
    SendBytes(command, 4);
}

void LoadFontCol(TypeFont typeFont, uint8 bytes[3080]) {
    static uint8 command[3084];
    command[0] = LOAD_FONT;
    command[1] = typeFont;
    for(int i = 0; i < 3080; i++) {
        command[2 + i] = bytes[i];
    }
    SendBytes(command, 3084);
}

#if _USE_LFN > 0
void SaveScreenToFlashDriveCol(TCHAR *fileName) {
#else
void SaveScreenToFlashDriveCol() {
#endif

    uint startTime = Timer_GetMS();

#pragma pack(1)
    typedef struct {
        char    type0;      // 0
        char    type1;      // 1
        uint    size;       // 2
        uint16  res1;       // 6
        uint16  res2;       // 8
        uint    offBits;    // 10
    } BITMAPFILEHEADER;
    // 14

    typedef struct {
        uint    size;           // 14
        int     width;          // 18
        int     height;         // 22
        uint16  planes;         // 26
        uint16  bitCount;       // 28
        uint    compression;    // 30
        uint    sizeImage;      // 34
        int     xPelsPerMeter;  // 38
        int     yPelsPerMeter;  // 42
        uint    clrUsed;        // 46
        uint    clrImportant;   // 50
        //uint    notUsed[15];
    } BITMAPINFOHEADER;
    // 54
#pragma pack(4)

    BITMAPFILEHEADER bmFH = {
        0x42,
        0x4d,
        14 + 40 + 1024 + 320 * 240 / 2,
        0,
        0,
        14 + 40 + 1024
    };

    OpenFile(FM_GetNameForNewFile());

    WriteToFile((uint8*)(&bmFH), 14);

    BITMAPINFOHEADER bmIH = {
        40,                         // size;
        320,                        // width;
        240,                        // height;
        1,                          // planes;
        4,                         // bitCount;
        0,                          // compression;
        0,                          // sizeImage;
        0,                         // xPelsPerMeter;
        0,                         // yPelsPerMeter;
        0,                         // clrUsed;
        0                          // clrImportant;
    };  

    WriteToFile((uint8*)(&bmIH), 40);

    static uint8 buffer[320 * 3] = {0};
    
    typedef struct tagRGBQUAD 
    {
        uint8    blue; 
        uint8    green; 
        uint8    red; 
        uint8    rgbReserved; 
    } RGBQUAD;
    
    RGBQUAD colorStruct;    

    for(int i = 0; i < 16; i++) {
        uint16 color = colors[i];
        colorStruct.blue = (float)B_FROM_COLOR(color) / 31.0f * 255.0f;
        colorStruct.green = (float)G_FROM_COLOR(color) / 63.0f * 255.0f;
        colorStruct.red = (float)R_FROM_COLOR(color) / 31.0f * 255.0f;
        colorStruct.rgbReserved = 0;
        ((RGBQUAD*)(buffer))[i] = colorStruct;
    }
    

    for(int i = 0; i < 4; i++) {
        WriteToFile(buffer, 256);
    }

    uint timeRead = 0;
    
    for(int y = 239; y >= 0; y--) {
        for(int x = 1; x < 320; x += 2) {
            uint startTimeRead = Timer_GetMS();
            uint8 color = Get2Points(x, y);
            buffer[x / 2] = ((color & 0x0f) << 4) + (color >> 4);
            timeRead += (Timer_GetMS() - startTimeRead);
        }
        WriteToFile(buffer, 160);
    }

    CloseLastFile();

    //Log_Write("����� ������ %d, ����� ������ %d", Timer_GetMS() - startTime - timeRead, timeRead);
}

void SendScreenToComportCol() {

    uint timeStart = Timer_GetMS();
    VCP_SendData((uint8*)colors, 32);
    static uint8 buffer[160];
    for(int y = 0; y < 240; y++) {
        for(int x = 0; x < 320; x += 2) {
            buffer[x / 2] = Get2Points(x, y);
        }
        VCP_SendData(buffer, 160);
    }
}

void SendToScreenCol() {
    if(!needResetPalette) {
        uint8 command[4];
        command[0] = SEND_TO_SCREEN;
        SendBytes(command, 4);
    }
}

void SetPalette(uint8 numColor, uint16 color) {
    uint8 command[4];
    command[0] = SET_PALETTE;
    *(command + 1) = numColor;
    *((uint16*)(command + 2)) = color;
    SendBytes(command, 4);
}

void ClearScreenCol(Color color) {
    BeginSceneCol();
    FillRegion(0, 0, 319, 239, color);
}

void SendBytes(uint8 *bytes, int numBytes) {
#ifdef DISPLAY_COLOR
    if(!needResetPalette) {
        for(int i = 0; i < numBytes; i += 4) {
            
            while(GPIO_ReadInputDataBit(GPIOG, GPIO_Pin_11) == 0) {}
            
            uint timeStart = Timer_GetMultiMeasTicks();
            uint time = Timer_GetMultiMeasTicks();
            while((time - timeStart) < 60) {   
                time = Timer_GetMultiMeasTicks();
            }
            
            for(int j = 0; j < 4; j++) {
                *ADDR_CDISPLAY = bytes[i + j];
            }
        }
    }
#endif
}

uint8 GetOneByte() {
#ifdef DISPLAY_COLOR
    //while(GPIO_ReadInputDataBit(GPIOG, GPIO_Pin_11) == 0) {};
    //uint timeStart = Timer_GetMultiMeasTicks();
    //while((Timer_GetMultiMeasTicks() - timeStart) < 12) {};
    return *ADDR_CDISPLAY;
#endif
}

void Get4Bytes(uint8 bytes[4]) {
#ifdef DISPLAY_COLOR
    for(int i = 0; i < 4; i++) {
        while(GPIO_ReadInputDataBit(GPIOG, GPIO_Pin_11) == 0) {};

        uint timeStart = Timer_GetMultiMeasTicks();
        uint time = Timer_GetMultiMeasTicks();
        
        
        while((time - timeStart) < 12) {
            time = Timer_GetMultiMeasTicks();
        }
        
        
        bytes[i] = *ADDR_CDISPLAY;
    }
#endif
}

Color InverseColorCol(uint16 colorValue) {
    if(R_FROM_COLOR(colorValue) > 20 || G_FROM_COLOR(colorValue) > 40 || B_FROM_COLOR(colorValue) > 20)  {
        return COLOR_BLACK;
    }
    return COLOR_WHITE;
}

uint16 ReduceBrightness(uint16 colorValue, float newBrightness) {
    int red = LimitationInt(R_FROM_COLOR(colorValue) * newBrightness, 0, 31);
    int green = LimitationInt(G_FROM_COLOR(colorValue) * newBrightness, 0, 63);
    int blue = LimitationInt(B_FROM_COLOR(colorValue) * newBrightness, 0, 31);
    return MAKE_COLOR(red, green, blue);
}

#endif
