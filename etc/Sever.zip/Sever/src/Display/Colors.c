/// @file

#include "Colors.h"
#include "DisplayDrawingCol.h"
#include "../Settings/Settings.h"
#include "../Log.h"
#include "../Menu/Pages/PageDisplay.h"
#include "../Menu/Pages/PageTrig.h"

/** @addtogroup COLORS
    @{ */

Color ColorChannel(Channel chan) {
#ifdef DISPLAY_COLOR
    return chan == Chan0 ? COLOR_DATA_0 : COLOR_DATA_1;
#else
    return ColorFill();
#endif
}

Color ColorTrig() {
    TrigSource trigChan = GetTrigSource();
    if(trigChan == TrigSource_Channel0 || trigChan == TrigSource_Channel1) {
        return ColorChannel((Channel)trigChan);
    }
    return ColorFill();
}

Color ColorMenuTitle(bool inShade) {
#ifdef DISPLAY_COLOR
    return inShade ? COLOR_MENU_ITEM : COLOR_MENU_TITLE;
#else
    return ColorFill();
#endif
}

Color ColorMenuTitleBrighter() {
    return COLOR_MENU_TITLE_BRIGHT;
}

Color ColorMenuTitleLessBright() {
    return COLOR_MENU_TITLE_DARK;
}

Color ColorMenuItem(bool inShade) {
#ifdef DISPLAY_COLOR
    return inShade ? COLOR_MENU_ITEM_DARK : COLOR_MENU_ITEM;
#else
    return COLOR_WHITE;
#endif
}

Color ColorMenuItemBrighter() {
    return COLOR_MENU_ITEM_BRIGHT;
}

Color ColorMenuItemLessBright() {
    return COLOR_MENU_ITEM_DARK;
}

Color ColorMenuField() {
    return COLOR_MENU_FIELD;
}

Color ColorBack() {
#ifdef DISPLAY_COLOR
    return COLOR_BLACK;
#else
    return COLOR_WHITE;
#endif
}

Color ColorFill() {
#ifdef DISPLAY_COLOR
    return COLOR_WHITE;
#else
    return COLOR_BLACK;
#endif
}

Color ColorBorderMenu(bool inShade) {
    return ColorMenuTitle(inShade);
}

Color ColorContrast(Color color) {
#ifdef DISPLAY_COLOR
    uint16 colorValue = GetColorValue(color);
    if(R_FROM_COLOR(colorValue) > 16 || G_FROM_COLOR(colorValue) > 32 || B_FROM_COLOR(colorValue) > 16) {
        return COLOR_BLACK;
    }
    return COLOR_WHITE;
#else
    return color == COLOR_WHITE ? COLOR_BLACK : COLOR_WHITE;
#endif
}

#ifdef DISPLAY_COLOR
void Color_Log(Color color) {
    uint16 colorValue = GetColorValue(color);
    Log_Write("%s   r=%d, g=%d, b=%d", NameColor(color), R_FROM_COLOR(colorValue), G_FROM_COLOR(colorValue), B_FROM_COLOR(colorValue));
}
#endif

Color LightShadingTextColor() {
    return ColorMenuTitle(false);
}

Color DarkShadingTextColor() {
    return ColorMenuTitleLessBright();
}

Color ColorGrid() {
#ifdef DISPLAY_COLOR
    return COLOR_GRID;
#else
    return COLOR_BLACK;
#endif
}
/** @} */
