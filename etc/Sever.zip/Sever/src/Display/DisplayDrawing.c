/// @file

#include "DisplayDrawing.h"
#include "Colors.h"
#include "Display.h"
#include "font.h"
#include "DisplayDrawingCol.h"
#include "../Math/GlobalFunctions.h"
#include "../Settings/Settings.h"
#include "../Timer.h"
#include "../Log.h"
#include "../Menu/Pages/PageDisplay.h"

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define REQUIRED_BYTE(x, y)                 (((y) * (SCREEN_WIDTH) + (x)) >> 3)
#define REQUIRED_BIT(x)                     ((x) & 0x07)
#define _SET_BIT_(address, bit)             ((*(address)) |= (1 << (7 - (bit))))
#define _CLEAR_BIT_(address, bit)           ((*(address)) &= (~(1 << (7 - (bit)))))

#define REQUIRED_BIT_MASK(x)                (128 >> ((x) & 0x07))
#define SET_BIT_MASK(address, bitMask)      ((*(address)) |= (bitMask))
#define CLEAR_BIT_MASK(address, bitMask)    ((*(address)) &= (~(bitMask)))

#define IN_RANGE_OF_GRID_X(x)               ((x) > GridLeft() && (x) < (GRID_RIGHT))
#define IN_RANGE_OF_GRID_Y(y)               ((y) > (GRID_TOP) && (y) < (GRID_BOTTOM))

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef DISPLAY_BLACK
extern uint8 bufferDisplay[SIZE_BUFFER_FOR_SCREEN];
#endif

bool inverseColors = false;

extern Font font8;
extern Font font5;
extern Font fontUGO;
extern Font fontUGO2;
Font *fonts[TypeFont_Number] = {&font5, &font8, &fontUGO, &fontUGO2};
Font *font = &font8;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void OnTimerFlashDisplay(void);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int    GetSizeFont() {
    return font->height;
}

void SetFont(TypeFont typeFont) {
    font = fonts[typeFont];
#ifdef DISPLAY_COLOR
    SetFontCol(typeFont);
#endif
}

void DrawHLine(int y, int x0, int x1, Color color) {
    CalculateColor(&color);
    
#ifdef DISPLAY_COLOR
    DrawHLineCol(y, x0, x1, color);
#else
    x0 = LimitationInt(x0, 0, SCREEN_WIDTH - 1);
    x1 = LimitationInt(x1, 0, SCREEN_WIDTH - 1);
    uint8 *startByte = bufferDisplay + REQUIRED_BYTE(x0, y);
    uint8 *endByte = bufferDisplay + REQUIRED_BYTE(x1, y);
    if(endByte - startByte > 1) {
        uint8 *pointer = startByte + 1;
        while(pointer < endByte) {
            *pointer = (color == COLOR_BLACK) ? 255 : 0;
            pointer++;
        }
    }

    if(endByte - startByte > 0) {
        if(color == COLOR_BLACK) {
            *startByte |= (REQUIRED_BIT_MASK(x0) << 1) - 1;
            *endByte |= (0x100 - REQUIRED_BIT_MASK(x1));
        } else {
            uint8 bitMaskStartByte = REQUIRED_BIT_MASK(x0);
            *startByte &= ~((bitMaskStartByte << 1) - 1);
            uint8 bitMaskEndByte = REQUIRED_BIT_MASK(x1);
            *endByte &= ~(0x100 - bitMaskEndByte);
        }
    } else {
        uint8 startBit = REQUIRED_BIT(x0);
        uint8 endBit = REQUIRED_BIT(x1);
        for(uint8 bit = startBit; bit <= endBit; bit++) {
            if(color == COLOR_BLACK) {
                _SET_BIT_(startByte, bit);
            } else {
                _CLEAR_BIT_(startByte, bit);
            }
        }
    }
#endif
}

void DrawVLine(int x, int y0, int y1, Color color) {
    CalculateColor(&color);
 #ifdef DISPLAY_COLOR
    DrawVLineCol(x, y0, y1, color);
 #else
    if(y0 > y1) {
        SwapInt(&y0, &y1);
    }
    uint8 *startByte = bufferDisplay + REQUIRED_BYTE(x, y0);
    uint8 *endByte = bufferDisplay + REQUIRED_BYTE(x, y1);
    uint8 bitMask = REQUIRED_BIT_MASK(x);
    
    if(color == COLOR_BLACK) {
        do {
            *startByte |= bitMask;
            startByte += SCREEN_WIDTH_IN_BYTES;
        } while (startByte <= endByte);
    } else {
        do {
            *startByte &= ~(bitMask);
            startByte += SCREEN_WIDTH_IN_BYTES;
        } while (startByte <= endByte);
    }
#endif
}

void InverseColor(Color *color) {
    *color = (*color == COLOR_BLACK) ? COLOR_WHITE : COLOR_BLACK;
}

void FillRegion(int x, int eY, int width, int height, Color color) {
    CalculateColor(&color);
#ifdef DISPLAY_COLOR
    FillRegionCol(x, eY, width, height, color);
#else
    if(color == CELL_BACK || color == CELL_FILL) {
        Color startColor = color == CELL_FILL ? COLOR_BLACK : COLOR_WHITE;
        for(int row = 0; row <= height; row++) {
            Color color = startColor;
            for(int col = 0; col <= width; col++) {
                SetColorPoint(x + col, eY + row, color);
                InverseColor(&color);
            }
            InverseColor(&startColor);
        }
    } else {
        for(int y = eY; y <= eY + height; y++) {
            DrawHLine(y, x, x + width, color);
        }
    }
#endif
}

#ifdef DISPLAY_BLACK
void DrawRoundedRegion(int x, int y, int width, int height, int round, Color color) {
    for(int i = 0; i < round; i++) {
        DrawHLine(y + i, x + (round - i), x + width - (round - i), color);
    }
    FillRegion(x, y + round, width, height - 2 * round, color);
    for(int i = 0; i < round; i++) {
        DrawHLine(y + height - round + i + 1, x + i + 1, x + width - i - 1, color);
    }
}

void DrawRoundedRectangle(int x, int y, int width, int height, int round, Color color) {
    int x0[] = {x,          x + width - round,  x + width,          x + round};
    int x1[] = {x + round,  x + width,          x + width - round,  x};
    int y0[] = {y + round,  y,                  y + height - round, y + height};
    int y1[] = {y,          y + round,          y + height,         y + height - round};

    DrawHLine(y, x0[3], x0[1], color);
    DrawHLine(y1[2], x0[3], x0[1], color);
    DrawVLine(x, y0[0], y0[2], color);
    DrawVLine(x1[1], y1[1], y0[2], color);

    for(int i = 0; i < 4; i++) {
        DrawLine(x0[i], y0[i], x1[i], y1[i], color);
    }
}
#endif

void DrawBoundedRegion(int x, int y, int width, int height, Color colorFill) {
    Color inverseColor = colorFill;
    InverseColor(&inverseColor);
    DrawRectangle(x, y, width, height, inverseColor);
    DrawRectangle(x + 1, y + 1, width - 2, height - 2, colorFill);
    DrawRectangle(x + 2, y + 2, width - 4, height - 4, inverseColor);
    FillRegion(x + 3, y + 3, width - 6, height - 6, colorFill);
}

void DrawVolumeButton(int x, int y, int width, int height, int thickness, Color normal, Color bright, Color dark, bool isPressed, bool inShade) {
    if(inShade) {
        thickness = 1;
    }
#ifdef DISPLAY_COLOR
    FillRegion(x + thickness, y + thickness, width - thickness * 2, height - thickness * 2, normal);
    if(isPressed || inShade) {
        for(int i = 0; i < thickness; i++) {
            DrawHLine(y + i, x + i, x + width - i, dark);
            DrawVLine(x + i, y + 1 + i, y + height - i, dark);
            DrawVLine(x + width - i, y + 1 + i, y + height - i, bright);
            DrawHLine(y + height - i, x + 1 + i, x + width - i, bright);
        }
    } else {
        for(int i = 0; i < thickness; i++) {
            DrawHLine(y + i, x + i, x + width - i, bright);
            DrawVLine(x + i, y + 1 + i, y + height - i, bright);
            DrawVLine(x + width - i, y + 1 + i, y + height - i, dark);
            DrawHLine(y + height - i, x + 1 + i, x + width - i, dark);
        }
    }
#else
    DrawRectangle(x + 1, y + 1, width - 2, height - 2, ColorFill());
    DrawRectangle(x + thickness + 1, y + thickness + 1, width - thickness * 2 - 2, height - thickness * 2 - 2, ColorFill());
    bool pressOrShade = isPressed || inShade;
    if((IsInverseScreen() && pressOrShade) ||
        ((!IsInverseScreen()) && (!pressOrShade))) {
            for(int i = 0; i < thickness - 1; i++) {                                        //         |
                DrawHLine(y + height - i - 2, x + i + 2, x + width - i - 2, ColorFill());   //         |
                DrawVLine(x + width - i - 2, y + i + 2, y + height - i - 2, ColorFill());   //    _____|
        }
    } else if((IsInverseScreen() && (!pressOrShade)) ||
        ((!IsInverseScreen()) && pressOrShade)) {
            for(int i = 0; i < thickness - 1; i++) {                                   //   ________
                DrawHLine(y + i + 2, x + i + 2, x + width - i - 2, ColorFill());       //   |
                DrawVLine(x + i + 2, y + 1 + i + 2, y + height - i - 2, ColorFill());  //   |
        }
    }
#endif
}

void DrawRectangle(int x, int y, int width, int height, Color color) {
    DrawHLine(y, x, x + width, color);
    DrawVLine(x, y, y + height, color);
    DrawHLine(y + height, x, x + width, color);
    if(x + width < SCREEN_WIDTH) {
        DrawVLine(x + width, y, y + height, color);
    }
}

#ifdef DISPLAY_BLACK
void SetPoint(int x, int y) {
    if(x >= 0 && x < SCREEN_WIDTH && y >= 0 && y < SCREEN_HEIGHT) {
        SET_BIT_MASK(&(bufferDisplay[REQUIRED_BYTE(x, y)]), REQUIRED_BIT_MASK(x));
    }
}

void SetColorPoint(int x, int y, Color color) {
    if(color == ColorFill()) {
        SetPoint(x, y);
    } else {
        ClearPoint(x, y);
    }
}
#endif

int Display_DrawText(int x, int y, const char* text, Color color) {
    if(*text == 0) {
        return x;
    }
    
    CalculateColor(&color);
#ifdef DISPLAY_COLOR
    return DrawTextCol(x, y, text, color);
#else
    int retValue = x;
    while(*text) {
        x = Display_DrawChar(x, y, *text, color);
        retValue += LenghtSymbol(*text);
        text++;
    }
    return retValue + 1;
#endif
    
}

#ifdef DISPLAY_COLOR
int DrawTextWithLimitation(int x, int y, const char* text, Color color, int limitX, int limitY, int limitWidth, int limitHeight) {
    int retValue = x;
    while(*text) {
        x = DrawCharWithLimitation(x, y, *text, color, limitX, limitY, limitWidth, limitHeight);
        retValue += LenghtSymbol(*text);
        text++;
    }
    return retValue + 1;
}
#endif

int DrawTextWithBackGround(int x, int y, const char* text, Color color, bool backGround) {
    CalculateColor(&color);
    while(*text) {
        x = Display_DrawChar(x, y, *text, color);
        text++;
    }

    return x;
}

int DrawStringInCenterRect(int eX, int eY, int width, int eHeight, const char *text, Color color, bool backGround) {
    int lenght = LenghtText(text);
    int height = HeightSymbol(text[0]);
    int x = eX + (width - lenght) / 2;
    int y = eY + (eHeight - height) / 2;
    return DrawTextWithBackGround(x, y, text, color, backGround);
}

static int GetLenghtSubString(char *text) {
    int retValue = 0;
    while(((*text) != ' ') && ((*text) != '\0')) {
        retValue += LenghtSymbol(*text);
        text++;
    }
    return retValue;
}

static int DrawSubString(int x, int y, char *text, Color color) {
    int numSymbols = 0;
    while(((*text) != ' ') && ((*text) != '\0')) {
        x = Display_DrawChar(x, y, *text, color);
        numSymbols++;
        text++;
    }
    return numSymbols;
}

static int DrawSpaces(int x, int y, char *text, Color color, int *numSymbols) {
    *numSymbols = 0;
    while(*text == ' ') {
        x = Display_DrawChar(x, y, *text, color);
        text++;
        (*numSymbols)++;
    }
    return x;
}

void    DrawTextInRect(int x, int y, int width, int height, char *text, Color color) {
    int xStart = x;
    int xEnd = xStart + width;
    
    while(*text != 0) {
        int length = GetLenghtSubString(text);
        if(length + x > xEnd) {
            x = xStart;
            y += HeightSymbol(*text);
        }
        int numSymbols = 0;
        numSymbols = DrawSubString(x, y, text, color);
        text += numSymbols;
        x += length;
        x = DrawSpaces(x, y, text, color, &numSymbols);
        text += numSymbols;
    }
}

void DrawTextRelativelyRight(int xRight, int y, const char *text, Color color) {
    int lenght = LenghtText(text);
    Display_DrawText(xRight - lenght, y, text, color);
}

void ClearPoint(int x, int y) {
#ifdef DISPLAY_COLOR
    SetPointCol(x, y, ColorBack());
#else
    if(x >= 0 && x < SCREEN_WIDTH && y >= 0 && y < SCREEN_HEIGHT) {
        CLEAR_BIT_MASK(&(bufferDisplay[REQUIRED_BYTE(x, y)]), REQUIRED_BIT_MASK(x));
    }
#endif
}

#ifdef DISPLAY_BLACK
void DrawLine(int x1, int y1, int x2, int y2, Color color) {
    if((x2 - x1) == 0 && (y2 - y1) == 0) {
        x1++;
    }
    int16 x = x1;
    int16 y = y1;
    int16 dx = x2 - x1;
    if(dx < 0) {
        dx = -dx;
    }
    int16 dy = y2 - y1;
    if(dy < 0) {
        dy = -dy;
    }
    int8 s1 = (x2 - x1) < 0 ? -1 : 1;
    int8 s2 = (y2 - y1) < 0 ? -1 : 1;
    int16 temp;
    int16 exchange;
    if(dy > dx) {
        temp = dx;
        dx = dy;
        dy = temp;
        exchange = 1;
    } else {
        exchange = 0;
    }
    int16 e = 2 * dy - dx;
    for(int16 i = 0; i <= dx; i++) {
        SetColorPoint(x, y, color);
        while(e >= 0) {
            if(exchange) {
                x = x + s1;
            } else {
                y = y + s2;
            }
            e = e - 2 * dx;
        }
        if(exchange) {
            y = y + s2;
        } else {
            x = x + s1;
        }
        e = e + 2 * dy;
    }
}
#endif

void Display_DrawVPointLine(int x, int y0, int y1, float delta) {
#ifdef DISPLAY_COLOR
    DrawVPointLineCol(x, y0, delta, (y1 - y0) / delta, ColorGrid());
#else
    for(float y = y0; y < y1; y += delta) {
        Display_SetPoint(x, y, ColorGrid());
    }
#endif
}

void DrawDashedVLine(int x, int y0, int y1, int deltaFill, int deltaEmtpy, int deltaStart, Color color) {
    if(deltaStart < 0 || deltaStart >= (deltaFill + deltaEmtpy)) {
        LOG_ERROR("������������ �������� deltaStart = %d", deltaStart);
        return;
    }
    int y = y0;
    if(deltaStart != 0) {               // ���� ����� ����� �������� �� � ������ ������
        y += (deltaFill + deltaEmtpy - deltaStart); 
        if(deltaStart < deltaFill) {    // ���� ������ ����� ���������� �� �����
            DrawVLine(x, y0, y - 1, color);
        }
    }

    while(y < y1) {
        DrawVLine(x, y, y + deltaFill - 1, color);
        y += (deltaFill + deltaEmtpy);
    }
}

void DrawDashedHLine(int y, int x0, int x1, int deltaFill, int deltaEmpty, int deltaStart, Color color ) {
    if(deltaStart < 0 || deltaStart >= (deltaFill + deltaEmpty)) {
        LOG_ERROR("������������ �������� deltaStart = %d", deltaStart);
        return;
    }
    int x = x0;
    if(deltaStart != 0) {               // ���� ����� ����� �������� �� � ������ ������
        x += (deltaFill + deltaEmpty - deltaStart);
        if(deltaStart < deltaFill) {    // ���� ������ ����� ���������� �� �����
            DrawHLine(y, x0, x - 1, color);
        }
    }

    while(x < x1) {
        DrawHLine(y, x, x + deltaFill - 1, color);
        x += (deltaFill + deltaEmpty);
    }
}

bool BitInFontIsExist(int eChar, int numByte, int bit) {
    static uint8 prevByte = 0;
    static int prevChar = -1;
    static int prevNumByte = -1;
    if(prevNumByte != numByte || prevChar != eChar) {
        prevByte = font->symbol[eChar].bytes[numByte];
        prevChar = eChar;
        prevNumByte = numByte;
    }
    return prevByte & (1 << bit);
}

bool ByteFontNotEmpty(int eChar, int byte) {
    static uint8 *bytes = 0;
    static int prevChar = -1;
    if(eChar != prevChar) {
        prevChar = eChar;
        bytes = font->symbol[prevChar].bytes;
    }
    return bytes[byte];
}

void DrawChar(int eX, int eY, char symbol, Color color) {
    CalculateColor(&color);
#ifdef DISPLAY_COLOR
    DrawCharHardCol(eX, eY, symbol, color);
#else
    int8 width = font->symbol[symbol].width;
    int8 height = font->height;
    
    for(int b = 0; b < height; b++) {
        if(ByteFontNotEmpty(symbol, b)) {
            int x = eX;
            int y = eY + b + 9 - height;
            int endBit = 8 - width;
            for(int bit = 7; bit >= endBit; bit--) {
                if(BitInFontIsExist(symbol, b, bit)) {
                    SetColorPoint(x, y, color);
                }
                x++;
            }
        }
    }
#endif
}

#ifdef DISPLAY_COLOR
int DrawCharWithLimitation(int eX, int eY, char symbol, Color color, int limitX, int limitY, int limitWidth, int limitHeight) {
    int8 width = font->symbol[symbol].width;
    int8 height = font->height;

    for(int b = 0; b < height; b++) {
        if(ByteFontNotEmpty(symbol, b)) {
            int x = eX;
            int y = eY + b + 9 - height;
            int endBit = 8 - width;
            for(int bit = 7; bit >= endBit; bit--) {
                if(BitInFontIsExist(symbol, b, bit)) {
                    if((x >= limitX) && (x <= (limitX + limitWidth)) && (y >= limitY) && (y <= limitY + limitHeight)) {
                        SetPointCol(x, y, color);
                    }
                }
                x++;
            }
        }
    }

    return eX + width + 1;
}
#endif

#ifdef DISPLAY_COLOR
void DrawCharInColorDisplay(int eX, int eY, char symbol, Color color) {
    CalculateColor(&color);
    int8 width = font->symbol[symbol].width;
    int8 height = font->height;

    for(int b = 0; b < height; b++) {
        if(ByteFontNotEmpty(symbol, b)) {
            int x = eX;
            int y = eY + b + 9 - height;
            int endBit = 8 - width;
            for(int bit = 7; bit >= endBit; bit--) {
                if(BitInFontIsExist(symbol, b, bit)) {
                    SetPointCol(x, y, color);
                }
                x++;
            }
        }
    }
}
#endif

void Draw2Symbols(int x, int y, char symbol1, char symbol2, Color color1, Color color2) {
    Display_DrawChar(x, y, symbol1, color1);
    Display_DrawChar(x, y, symbol2, color2);
}

void ResetFlash() {
    Timer_SetTimer(Timer_FlashDisplay, 400, OnTimerFlashDisplay);
    inverseColors = false;
}

void Draw4SymbolsInRect(int x, int y, char eChar, Color color) {
    for(int i = 0; i < 2; i++) {
        Display_DrawChar(x + 8 * i, y, eChar + i, color);
        Display_DrawChar(x + 8 * i, y + 8, eChar + i + 16, color);
    }
}

void Draw10SymbolsInRect(int x, int y, char eChar, Color color) {
    CalculateColor(&color);
    for(int i = 0; i < 5; i++) {
        DrawChar(x + 8 * i, y, eChar + i, color);
        DrawChar(x + 8 * i, y + 8, eChar + i + 16, color);
    }
}

int LenghtSymbol(char symbol) {
    return font->symbol[symbol].width + 1;
}

int HeightSymbol(char symbol) {
    return 9;
}

void CalculateColor(uint8 *color) {
    if(*color == FLASH_10) {
        *color = inverseColors ? ColorBack() : ColorFill();
    } else if(*color == FLASH_01) {
        *color = inverseColors ? ColorFill() : ColorBack();
    }
}

void OnTimerFlashDisplay() {
    inverseColors = !inverseColors;
}
