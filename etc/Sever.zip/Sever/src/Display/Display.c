/// @file

#include "../defines.h"
#include "../Settings/SettingsTypes.h"
#include "../Menu/Pages/PageDisplay.h"
#include "../USB/v-com-api.h"
#include "../Menu/Pages/PageTime.h"
#include "Display.h"
#include "DisplayDrawing.h"
#include "Help.h"
#include "DisplayDrawingCol.h"
#include "Font.h"
#include "Colors.h"
#include "../FPGA/FPGA_Settings.h"
#include "../FPGA/FPGA.h"
#include "../FPGA/FPGA_Types.h"
#include "../FPGA/DataStorage.h"
#include "../Hardware/FSMC.h"
#include "../Hardware/FLASH.h"
#include "../Hardware/HAL.h"
#include "../Menu/Menu.h"
#include "../Menu/MenuDrawing.h"
#include "../Menu/Pages/PageCursors.h"
#include "../Menu/Pages/PageMemory.h"
#include "../Menu/Pages/PageHelp.h"
#include "../Menu/Pages/HelpContent.h"
#include "../Menu/Pages/PageChannels.h"
#include "../Menu/Pages/PageDebug.h"
#include "../Menu/Pages/PageTrig.h"
#include "../Math/Measures.h"
#include "../Menu/Pages/PageMeasures.h"
#include "../Settings/Settings.h"
#include "../Math/Math.h"
#include "../Math/GlobalFunctions.h"
#include "../Math/ProcessingSignal.h"
#include "../Timer.h"
#include "../Log.h"
#include "../USB/usbh_usr.h"

#include <string.h>
#include <math.h>
#include <stdio.h>

extern bool displayIsConnected;

/** @addtogroup DISPLAY
    @{ */

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifdef DISPLAY_BLACK

static const uint8 COM_SYSTEM_SET   = 0x40;
static const uint8 COM_MWRITE       = 0x42;
// static const uint8 COM_MREAD        = 0x43;
static const uint8 COM_SCROLL       = 0x44;
static const uint8 COM_CSRW         = 0x46;
// static const uint8 COM_CSRR         = 0x47;
static const uint8 COM_DISP_ON      = 0x59;
static const uint8 COM_HDOT_SCR     = 0x5a;
static const uint8 COM_OVLAY        = 0x5b;
static const uint8 COM_CSRFORM      = 0x5d; 

#endif

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define READ_PARAMETER                    (*ADDR_DISPLAY_D7_D0)
#define WRITE_COMMAND(data)                *ADDR_DISPLAY_A0 = (data);
#define WRITE_TO_ADDRESS(address, data)    WRITE_COMMAND(COM_CSRW);    WRITE_ADDRESS(address);    WRITE_COMMAND(COM_MWRITE);    WRITE_PARAMETER(data);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef DISPLAY_BLACK
        uint8       bufferDisplay[SIZE_BUFFER_FOR_SCREEN] = {0};
#endif
#define NUM_P2P_POINTS (FPGA_MAX_POINTS)
static  uint8       dataP2P[2][NUM_P2P_POINTS];
static  bool        dataP2PIsEmpty = true;          // ������� ����, ��� ���������� �����.
static  int         lastP2Pdata = 0;
static  bool        showLevelRShift[2] = {false, false};
static  bool        trigEnable = false;
static  DrawMode    mode = DrawMode_Auto;
static  bool        drawRShiftMarkers = false;

#define DELTA_Y                 5
#define MAX_NUM_STRINGS         175
#define SIZE_BUFFER_FOR_STRINGS 5170
static char                     *strings[MAX_NUM_STRINGS] = {0};
static char                     bufferForStrings[SIZE_BUFFER_FOR_STRINGS] = {0};
static int                      lastStringForPause = -1;

#define NUM_WARNINGS            10
static const char               *warnings[NUM_WARNINGS] = {0};      ///< ����� ��������������� ���������.
static uint                     timeWarnings[NUM_WARNINGS] = {0};   ///< ����� �����, ����� ��������������� ��������� ��������� �� �����.

Redraw redraw = {
    true,
    true
};

static bool volatile requiredFinishDraw = false;
static pFuncVV funcOnHand       = 0;
static pFuncVV funcAdditionDraw = 0;

extern Font *font;
extern Font *fonts[TypeFont_Number];
extern uint8 font5display[3080];
extern uint8 font8display[3080];
extern uint8 fontUGOdisplay[3080];
extern uint8 fontUGO2display[3080];

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef DISPLAY_BLACK
static void InitHardware(void);                         ///< ������������� ���������� ����� �����-������ �������.
#endif
static void InitHelp(void);                             ///< ������������� ������. ����������� ������ ����.
static void DrawGrid(void);                             ///< ���������� �����.
static void DrawCursorsWindow(void);                    
static void DrawCursorRShift(Channel chan);             ///< ���������� ������� �������� �� ����������.
static void DrawCursorTrigLevel(void);                  ///< ���������� ������ ������ �������������.
static void DrawCursorTShift(void);                     ///< ���������� ������ �������� �� �������.
static void DrawLowPart(void);                   ///< �������� ���������� ��� ������ - � ������ ����� �������.
static void DrawDataChannel(const uint8 *data, Channel chan); ///< ���������� ������ �������.
static void DrawHiPart(void);                           ///< ���������� ���������� ��� ������.
static void DrawHiRightPart(void);
static void DrawMemoryWindow(void);                     ///< ���������� ���� ������.
static bool DrawData(void);                             ///< ���������� ������.
static void DrawTime(int x, int y);                     ///< ������� ������� �����.
static void DrawCursors(void);                          ///< ���������� ������� ��������� ���������.
static void WriteCursors(void);                         ///< ������� �������� �������� ��������� ���������.
static void DrawMeasures(void);                         ///< ������� �������� �������������� ���������.
#ifdef DISPLAY_BLACK
static void SendScreenToHardware(void);                 ///< ����� ����� - ���������� �������� �� ������.
#endif
static void DisableShowLevelRShift0(void);              ///< ��������� ��������������� ����� ������� �������� �� ���������� ������� ������.
static void DisableShowLevelRShift1(void);              ///< ��������� ��������������� ����� ������� �������� �� ���������� ������� ������.
static void DrawConsole(void);                          ///< �������� ��������� ���������� �������.
static void DrawWarnings(void);                         ///< �������� ��������������.
static void OnRShiftMarkersAutoHide(void);
static void OnTimerShowWarning(void);
static void DrawTimeForFrame(uint timeMS);
static void WriteSmoothlyRanges(void);                  ///< ������� �������� ������� ��������� �� ��������� ����� �������, ���� ������� ����� �������� ��������� �������� �� ����������.
static void DrawHorizontalCursor                        ///  ���������� �������������� ������ ��������� ���������.
                                 (int y,                ///< �������� �������� �������.
                                 int xTearing,          ///< ���������� �����, � ������� ���������� ������� ������ ��� �������� �����������.
                                 Color color            ///< ����, ������� ��������.
                                 );
static void DrawVerticalCursor                          ///  ���������� ������������ ������ ��������� ���������.
                               (int x,                  ///< �������� �������� �������.
                               int yTearing,            ///< ���������� �����, � ������� ���������� ������� ������ ��� �������� �����������.
                               Color color              ///< ����, ������� ��������.
                               );

void WRITE_PARAMETER(uint8 parameter) {
    *ADDR_DISPLAY_D7_D0 = parameter;
    __asm { nop; nop; nop; nop; nop; nop; nop; nop; nop; nop; nop; nop; nop; nop; nop; nop; nop; nop; nop; nop; nop; nop; nop; nop; nop; nop; nop; nop; nop; nop; nop; nop; }
}

void WRITE_ADDRESS(uint address) {
    WRITE_PARAMETER((uint8)(address));    
    WRITE_PARAMETER((uint8)((address) >> 8));
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void Display_BeginScene(Color color) {
#ifdef DISPLAY_COLOR
    ClearScreenCol(color);
#else
    memset(bufferDisplay, (color == COLOR_WHITE) ? 0x00 : 0xff, SIZE_BUFFER_FOR_SCREEN);
#endif
}

void Display_DrawLine(int x0, int y0, int x1, int y1, Color color) {
#ifdef DISPLAY_COLOR
    if(x0 == x1) {
        DrawVLine(x0, y0, y1, color);
    } else if(y0 == y1) {
        DrawHLine(y0, x0, x1, color);
    }
#else
    if(x0 == x1) {
        DrawVLine(x0, y0, y1, color);
    } else if(y0 == y1) {
        DrawHLine(y0, x0, x1, color);
    } else {
        DrawLine(x0, y0, x1, y1, color);
    }
#endif
}

void Display_SetPoint(int x, int y, Color color) {
#ifdef DISPLAY_COLOR
    SetPointCol(x, y, color);
#else
    if(color == COLOR_BLACK) {
            SetPoint(x, y);
    } else {
            ClearPoint(x, y);
    }
#endif
}

void Display_ClearPoint(int x, int y) {
#ifdef DISPLAY_COLOR
    SetPointCol(x, y, COLOR_BLACK);
#else
    ClearPoint(x, y);
#endif
}

int Display_DrawChar(int x, int y , char symbol, Color color) {
#ifdef DISPLAY_COLOR
    if(GetSizeFont() == 5) {
        DrawCharHardCol(x, y + 3, symbol, color);
    } else if(GetSizeFont() == 8) {
        DrawCharHardCol(x, y, symbol, color);
    } else {
        DrawCharInColorDisplay(x, y, symbol, color);
    }
#else
    DrawChar(x, y, symbol, color);
#endif
    return x + LenghtSymbol(symbol);
}
void Display_DrawHPointLine(int y, int x0, int x1, float delta, bool multi) {
#ifdef DISPLAY_COLOR
    DrawHPointLineCol(x0, y, delta, (x1 - x0) / delta, COLOR_GRID, multi);
#else
    for(float x = x0; x < x1; x += delta) {
        Display_SetPoint(x, y, COLOR_BLACK);
    }
#endif
}

void Display_EndScene() {
#ifdef DISPLAY_COLOR
    SendToScreenCol();
    if(displayIsConnected) {
        static uint prevTime = 0;
        if(Timer_GetMS() - prevTime > 600) {
            SendScreenToComportCol();
            prevTime = Timer_GetMS();
        }
    }
#else
    SendScreenToHardware();
    if(displayIsConnected) {
        uint startTime = Timer_GetMS();
        static uint prevTime = 0;
        if(Timer_GetMS() - prevTime > 600) {
            for(int y = 0; y < 240; y++) {
                VCP_SendData(bufferDisplay + 40 * y, 40);
            }
            Log_Write("������� ��������");
            prevTime = Timer_GetMS();
        }
        //Log_Write("����� �������� %d", Timer_GetMS() - startTime);
    }
#endif
}

void Display_Init() {
    InitHelp();
    ResetFlash();
#ifdef DISPLAY_BLACK
    InitHardware();
    InitHardware();
#else
    LoadFontCol(TypeFont_5, font5display);
    LoadFontCol(TypeFont_8, font8display);
    LoadFontCol(TypeFont_UGO, fontUGOdisplay);
    LoadFontCol(TypeFont_UGO2, fontUGO2display);
    SetFontCol(TypeFont_8);
#endif
}

void DrawStringNavigation() {
    char *string = Menu_StringNavigation();
    if(string) {
        int length = LenghtText(string);
        int height = 10;
        DrawRectangle(GridLeft(), GridTop(), length + 2, height, ColorFill());
        FillRegion(GridLeft() + 1, GridTop() + 1, length, height - 2, ColorBack());
        Display_DrawText(GridLeft() + 2, GridTop() + 1, string, ColorFill());
    }
}

void Display_RotateRShift(Channel chan) {
    SetLastAffectedChannel(chan);
    if(GetTimeShowLevels()) {
        showLevelRShift[chan] = true;
        Timer_SetTimer((chan == Chan0) ? Timer_ShowLevelRShift0 : Timer_ShowLevelRShift1, GetTimeShowLevels() * 1000, (chan == Chan0) ? DisableShowLevelRShift0 : DisableShowLevelRShift1);
    };
    Display_Redraw();
};

void Display_Redraw(void) {
    requiredFinishDraw = true;
}

bool DrawData() {
    bool retValue = true;
    bool lastChannel1 = GetLastAffectedChannel() == Chan1;
    const uint8 *data0 = Processing_GetData(Chan0);
    const uint8 *data1 = Processing_GetData(Chan1);
    if(GetMemoryModeWork() == ModeWork_Latest) {
        int num = CurrentNumLatestSignal();
        const uint8 *data0 = DS_GetData(Chan0, num);
        const uint8 *data1 = DS_GetData(Chan1, num);
        DrawDataChannel(data0, Chan0);
        DrawDataChannel(data1, Chan1);
        int width = 40;
        int height = 10;
        FillRegion(GridRight() - width, GridTop(), width, height, ColorBack());
        DrawRectangle(GridRight() - width, GridTop(), width, height, ColorFill());
        Display_DrawText(GridRight() - width + 2, GridTop() + 1, Int2String(num + 1, false, 3), ColorFill());
        Display_DrawText(GridRight() - width + 17, GridTop() + 1, "/", ColorFill());
        Display_DrawText(GridRight() - width + 23, GridTop() + 1, Int2String(DS_AllDatas(), false, 3), ColorFill());
    } else if (!dataP2PIsEmpty) {
        if(lastChannel1) {
            if(ModeSelfRecorderEnable() || !DS_NumElementsWithCurrentSettings()) {
                DrawDataChannel(dataP2P[0], Chan0);
                DrawDataChannel(dataP2P[1], Chan1);
            } else {
                DrawDataChannel(data0, Chan0);
                DrawDataChannel(data1, Chan1);
            }
        } else {
            if(ModeSelfRecorderEnable() || !DS_NumElementsWithCurrentSettings()) {
                DrawDataChannel(dataP2P[1], Chan1);
                DrawDataChannel(dataP2P[0], Chan0);
            } else {
                DrawDataChannel(data1, Chan1);
                DrawDataChannel(data0, Chan0);
            }
        }
    } else if(GetNumAveraging() != 1) {
        if(lastChannel1) {
            DrawDataChannel(DS_GetAverageData(Chan0), Chan0);
            DrawDataChannel(DS_GetAverageData(Chan1), Chan1);
        } else {
            DrawDataChannel(DS_GetAverageData(Chan1), Chan1);
            DrawDataChannel(DS_GetAverageData(Chan0), Chan0);
        }
    } else {
        int16 numSignals = DS_NumElementsWithSameSettings();
        numSignals = LimitationInt(numSignals, 1, GetNumAccumulation());
        if(IsResetAccumulationSignals()) {
            static int allData = 0;
            if(allData != DS_AllDatas() ) {
                if(lastChannel1) {
                    DrawDataChannel(data0, Chan0);
                    DrawDataChannel(data1, Chan1);
                } else {
                    DrawDataChannel(data1, Chan1);
                    DrawDataChannel(data0, Chan0);
                }
                allData = DS_AllDatas();
            } else {
                retValue = false;
            }
        } else {
            for(int i = 0; i < numSignals; i++) {
                if(lastChannel1) {
                    DrawDataChannel(DS_GetData(Chan0, i), Chan0);
                    DrawDataChannel(DS_GetData(Chan1, i), Chan1);
                } else {
                    DrawDataChannel(DS_GetData(Chan1, i), Chan1);
                    DrawDataChannel(DS_GetData(Chan0, i), Chan0);
                }
                if(requiredFinishDraw) {
                    requiredFinishDraw = false;
                    break;
                }
            }
        }
    }

    if(GetNumMinMax() != 1) {
        ModeDrawSignal modeDrawSignalOld = GetModeDrawSignal();
        SetModeDrawSignal(ModeDrawSignal_Lines);
        if(lastChannel1) {
            DrawDataChannel(DS_GetLimitation(Chan0, 0), Chan0);
            DrawDataChannel(DS_GetLimitation(Chan0, 1), Chan0);
            DrawDataChannel(DS_GetLimitation(Chan1, 0), Chan1);
            DrawDataChannel(DS_GetLimitation(Chan1, 1), Chan1);
        } else {
            DrawDataChannel(DS_GetLimitation(Chan1, 0), Chan1);
            DrawDataChannel(DS_GetLimitation(Chan1, 1), Chan1);
            DrawDataChannel(DS_GetLimitation(Chan0, 0), Chan0);
            DrawDataChannel(DS_GetLimitation(Chan0, 1), Chan0);
        }
        SetModeDrawSignal(modeDrawSignalOld);
    }

    DrawRectangle(GridLeft(), GridTop(), GridWidth(), GridHeight(), ColorFill());

    return retValue;
}

void DrawTime(int x, int y) {
    int dField = 10;
    int dSeparator = 2;
    Display_DrawText(x, y, Int2String(HAL_GetHours(), false, 2), ColorFill());
    Display_DrawText(x + dField, y, ":", ColorFill());
    Display_DrawText(x + dField + dSeparator, y, Int2String(HAL_GetMinutes(), false, 2), ColorFill());
    Display_DrawText(x + 2 * dField + dSeparator, y, ":", ColorFill());
    Display_DrawText(x + 2 * dField + 2 * dSeparator, y, Int2String(HAL_GetSeconds(), false, 2), ColorFill());
}

void DrawHiPart() {
    WriteCursors();
    DrawHiRightPart();
}

void DrawDataInRect(int x, int width, const uint8 *data, int numElems, Channel chan) {
    if(numElems == 0) {
        return;
    }

    width--;
    float elemsInColumn = (float)numElems / (float)width;
    static uint8 min[300];
    static uint8 max[300];
    for(int col = 0; col < width; col++) {
        int firstElem = col * elemsInColumn;
        int lastElem = firstElem + elemsInColumn - 1;
        min[col] = data[firstElem];
        max[col] = data[firstElem];
        for(int elem = firstElem + 1; elem <= lastElem; elem++) {
            if(data[elem] < min[col]) {
                min[col] = data[elem];
            }
            if(data[elem] > max[col]) {
                max[col] = data[elem];
            }
        }
    }
#ifdef DISPLAY_BLACK
    int bottom = 15;
    int height = 12;
    float scale = (float)height / (MAX_VALUE - MIN_VALUE);
#else
    int bottom = 16;
    int height = 14;
    float scale = (float)height / (float)(MAX_VALUE - MIN_VALUE);
#endif

#define ORDINATE(x) bottom - scale * LimitationInt(x - MIN_VALUE, 0, 200)

#ifdef DISPLAY_COLOR
    static const int NUM_POINTS = 300 * 2;
    static uint8 points[NUM_POINTS];

    points[0] = ORDINATE(max[0]);
    points[1] = ORDINATE(min[0]);

    for(int i = 1; i < width; i++) {

        int value0 = min[i] > max[i - 1] ? max[i - 1] : min[i];
        int value1 = max[i] < min[i - 1] ? min[i - 1] : max[i];
        points[i * 2] = ORDINATE(value1);
        points[i * 2 + 1] = ORDINATE(value0);
    }
	if(width < 256) {
		DrawVLineArrayCol(x, width, points, ColorChannel(chan));
	} else {
		DrawVLineArrayCol(x, 255, points, ColorChannel(chan));
		DrawVLineArrayCol(x + 255, width - 255, points + 255 * 2, ColorChannel(chan));
	}
#else
    Display_DrawLine(x, ORDINATE(max[0]), x, ORDINATE(min[0]), ColorChannel(chan));
    for(int i = 1; i < width; i++) {
        int value0 = min[i] > max[i - 1] ? max[i - 1] : min[i];
        int value1 = max[i] < min[i - 1] ? min[i - 1] : max[i];
        Display_DrawLine(i + x, ORDINATE(value1), i + x, ORDINATE(value0), ColorChannel(chan));
    }
#endif
}

void DrawChannelInWindowMemory(int timeWindowRectWidth, int xVert0, int xVert1, int startI, int endI, const uint8 *data, int rightX, Channel chan) {
    if(data == dataP2P[0] && data == dataP2P[1]) {

    } else {
        DrawDataInRect(1,          xVert0 - 1,              &(data[0]),        startI,                       chan);
        DrawDataInRect(xVert0 + 2, timeWindowRectWidth - 2, &(data[startI]),   281,                          chan);
        DrawDataInRect(xVert1 + 2, rightX - xVert1 + 2,     &(data[endI + 1]), GetMemoryNumPoints(false) - endI,  chan);
    }
}

void DrawMemoryWindow(void) {
    int leftX = 3;
    int top = 1;
    int height = GRID_TOP - 3;
    int bottom = top + height;
    int rightX = NecessaryDrawCursors() ? 39 : 247;
    if(GetMemoryModeWork() == ModeWork_Direct) {
        rightX += 29;
    }
    int timeWindowRectWidth = (rightX - leftX) * (282.0f / GetMemoryNumPoints(false));
    float scaleX = (float)(rightX - leftX + 1) / GetMemoryNumPoints(false);

    int startI = GetShiftInMemory();
    int endI = startI + 281;

    const int xVert0 = leftX + GetShiftInMemory() * scaleX;
    const int xVert1 = leftX + GetShiftInMemory() * scaleX + timeWindowRectWidth;
    DrawRectangle(xVert0, top + (IsShowFullMemoryWindow() ? 0 : 1), xVert1 - xVert0, bottom - top - (IsShowFullMemoryWindow() ? 0 : 2), ColorFill());

    const uint8* data0 = Processing_GetData(Chan0);
    const uint8* data1 = Processing_GetData(Chan1);
    
    if(!dataP2PIsEmpty) {
        data0 = dataP2P[0];
        data1 = dataP2P[1];
    }

    if (IsShowFullMemoryWindow()) {
        if (data0 || data1 || !dataP2PIsEmpty) {
            Channel chanFirst = GetLastAffectedChannel() == Chan0 ? Chan1 : Chan0;
            Channel chanSecond = GetLastAffectedChannel() == Chan0 ? Chan0 : Chan1;
            const uint8 *dataFirst = GetLastAffectedChannel() == Chan0 ? data1 : data0;
            const uint8 *dataSecond = GetLastAffectedChannel() == Chan0 ? data0 : data1;

            if (IsChannelEnable(chanFirst)) {
                DrawChannelInWindowMemory(timeWindowRectWidth, xVert0, xVert1, startI, endI, dataFirst, rightX, chanFirst);
            }
            if (IsChannelEnable(chanSecond)) {
                DrawChannelInWindowMemory(timeWindowRectWidth, xVert0, xVert1, startI, endI, dataSecond, rightX, chanSecond);
            }
        }
    } else {
        DrawVLine(leftX - 2, top, bottom, ColorFill());
        DrawVLine(rightX + 2, top, bottom, ColorFill());
        DrawHLine((bottom + top) / 2 - 3, leftX, xVert0 - 2, ColorFill());
        DrawHLine((bottom + top) / 2 + 3, leftX, xVert0 - 2, ColorFill());
        DrawHLine((bottom + top) / 2 + 3, xVert1 + 2, rightX, ColorFill());
        DrawHLine((bottom + top) / 2 - 3, xVert1 + 2, rightX, ColorFill());
    }

    int numPoints = GetMemoryNumPoints(false);

    int x[] = {leftX, (rightX - leftX) / 2 + leftX + 1, rightX};
    int x0 = x[GetTPos()];


    // ������ TPos
    FillRegion(x0 - 3, 9, 6, 6, ColorBack());
    Display_DrawChar(x0 - 3, 9, '\x8a', ColorFill());

    // ������ tShift
    float scale = (float)(rightX - leftX + 1) / ((float)GetMemoryNumPoints(false) - (GetMemoryNumPoints(false) == 281 ? 1 : 0));
    float xShift = 1 + (GetTPosInPoints() - GetTShiftInPoints()) * scale;

    FillRegion(xShift - 1, 3, 6, 6, ColorBack());
    FillRegion(xShift, 4, 4, 4, ColorFill());
    Color color = ColorBack();
    if(xShift < leftX - 2) {
        xShift = leftX - 2;
        Display_DrawLine(xShift + 3, 5, xShift + 3, 7, color);
        Display_DrawLine(xShift + 1, 6, xShift + 2, 6, color);
    } else if(xShift > rightX - 1) {
        xShift = rightX - 2;
        Display_DrawLine(xShift + 1, 5, xShift + 1, 7, color);
        Display_DrawLine(xShift + 2, 6, xShift + 3, 6, color);
    } else {
        Display_DrawLine(xShift + 1, 5, xShift + 3, 5, color);
        Display_DrawLine(xShift + 2, 6, xShift + 2, 7, color);
    }
}

void WriteCursors() {
    int startX = 43;
    if(GetMemoryModeWork() == ModeWork_Direct) {
        startX += 29;
    }
    int x = startX;
    int y1 = 0;
    int y2 = 9;
    if(NecessaryDrawCursors()) {
        DrawVLine(x, 1, GRID_TOP - 2, ColorFill());
        x += 3;
        Channel source = GetCursSource();
        if(GetCursCntrlU(source) != CursCntrl_Disable) {
            Display_DrawText(x, y1, "1:", ColorFill());
            Display_DrawText(x, y2, "2:", ColorFill());
            x += 7;
            Display_DrawText(x, y1, GetCursorVoltage(source, 0), ColorFill());
            Display_DrawText(x, y2, GetCursorVoltage(source, 1), ColorFill());
            x = startX + 49;
            float pos0 = Math_VoltageCursor(GetCursPosU(source, 0), GetRange(source));
            float pos1 = Math_VoltageCursor(GetCursPosU(source, 1), GetRange(source));
            float delta = fabs(pos1 - pos0);
            Display_DrawText(x, y1, ":dU=", ColorFill());
            Display_DrawText(x + 17, y1, Voltage2String(delta, false), ColorFill());
            Display_DrawText(x, y2, ":", ColorFill());
            Display_DrawText(x + 10, y2, GetCursorPercentsU(source), ColorFill());
        }

        x = startX + 101;
        DrawVLine(x, 1, GRID_TOP - 2, ColorFill());
        x += 3;
        if(GetCursCntrlT(source) != CursCntrl_Disable) {
            Display_DrawText(x, y1, "1:", ColorFill());
            Display_DrawText(x, y2, "2:", ColorFill());
            x+=7;
            Display_DrawText(x, y1, GetCursorTime(source, 0), ColorFill());
            Display_DrawText(x, y2, GetCursorTime(source, 1), ColorFill());
            x = startX + 153;
            float pos0 = Math_TimeCursor(GetCursPosT(source, 0), GetTBase());
            float pos1 = Math_TimeCursor(GetCursPosT(source, 1), GetTBase());
            float delta = fabs(pos1 - pos0);
            Display_DrawText(x, y1, ":dT=", ColorFill());
            Display_DrawText(x + 17, y1, Time2String(delta, false), ColorFill());
            Display_DrawText(x, y2, ":", ColorFill());
            Display_DrawText(x + 8, y2, GetCursorPercentsT(source), ColorFill());

            if(IsShowFreqdTcursors()) {
                int width = 65;
                int x = GridRight() - width;
                DrawRectangle(x, GridTop(), width, 12, ColorFill());
                FillRegion(x + 1, GridTop() + 1, width - 2, 10, ColorBack());
                Display_DrawText(x + 1, GridTop() + 2, "1/dT=", ColorFill());
                Display_DrawText(x + 25, GridTop() + 2, Freq2String(1.0f / delta, false), ColorFill());
            }
        }
    }
}

void DrawHiRightPart() {
    // �������������
    int y = 2;
    int x = GetMemoryModeWork() == ModeWork_Direct ? 280 : 251;
    
    Color color = ColorFill();

    DrawVLine(x, 1, GRID_TOP - 2, color);

    x += 2;

    if(trigEnable) {
        FillRegion(x, 1 + y, GRID_TOP - 3, GRID_TOP - 7, color);
        Display_DrawText(x + 3, 3 + y, GetLanguage() == Russian ? "��" : "Tr", ColorBack());
    }

    // ����� ������
    static const char *strings[][2] = {
        {"���",     "MEAS"},
        {"����",    "LAST"},
        {"����",    "INT"}
    };

    if(GetMemoryModeWork() != ModeWork_Direct) {
        x += 18;
        DrawVLine(x, 1, GRID_TOP - 2, color);
        x += 2;
        Display_DrawText(GetLanguage() == Russian ? x : x + 3, -1, GetLanguage() == Russian ? "�����" : "mode", color);
        DrawStringInCenterRect(x + 1, 9, 25, 8, strings[GetMemoryModeWork()][GetLanguage()], color, false);
    } else {
        x -= 9;
    }
    x += 27;
    DrawVLine(x, 1, GRID_TOP - 2, color);

    x += 2;
    y = 1;
    if(FPGA_State() == StateFPGA_Work) {
        Draw4SymbolsInRect(x, 1, '\xae', color);
    } else if(FPGA_State() == StateFPGA_Stop) {
        FillRegion(x + 3, y + 3, 10, 10, color);
    } else if(FPGA_State() == StateFPGA_Wait) {
        int w = 4;
        int h = 14;
        int delta = 4;
        x = x + 2;
        FillRegion(x, y + 1, w, h, color);
        FillRegion(x + w + delta, y + 1, w, h, color);
    }
}

void DrawCursorsRShift() {
    if(GetLastAffectedChannel() == Chan1) {
        DrawCursorRShift(Chan0);
        DrawCursorRShift(Chan1);
    } else {
        DrawCursorRShift(Chan1);
        DrawCursorRShift(Chan0);
    }
}

void DrawMemoryWave(int num, bool exist) {
    int x = GridLeft() + 2 + num * 12;
    int y = GridBottom() - 10;
    int width = 12;
    FillRegion(x, y, width, 10, ColorBack());
    DrawRectangle(x, y, width, 10, ColorFill());
    if(exist) {
        Display_DrawText(x + 2, y + 1, Int2String(num + 1, false, 2), ColorFill());
    }
}

void ShowStateMemory() {
    bool exist[MAX_NUM_SAVED_WAVES] = {false};

    FLASH_GetDataInfo(exist);

    for(int i = 0; i < MAX_NUM_SAVED_WAVES; i++) {
        DrawMemoryWave(i, exist[i]);
    }
}

void Display_Update() {

    if (Help_IsShown()) {
        Display_BeginScene(ColorBack());
        HelpContent_Draw();
        Menu_Draw();
        Display_EndScene();
        return;
    }

    if(mode == DrawMode_Hand) {
        if(funcOnHand) {
            funcOnHand();
            Display_EndScene();
        }
        return;
    }

    static uint timeDraw = 0;
    static int numAccumDrawing = 0;                     // ���������� ������������ � ������ ���������� ��������

    if(requiredFinishDraw) {
        numAccumDrawing = GetNumAccumulation() + 1;
        requiredFinishDraw = 0;
    }
    if( GetNumAccumulation() > 1 &&                 // ���� ������� ����� ����������
        IsResetAccumulationSignals() &&             // � ������������ ����� ������
        numAccumDrawing < GetNumAccumulation()) {   // � ����� ������������ �������� ������ ���������
                                                    // �� ������ ������ ��� ���� ������
        if(DrawData()) {
            numAccumDrawing++;
        }
    } else {
        numAccumDrawing = 0;
        uint time = Timer_GetMultiMeasTicks();
        Help_ClearBase();
        Display_BeginScene(ColorBack());
        Processing_CalculateMeasures();
        DrawMemoryWindow();
        DrawGrid();
        DrawData();
        DrawCursors();
        DrawHiPart();
        DrawLowPart();
        DrawCursorsWindow();
        DrawCursorTrigLevel();
        DrawCursorsRShift();
        DrawMeasures();
        DrawStringNavigation();
        DrawCursorTShift();
        
        timeDraw = Timer_GetMultiMeasTicks() - time;
    }
    uint time = Timer_GetMultiMeasTicks();
    Menu_Draw();
    DrawWarnings();
    Help_Draw();
    WriteSmoothlyRanges();
    if(GetMemoryModeWork() == ModeWork_MemInt) {
        ShowStateMemory();
    }
    if(funcAdditionDraw) {
        funcAdditionDraw();
    }

    DrawConsole();

    DrawTimeForFrame(Timer_GetMultiMeasTicks() - time + timeDraw);

    Display_EndScene();
}

void DrawGrid() {
    int left = GridLeft();
    int top = GridTop();
    int right = GridRight();
    int bottom = GridBottom();
    int width = GridWidth();
    int height = GridHeight();

    DrawHLine(top, 1, left - 2, ColorFill());
    DrawHLine(top, right + 2, SCREEN_WIDTH - 2, ColorFill());

    if(!MenuIsMinimize()) {
        
        DrawVLine(1, top + 2, bottom - 2, ColorFill());
        DrawVLine(318, top + 2, bottom - 2, ColorFill());
        /*
        Display_DrawVPointLine(1, top + 2, bottom - 2, 4);
        Display_DrawVPointLine(318, top + 2, bottom - 2, 4);
        */
    }

    float deltaX = GRID_DELTA * (float)width / GridWidth();
    float deltaZ = GRID_DELTA * (float)height / GRID_HEIGHT;
    float stepX = deltaX / 5;
    float stepZ = deltaZ / 5;

#ifdef DISPLAY_COLOR
#else
    if(GetTypeGrid() == 1) {
        Display_DrawVPointLine(left + 1, top + stepZ, bottom, stepZ);
        Display_DrawVPointLine(left + 2, top + deltaZ, bottom, deltaZ);
        Display_DrawVPointLine(right - 1, top + stepZ, bottom, stepZ);
        Display_DrawVPointLine(right - 2, top + deltaZ, bottom, deltaZ);

        Display_DrawHPointLine(top + 1, left + stepX, right, stepX, false);
        Display_DrawHPointLine(top + 2, left + deltaX, right, deltaX, false);
        Display_DrawHPointLine(bottom - 1, left + stepX, right, stepX, false);
        Display_DrawHPointLine(bottom - 2, left + deltaX, right, deltaX, false);
    }
#endif

    int centerX = left + width / 2;
    int centerY = top + height / 2;
    if(GetTypeGrid() == TypeGrid_2) {
        Display_DrawHPointLine(centerY, left + stepX, right, stepX, false);
        Display_DrawHPointLine(centerY - 1, left + deltaX, right, deltaX, false);
        Display_DrawHPointLine(centerY + 1, left + deltaX, right, deltaX, false);
        Display_DrawVPointLine(centerX, top + stepZ, bottom, stepZ);
        Display_DrawVPointLine(centerX - 1, top + deltaZ, bottom, deltaZ);
        Display_DrawVPointLine(centerX + 1, top + deltaZ, bottom, deltaZ);
    } else if(GetTypeGrid() == TypeGrid_1) {
#ifdef DISPLAY_COLOR
            uint16 masX[20];
            masX[0] = GridLeft() + 1;
            for(int i = 1; i < 7; i++) {
                masX[i] = GridLeft() + deltaX * i;
            }
            for(int i = 7; i < 10; i++) {
                masX[i] = centerX - 8 + i;
            }
            for(int i = 10; i < 16; i++) {
                masX[i] = centerX + deltaX * (i - 9);
            }
            masX[16] = GridRight() - 1;
            DrawMultiVPointLineCol(17, top + stepZ, masX, stepZ, (bottom - top - stepZ) / stepZ, ColorGrid());

            uint8 mas[15];
            mas[0] = GridTop() + 1;
            for(int i = 1; i < 5; i++) {
                mas[i] = GridTop() + deltaZ * i;
            }
            for(int i = 5; i < 8; i++) {
                mas[i] = centerY - 6 + i;
            }
            for(int i = 8; i < 12; i++) {
                mas[i] = centerY + deltaZ * (i - 7);
            }
            mas[12] = GridBottom() - 1;
            DrawMultiHPointLineCol(13, left + stepX, mas, stepX, (right - left - stepX) / stepX, ColorGrid()); 
#else
            for(int i = 0; i < 3; i++) {
                Display_DrawHPointLine(centerY - 1 + i, left + stepX, right, stepX, false);
                Display_DrawVPointLine(centerX - 1 + i, top + stepZ, bottom, stepZ);
            }
            for(float x = left + deltaX; x < right; x += deltaX) {
                Display_DrawVPointLine(x, top + stepZ, bottom, stepZ);
            }
            for(float y = top + deltaZ; y < bottom; y += deltaZ) {
                Display_DrawHPointLine(y, left + stepX, right, stepX, false);
            }
#endif
    }
}

#define  DELTA 5

void DrawScaleLine(int x, bool forTrigLev) {
    if(GetAltMarkers() == AltMarkers_Hide) {
        return;
    }
    int width = 6;
    int topY = GRID_TOP + DELTA;
    int x2 = width + x + 2;
    int bottomY  = GridBottom() - DELTA;
    int centerY = (GridBottom() + GRID_TOP) / 2;
    int levels[] = {
        topY,
        bottomY,
        centerY,
        centerY - (bottomY - topY) / (forTrigLev ? 8 : 4),
        centerY + (bottomY - topY) / (forTrigLev ? 8 : 4)
    };
    for(int i = 0; i < 5; i++) {
        Display_DrawLine(x + 1, levels[i], x2 - 1, levels[i], ColorFill());
    }
}

void DrawCursorsWindow() {
    if(!MenuIsMinimize() && drawRShiftMarkers) {
        DrawScaleLine(2, false);
    }
}

void DrawCursorTrigLevel() {
    TrigSource chan = GetTrigSource();
    int trigLev = GetTrigLev(chan) + ((chan == TrigSource_Ext) ? 0 : GetRShift((Channel)chan) - RShiftZero);
    float scale = 1.0f / ((TrigLevMax - TrigLevMin) / 2 / GridHeight());
    int y0 = (GRID_TOP + GridBottom()) / 2 + scale * (TrigLevZero - TrigLevMin);
    int y = y0 - scale * (trigLev - TrigLevMin);

    if(chan != TrigSource_Ext) {
        y = (y - GridCenterHeight()) * GetSmoothlyRangeScale((Channel)chan) + GridCenterHeight();
    }

    int x = GridRight() + (GridSizeChanged() && MenuIsShown() ? 80 : 0);
    if(y > GridBottom()) {
        Display_DrawChar(x + 3, GridBottom() - 11, '\x95', ColorTrig());
        Display_SetPoint(x + 5, GridBottom() - 2, ColorTrig());
        y = GridBottom() - 7;
        x--;
    } else if(y < GRID_TOP) {
        Display_DrawChar(x + 3, GRID_TOP + 2, '\x96', ColorTrig());
        Display_SetPoint(x + 5, GRID_TOP + 2, ColorTrig());
        y = GRID_TOP + 7;
        x--;
    } else {
        Display_DrawChar(x + 1, y - 4, '\x94', ColorTrig());
    }
    SetFont(TypeFont_5);

    const char simbols[3] = {'1', '2', '�'};
#ifdef DISPLAY_COLOR
    int dY = 0;
#else
    int dY = 3;
#endif
    
    Display_DrawChar(x + 5, y - 9 + dY, simbols[GetTrigSource()], ColorBack());
    SetFont(TypeFont_8);

    if(!MenuIsMinimize() && drawRShiftMarkers) {
        DrawScaleLine(SCREEN_WIDTH - 11, true);
        int left = GridRight() + 9 + (GridSizeChanged() && MenuIsShown() ? 80 : 0);
        int height = GridHeight() - 2 * DELTA;
        int shiftFullMin = RShiftMin + TrigLevMin;
        int shiftFullMax = RShiftMax + TrigLevMax;
        scale = (float)height / (shiftFullMax - shiftFullMin);
        int shiftFull = GetTrigLev(GetTrigSource()) + ((GetTrigSource() == TrigSource_Ext) ? 0 : GetRShift((Channel)chan));
        int yFull = GRID_TOP + DELTA + height - scale * (shiftFull - RShiftMin - TrigLevMin) - 4;
        FillRegion(left + 2, yFull + 1, 4, 6, ColorTrig());
        SetFont(TypeFont_5);
        Display_DrawChar(left + 3, yFull - 5 + dY, simbols[GetTrigSource()], ColorBack());
        SetFont(TypeFont_8);
    }
}

void DrawCursorRShift(Channel chan) {
    
    if(!IsChannelEnable(chan)) {
        return;
    }

    int rShift = GetRShift(chan);

    float scale = 100.0f / (float)GridHeight();
    float y0 = (GridTop() + GridBottom()) / 2 + scale * (RShiftZero - RShiftMin);
    float y = y0 - scale * (rShift - RShiftMin);
    
    y = (y - GridCenterHeight()) * GetSmoothlyRangeScale(chan) + GridCenterHeight();                        // ��������� ������� ��������� ��������.

    float x = GridRight() - GridWidth() - Measure_GetDeltaGridLeft();
    int deltaRShift = (int)RShiftMax - (int)RShiftMin;
    int height = GridHeight() - 2 * DELTA;
    float var1 = height / (float)deltaRShift;
    int yFull = GridTop() - DELTA + height - var1 * (rShift - 2 - RShiftMin) + 6;

    yFull = (yFull - GridCenterHeight()) * GetSmoothlyRangeScale(chan) + GridCenterHeight();                // ��������� ������� ��������� ��������.


    if(y > GridBottom()) {
        Display_DrawChar(x - 7, GridBottom() - 11, '\x95', ColorChannel(chan));
        Display_SetPoint(x - 5, GridBottom() - 2, ColorChannel(chan));
        y = GridBottom() - 7;
        x++;
    } else if(y < GridTop()) {
        Display_DrawChar(x - 7, GridTop() + 2, '\x96', ColorChannel(chan));
        Display_SetPoint(x - 5, GridTop() + 2, ColorChannel(chan));
        y = GridTop() + 7;
        x++;
    } else {
        Display_DrawChar(x - 8, y - 4, '\x93', ColorChannel(chan));
        if(showLevelRShift[chan]) {
            Display_DrawLine(GridLeft(), y, GridRight(), y, ColorChannel(chan));
        }
    }

    SetFont(TypeFont_5);
#ifdef DISPLAY_COLOR
    int dY = 0;
#else
    int dY = 3;
#endif

    if(!MenuIsMinimize() && drawRShiftMarkers) {
        FillRegion(4, yFull + 1, 4, 6, ColorChannel(chan));
        Display_DrawChar(5, yFull - 5 + dY, chan == Chan0 ? '1' : '2', ColorBack());
    }
    Display_DrawChar(x - 7, y - 9 + dY, chan == Chan0 ? '1' : '2', ColorBack());
    SetFont(TypeFont_8);
}

void DrawCursorTShift() {
    int starPoint = 0;
    int endPoint = 0;
    GetPointsOnDisplay(&starPoint, &endPoint);
    int shiftTPos = GetTPosInPoints() - GetShiftInMemory();
    float scale = (endPoint - starPoint) / GridWidth();
    int gridLeft = GridLeft();
    if(IntInRange(GetTPosInPoints(), starPoint, endPoint)) {
        int x = gridLeft + shiftTPos * scale - 3;
        /*
        if(GetTPos() != TPos_Left) {
            x -= 62;
        }
        */
        Draw2Symbols(x, GRID_TOP - 1, '\x8b', '\x8a', ColorBack(), ColorFill());
    };

    int shiftTShift = GetTPosInPoints() - GetTShiftInPoints();
    /*
    if(GetTPos() != TPos_Left) {
        shiftTShift -= 62;
    }
    */
    if(IntInRange(shiftTShift, starPoint, endPoint)) {
        int x = gridLeft + shiftTShift - starPoint - 3;
        Draw2Symbols(x, GRID_TOP - 1, '\x85', '\x84', ColorBack(), ColorFill());
    } else if(shiftTShift < starPoint) {
        Draw2Symbols(gridLeft + 1, GRID_TOP, '\x94', '\x86', ColorBack(), ColorFill());
        Display_DrawLine(GridLeft() + 9, GRID_TOP + 1, GridLeft() + 9, GRID_TOP + 7, ColorBack());
    } else if(shiftTShift > endPoint) {
        Draw2Symbols(GridRight() - 8, GRID_TOP, '\x93', '\x87', ColorBack(), ColorFill());
        Display_DrawLine(GridRight() - 9, GRID_TOP + 1, GridRight() - 9, GRID_TOP + 7, ColorBack());
    }
}

void DrawHorizontalCursor(int y, int xTearing, Color color) {
    y += GridTop();
    if(xTearing == -1) {
        DrawDashedHLine(y, GridLeft() + 2, GridRight() - 1, 1, 1, 0, color);
    } else {
        DrawDashedHLine(y, GridLeft() + 2, xTearing - 2, 1, 1, 0, color);
        DrawDashedHLine(y, xTearing + 2, GridRight() - 1, 1, 1, 0, color);
    }
    DrawRectangle(GridLeft() - 1, y - 1, 2, 2, color);
    DrawRectangle(GridRight() - 1, y - 1, 2, 2, color);
}

void DrawVerticalCursor(int x, int yTearing, Color color) {
    x += GridLeft();
    if(yTearing == -1) {
        DrawDashedVLine(x, GridTop() + 2, GridBottom() - 1, 1, 1, 0, color);
    } else {
        DrawDashedVLine(x, GridTop() + 2, yTearing - 2, 1, 1, 0, color);
        DrawDashedVLine(x, yTearing + 2, GridBottom() - 1, 1, 1, 0, color);
    }
    DrawRectangle(x - 1, GridTop() - 1, 2, 2, color);
    DrawRectangle(x - 1, GridBottom() - 1, 2, 2, color);
}

void DrawCursors() {
    Channel source = GetCursSource();
    Color color = ColorChannel(source);
    if(NecessaryDrawCursors()) {

        bool bothCursors = GetCursCntrlT(source) != CursCntrl_Disable && GetCursCntrlU(source) != CursCntrl_Disable;  // ������� ����, ��� �������� � ������������ � �������������� ������� - ���� ���������� �������� � ������ �����������

        int x0 = -1;
        int x1 = -1;
        int y0 = -1;
        int y1 = -1;

        if(bothCursors) {    
            x0 = GridLeft() + GetCursPosT(source, 0);
            x1 = GridLeft() + GetCursPosT(source, 1);
            y0 = GridTop() + GetCursPosU(source, 0) + MIN_VALUE;
            y1 = GridTop() + GetCursPosU(source, 1) + MIN_VALUE;

            DrawRectangle(x0 - 2, y0 - 2, 4, 4, color);
            DrawRectangle(x1 - 2, y1 - 2, 4, 4, color);
        }

        CursCntrl cntrl = GetCursCntrlT(source);
        if(cntrl != CursCntrl_Disable) {
            DrawVerticalCursor(GetCursPosT(source, 0), y0, color);
            DrawVerticalCursor(GetCursPosT(source, 1), y1, color);
        }
        cntrl = GetCursCntrlU(source);
        if(cntrl != CursCntrl_Disable) {
            DrawHorizontalCursor(GetCursPosU(source, 0) + MIN_VALUE, x0, color);
            DrawHorizontalCursor(GetCursPosU(source, 1) + MIN_VALUE, x1, color);
        }
    }
}

void DrawMeasures() {
    if(!IsShownMeasures()) {
        return;
    }

    if(GetMeasuresField() == MeasuresField_Hand) {
        int x0 = GetMeasuresFieldPosT(0) - GetShiftInMemory() + GridLeft();
        int y0 = GetMeasuresFieldPosU(0) + GridTop();
        int x1 = GetMeasuresFieldPosT(1) - GetShiftInMemory() + GridLeft();
        int y1 = GetMeasuresFieldPosU(1) + GridTop();
        SortInt(&x0, &x1);
        SortInt(&y0, &y1);
        DrawRectangle(x0, y0, x1 - x0, y1 - y0, ColorFill());
    }

    int x0 = GridLeft() - Measure_GetDeltaGridLeft();
    int dX = Measure_GetDX();
    int dY = Measure_GetDY();
    int y0 = Measure_GetTopTable();
    for(int str = 0; str < Measure_NumRows(); str++) {
        for(int elem = 0; elem < Measure_NumCols(); elem++) {
            int x = x0 + dX * elem;
            int y = y0 + str * dY;
            bool active = Measure_IsActive(str, elem) && GetMenuSmallButtonPage() == TypePageSB_MeasTuneMeas;
            Color color = active ? ColorBack() : ColorFill();
            Measure meas = Measure_Type(str, elem);
            if(meas != Measure_None) {
                FillRegion(x, y, dX, dY, ColorBack());
                DrawRectangle(x, y, dX, dY, ColorFill());
            }
            if(active) {
                FillRegion(x + 2, y + 2, dX - 4, dY - 4, ColorFill());
            }
            if(meas != Measure_None) {
                Display_DrawText(x + 4, y + 2, Measure_Name(str, elem), color);
                if(meas == GetMarkedMeasure()) {
                    FillRegion(x + 1, y + 1, dX - 2, 9, active ? ColorBack() : ColorFill());
                    Display_DrawText(x + 4, y + 2, Measure_Name(str, elem), active ? ColorFill() : ColorBack());
                }
                if(GetMeasuresSource() == Chan0) {
                    Display_DrawText(x + 2, y + 11, Processing_GetStringMeasure(meas, Chan0), color);
                } else if(GetMeasuresSource() == Chan1) {
                    Display_DrawText(x + 2, y + 11, Processing_GetStringMeasure(meas, Chan1), color);
                } else {
                    Display_DrawText(x + 2, y + 11, Processing_GetStringMeasure(meas, Chan0), color);
                    Display_DrawText(x + 2, y + 20, Processing_GetStringMeasure(meas, Chan1), color);
                }
            }
        }
    }

    if(GetMenuSmallButtonPage() == TypePageSB_MeasTuneMeas) {
        Measure_DrawPageChoice();
    }
}

void WriteTextVoltage(Channel chan, int x, int y) {
    static const char *couple[] = {
        "\x92",
        "\x91",
        "\x90"
    };
    Color color = ColorChannel(chan);

    if(IsChannelEnable(chan)) {
        const int widthField = 91;
        const int heightField = 8;
        Color colorDraw = IsChannelInverse(chan) ? COLOR_WHITE : color;

        if(IsChannelInverse(chan)) {
            FillRegion(x, y, widthField, heightField, color);
        }

        char buffer[100] = {0};
        sprintf(buffer, "%s\xa5%s\xa5%s", (chan == Chan0) ? (GetLanguage() == Russian ? "1�" : "1c") : (GetLanguage() == Russian ? "2�" : "2c"), couple[GetModeCouple(chan)], 
            IsSmoothlyRange(chan) ? " ": FPGA_GetRangeString(chan));

        Display_DrawText(x + 1, y, buffer, colorDraw);

        sprintf(buffer, "\xa5%s", FPGA_GetRShiftString(chan));
        Display_DrawText(x + 46, y, buffer, colorDraw);
    }
}

void WriteStringAndNumber(char *text, int16 x, int16 y, int number) {
    char buffer[100];
    Display_DrawText(x, y, text, ColorFill());
    if(number == 0) {
        sprintf(buffer, "-");
    } else {
        sprintf(buffer, "%d", number);
    }
    DrawTextRelativelyRight(x + 41, y, buffer, ColorFill());
}

void DrawLowPart() {

    int y0 = SCREEN_HEIGHT - 19;
    int y1 = SCREEN_HEIGHT - 10;
    int x = -1;

    DrawHLine(GRID_BOTTOM, 1, GridLeft() - Measure_GetDeltaGridLeft() - 2, ColorFill());

    WriteTextVoltage(Chan0, x + 2, y0);
    WriteTextVoltage(Chan1, x + 2, y1);

    DrawVLine(x + 95, GRID_BOTTOM + 2, SCREEN_HEIGHT - 2, ColorFill());

    x += 98;
    char buffer[100] = {0};
    sprintf(buffer, "�\xa5%s", FPGA_GetTBaseString());
    Display_DrawText(x, y0, buffer, ColorFill());

    buffer[0] = 0;
    sprintf(buffer, "\xa5%s", FPGA_GetTShiftString());
    Display_DrawText(x + 35, y0, buffer, ColorFill());

    buffer[0] = 0;
    const char *source[3] = {"1", "2", "\x82"};
    sprintf(buffer, "�\xa5\x10%s", source[GetTrigSource()]);
    Display_DrawText(x, y1, buffer, ColorTrig());

    buffer[0] = 0;
    static const char *couple[] = {
        "\x92",
        "\x91",
        "\x92",
        "\x92"
    };
    static const char *polar[] = {
        "\xa7",
        "\xa6"
    };
    static const char *filtr[] = {
        "\xb5\xb6",
        "\xb5\xb6",
        "\xb3\xb4",
        "\xb1\xb2"
    };
    sprintf(buffer, "\xa5\x10%s\x10\xa5\x10%s\x10\xa5\x10", couple[GetTrigInput()], polar[GetTrigPolarity()]);
    Display_DrawText(x + 18, y1, buffer, ColorTrig());
    Display_DrawChar(x + 45, y1, filtr[GetTrigInput()][0], ColorTrig());
    Display_DrawChar(x + 53, y1, filtr[GetTrigInput()][1], ColorTrig());

    buffer[0] = '\0';
    const char mode[] = {
        '\xb7',
        '\xa0',
        '\xb0'
    };
    sprintf(buffer, "\xa5\x10%c", mode[GetTrigStartMode()]);
    Display_DrawText(x + 63, y1, buffer, ColorTrig());
    
    DrawVLine(x + 79, GRID_BOTTOM + 2, SCREEN_HEIGHT - 2, ColorFill());

    DrawHLine(GRID_BOTTOM, GRID_RIGHT + 2, SCREEN_WIDTH - 2, ColorFill());

    x += 82;
    y0 = y0 - 3;
    y1 = y1 - 6;
    int y2 = y1 + 6;
    SetFont(TypeFont_5);
    
    WriteStringAndNumber("������", x, y0, GetNumAccumulation());
    WriteStringAndNumber("������", x, y1, GetNumAveraging());
    WriteStringAndNumber("��\x93���", x , y2, GetNumMinMax());

    x += 42;
    DrawVLine(x, GRID_BOTTOM + 2, SCREEN_HEIGHT - 2, ColorFill());

    SetFont(TypeFont_8);

    char mesFreq[20] = "\x7c=";
    float freq = FPGA_GetFreq();
    if(freq == -1.0f) {
        strcat(mesFreq, "******");
    } else {
        strcat(mesFreq, Freq2String(freq, false));
    }
    Display_DrawText(x + 3, GRID_BOTTOM + 2, mesFreq, ColorFill());

    DrawTime(x + 3, GRID_BOTTOM + 11);

    DrawVLine(x + 55, GRID_BOTTOM + 2, SCREEN_HEIGHT - 2, ColorFill());

    SetFont(TypeFont_UGO2);

    // ������
    if(FlashDriveIsConnected()) {
        Draw4SymbolsInRect(x + 57, GRID_BOTTOM + 2, '\x80', ColorFill());
    };

    // Ethernet
    //Draw4SymbolsInRect(x + 84, GRID_BOTTOM + 2, '\x82', ColorFill());

    // USB-���������� � �����������
    if(displayIsConnected) {
        Draw4SymbolsInRect(x + 72, GRID_BOTTOM + 2, '\x84', ColorFill());
    }

    // ������� ��������
    if(GetPeackDetEnable()) {
        Display_DrawChar(x + 38, GRID_BOTTOM + 11, '\x12', ColorFill());
        Display_DrawChar(x + 46, GRID_BOTTOM + 11, '\x13', ColorFill());
    }

    SetFont(TypeFont_5);
    WriteStringAndNumber("�����.:", x + 57, GRID_BOTTOM + 10, GetNumPointSmoothing());
    SetFont(TypeFont_8);
}

void DrawTimeForFrame(uint timeTicks) {
    if(!GetDebugShowStatsIsEnable()) {
        return;
    }
    static char buffer[100] = {0};
    static bool first = true;
    static uint timeMSstartCalculation = 0;
    static int numFrames = 0;
    static float numMS = 0.0f;
    if(first) {
        timeMSstartCalculation = Timer_GetMS();
        first = false;
    }
    numMS += timeTicks / 120000.0f;
    numFrames++;
    
    if((Timer_GetMS() - timeMSstartCalculation) >= 500) {
        sprintf(buffer, "%.1fms/%d", numMS / numFrames, numFrames * 2);
        timeMSstartCalculation = Timer_GetMS();
        numMS = 0.0f;
        numFrames = 0;
    }

    DrawRectangle(GridLeft(), GridBottom() - 10, 84, 10, ColorFill());
    FillRegion(GridLeft() + 1, GridBottom() - 9, 82, 8, ColorBack());
    Display_DrawText(GridLeft() + 2, GridBottom() - 9, buffer, ColorFill());

    char message[20] = {0};
    sprintf(message, "%d", DS_NumElementsWithSameSettings());
    strcat(message, "/");
    char numAvail[10] = {0};
    sprintf(numAvail, "%d", DS_NumberAvailableEntries());
    strcat(message, numAvail);
    Display_DrawText(GridLeft() + 50, GridBottom() - 9, message, ColorFill());
}

void WriteSmoothlyRanges() {
    if(!IsSmoothlyRange(Chan0) && !IsSmoothlyRange(Chan1)) {
        return;
    }
    static const int HEIGHT = 19;
    DrawRectangle(GridLeft(), GridBottom() - HEIGHT, 59, HEIGHT, ColorFill());
    FillRegion(GridLeft() + 1, GridBottom() - HEIGHT + 1, 57, HEIGHT - 2, ColorBack());

    char buffer[50] = {0};
    if(IsChannelEnable(Chan0) && IsSmoothlyRange(Chan0)) {
        sprintf(buffer, "%s/���.", Voltage2String(GetSmoothlyRangeInUV(Chan0) / 1e6, false));
        Display_DrawText(GridLeft() + 2, GridBottom() - HEIGHT + 1, buffer, ColorChannel(Chan0));
    }
    if(IsChannelEnable(Chan1) && IsSmoothlyRange(Chan1)) {
        sprintf(buffer, "%s/���.", Voltage2String(GetSmoothlyRangeInUV(Chan1) / 1e6, false));
        Display_DrawText(GridLeft() + 2, GridBottom() - HEIGHT / 2, buffer, ColorChannel(Chan1));
    }
}

uint8 CalculateFiltr(const uint8 *data, int x) {
    if(GetNumPointSmoothing() == 0) {
        return data[x];
    }
    int count = 1;
    int sum = data[x];
    int startDelta = 1;
    if(GetNumPointSmoothing() > 2) {
        int endDelta = GetNumPointSmoothing() / 2;
        for(int delta = startDelta; delta <= endDelta; delta++) {
            if(((x - delta) >= 0) && ((x + delta) < (GetMemoryNumPoints(false)))) {
                sum += data[x - delta];
                sum += data[x + delta];
                count += 2;
            }
        }
    }

    if((GetNumPointSmoothing() % 2) == 0) {
        int delta = GetNumPointSmoothing() / 2;
        if((x + delta) < GetMemoryNumPoints(false)) {
            sum += data[x + delta];
            count++;
        }
    }

    return sum / count;
}

int ConvertDataToDisplay(uint8 data, float scale) {
    return LimitationInt(GridBottom() - (data - MIN_VALUE) * scale, GridTop(), GridBottom());
}

static void DrawSignalLined(const uint8 *data, Color color, int startPoint, int endPoint, float scale, float scaleX) {

#ifdef DISPLAY_COLOR
    uint8 dataCD[281];
#endif

    for(int i = startPoint; i < endPoint; i++) {

        float x0 = GridLeft() + (i - startPoint) * scaleX;

        if(GetPeackDetEnable()) {
            int bottom = GridBottom();
            if(x0 >= GridLeft() && x0 <= GridRight()) {
                int y0 = ConvertDataToDisplay(data[2 * i], scale);
                int y1 = ConvertDataToDisplay(data[2 * i + 1], scale);
                int yNext = ConvertDataToDisplay(data[2 * i + 2], scale);
                if(yNext < y1) {
                    y1 = yNext + 1;
                }
                yNext = ConvertDataToDisplay(data[2 * i + 3], scale);
                if(yNext > y0) {
                    y0 = yNext - 1;
                }
                DrawVLine((int)x0, y0, y1, color);
            }
        } else  {
#ifdef DISPLAY_COLOR
            int index = i - startPoint;
            dataCD[index] = ConvertDataToDisplay(CalculateFiltr(data, i), scale);
#else
            int y0 = ConvertDataToDisplay(CalculateFiltr(data, i), scale);
            int y1 = ConvertDataToDisplay(CalculateFiltr(data, i + 1), scale);
            if(y1 > y0) {
                DrawVLine(x0, y0, y1 - 1, color);
            } else if (y1 < y0) {
                DrawVLine(x0, y1 + 1, y0, color);
            } else {
                Display_SetPoint(x0, y0, color);
            }
#endif
        }
    }
#ifdef DISPLAY_COLOR
    if(endPoint - startPoint < 281) {
        int numPoints = 281 - (endPoint - startPoint);
        for(int i = 0; i < numPoints; i++) {
            int index = endPoint - startPoint + i;
            dataCD[index] = ConvertDataToDisplay(MIN_VALUE, scale);
        }
    }
    if(!GetPeackDetEnable()) {
        dataCD[280] = ConvertDataToDisplay(data[endPoint], scale);
        DrawSignalCol(GridLeft(), dataCD, true, GetColorValue(color));
    }
#endif
}

static void DrawSignalPointed(const uint8 *data, Color color, int startPoint, int endPoint, float scale, float scaleX) {
#ifdef DISPLAY_COLOR
    uint8 dataCD[281];
#endif
    for(int i = startPoint; i < endPoint; i++) {
#ifdef DISPLAY_COLOR
        int index = i - startPoint;
        dataCD[index] = ConvertDataToDisplay(CalculateFiltr(data, i), scale);
#else
        int16 x = GridLeft() + (i - startPoint) * scaleX;
        int y = ConvertDataToDisplay(CalculateFiltr(data, i), scale);
        Display_SetPoint(x, y, color);
#endif
    }
#ifdef DISPLAY_COLOR
    DrawSignalCol(GridLeft(), dataCD, false, GetColorValue(color));
#endif
}

static void DrawMarkersForMeasure(float scale, Channel chan) {
    for(int numMarker = 0; numMarker < 2; numMarker++) {
        int pos = Processing_GetMarkerHorizontal(chan, numMarker);
        if(pos != ERROR_VALUE_INT && pos > 0 && pos < 200) {
            DrawDashedHLine(GridBottom() - pos * scale, GridLeft(), GridRight(), 3, 2, 0, ColorChannel(chan));
        }
    }
}

void DrawDataChannel(const uint8 *data, Channel chan) {
    if(!data || !IsChannelEnable(chan)) {
        return;
    }

    float scale = (GridBottom() - GridTop()) / (MAX_VALUE - MIN_VALUE);
    float scaleX = ((float)GridWidth() + (GridSizeChanged() && MenuIsShown() ? 80 : 0)) / GridWidth();

    if(IsShownMeasures()) {
        DrawMarkersForMeasure(scale, chan);
    }

    int startPoint = 0;
    int endPoint = 0;
    GetPointsOnDisplay(&startPoint, &endPoint);
    int numPoints = endPoint - startPoint;
    if(GetPeackDetEnable()) {
        startPoint /= 2;
        startPoint -= 72;
        endPoint = startPoint + 2 * numPoints;
    }
    if(data == dataP2P[0] || data == dataP2P[1]) {
        if(ModeSelfRecorderEnable()) {
            /*
            uint8 *firstElem = (chan == Chan0) ? dataP2P[0] : dataP2P[1];
            uint8 dataSR[281];
            int indexPoint = 0;

            uint8 *pointer = firstElem;
            pointer

            data = dataSR;
            */
        } else if(endPoint > lastP2Pdata) {
            endPoint = lastP2Pdata;
        }
    }

    if(GetModeDrawSignal() == ModeDrawSignal_Lines) {
        DrawSignalLined(data, ColorChannel(chan), startPoint, endPoint, scale, scaleX);
    } else {
        DrawSignalPointed(data, ColorChannel(chan), startPoint, endPoint, scale, scaleX);
    }
}

#ifdef DISPLAY_BLACK
void SendScreenToHardware() {
    WRITE_COMMAND(COM_CSRW);
    WRITE_ADDRESS(0);

    WRITE_COMMAND(COM_MWRITE);
    volatile uint8 *pointer = bufferDisplay;
    volatile uint8 *endPointer = bufferDisplay + SIZE_BUFFER_FOR_SCREEN;

    if(IsInverseScreen()) {
        while(pointer < endPointer) {
            WRITE_PARAMETER(~(*(pointer++)));
        }
    } else {
        while(pointer < endPointer) {
            WRITE_PARAMETER(*(pointer++));
        }
    }
}
#endif

int LenghtText(const char *text) {
    int retValue = 0;
    while(*text) {
        retValue += LenghtSymbol(*text);
        text++;
    }
    return retValue;
}

void DisableShowLevelRShift0() {
    showLevelRShift[Chan0] = false;
    Timer_KillTimer(Timer_ShowLevelRShift0);
}

void DisableShowLevelRShift1() {
    showLevelRShift[Chan1] = false;
    Timer_KillTimer(Timer_ShowLevelRShift1);
}

int GridLeft() {
    return (MenuIsMinimize() ? 9 : 20) + Measure_GetDeltaGridLeft();
}

int GridRight() {
    int retValue = MenuIsMinimize() ? 9 + 280 : 20 + 280;
    if(GridSizeChanged() && MenuIsShown()) {
        retValue -= 80;
    }
    return retValue;
}

int GridTop() {
    return GRID_TOP;
}

int GridBottom() {
    return GRID_BOTTOM - Measure_GetDeltaGridBottom();
}

int GridHeight() {
    return GridBottom() - GridTop();
}

int GridWidth() {
    return GridRight() - GridLeft();
}

int GridCenterHeight() {
    return (GridBottom() + GridTop()) / 2;
}

int Grid_CellsInWidth() {
    return MenuIsShown() ? 10 : 14;
}

int GridWidthInCells() {
    if(!GridSizeChanged()) {
        return 14;
    }
    return MenuIsShown() ? 10 : 14;
}

void Display_EnableTrigLabel(bool enable) {
    trigEnable = enable;
}

void Display_ResetP2Ppoints(bool empty) {
    dataP2PIsEmpty = empty;
    lastP2Pdata = 0;
    memset(dataP2P, AVE_VALUE, NUM_P2P_POINTS * 2);
}

void Display_AddPoint(Channel chan, uint8 data0, uint8 data1) {
    dataP2PIsEmpty = false;
    dataP2P[chan][lastP2Pdata] = data0;
    dataP2P[chan][lastP2Pdata + 1] = data1;
    if(chan == Chan0) {
        lastP2Pdata += 2;
        if(lastP2Pdata >= NUM_P2P_POINTS) {
            lastP2Pdata = 0;
        }
   }
}

void Display_SetMode(DrawMode eMmode, pFuncVV func) {
    mode = eMmode;
    funcOnHand = func;
    if(eMmode == DrawMode_Hand) {
        Timer_SetTimer(Timer_DisplayHandMode, 100, Display_Update);
    } else {
        Timer_KillTimer(Timer_DisplayHandMode);
    }
}

void Display_SetAddDrawFunction(pFuncVV func) {
    funcAdditionDraw = func;
}

void Display_RemoveAddDrawFunction() {
    funcAdditionDraw = 0;
}

void Display_Clear() {
    FillRegion(0, 0, SCREEN_WIDTH - 1, SCREEN_HEIGHT - 2, ColorBack());
}

void Display_ShiftScreen(int delta) {
    int shift = LimitationInt(GetShiftInMemory() + delta, 0, GetMemoryNumPoints(false) - 282);
    SetShiftInMemory(shift);
}

void Display_SetRShiftMarkers(bool active) {
    AltMarkers marks = GetAltMarkers();
    drawRShiftMarkers = (marks == AltMarkers_Hide) ? false : true;
    Timer_SetTimer(Timer_RShiftMarkersAutoHide, 5000, OnRShiftMarkersAutoHide);
}

void OnRShiftMarkersAutoHide() {
    drawRShiftMarkers = false;
    Timer_KillTimer(Timer_RShiftMarkersAutoHide);
}

#ifdef DISPLAY_BLACK
void InitHardware() {
#define CHAR_WIDTH      8
#define CHAR_HEIGHT     8
#define CHARS_IN_LINE   40
#define F_OSC           7.2e6   /* 7.2e6 */
#define F_FRAME         70      /* 70    */

    WRITE_COMMAND(COM_SYSTEM_SET);        // C = 40h
    WRITE_PARAMETER(0x30);                // P1 = 30h
    // M0    (D0) = 0 - internal CG ROM
    // M1    (D1) = 0 - CG RAM1, 32 char
    // M2    (D2) = 0 - 8-pixel character height(2716 or equivalent ROM)
    // W/S    (D3) = 0 - single-panel drive
    // D4         = 1
    // IV    (D5) = 1 - no screen top-line correction
    // T/L    (D6) = 0 - LCD mode
    // DR    (D7) = 0 - normal operation
    int8 FX = CHAR_WIDTH - 1;
    int8 P2 = FX;
    P2 |= (1 << 7);
    WRITE_PARAMETER(P2);                // P2 = 87h
    // FX    (D0...D2) = CalculateFX(8) - width of character field in pixels
    // WF    (D7) = 1 - two-frame AC drive
    WRITE_PARAMETER(CHAR_HEIGHT - 1);    // P3 = 07h
    // FY    (D0...D3) = CalculateFY(8) - height of character field in pixels, height = FY + 1
    WRITE_PARAMETER(CHARS_IN_LINE - 1);    // P4 = 40
    // C/R    (D0...D7) = 40 - address range covered by one display line

    WRITE_PARAMETER((F_OSC / (SCREEN_HEIGHT - 1) / F_FRAME - 1) / 9);    // P5
    // TC/R    (D0...D7) = TCR
    WRITE_PARAMETER(SCREEN_HEIGHT - 1);    // P6
    // L/F    (D0...D7) = 239 - height of a frame, height = L/F + 1
    // AP = 240
    WRITE_PARAMETER(CHARS_IN_LINE);        // P7 = 240
    // APL    (D0...D7) = 240
    WRITE_PARAMETER(0x00);                // P8 = 0
    // APH    (D0...D7) = 0

    WRITE_COMMAND(COM_SCROLL);            // C
    WRITE_ADDRESS(0);
    WRITE_PARAMETER(240);                // SL 1
    WRITE_ADDRESS(0);
    WRITE_PARAMETER(0);                    // SL 2
    WRITE_ADDRESS(0);
    WRITE_PARAMETER(0);
    WRITE_PARAMETER(0);

    WRITE_COMMAND(COM_CSRFORM);
    WRITE_PARAMETER(0x07);
    WRITE_PARAMETER(0x87);

    WRITE_COMMAND(COM_HDOT_SCR);
    WRITE_PARAMETER(0);

    WRITE_COMMAND(COM_OVLAY);
    WRITE_PARAMETER(0x1c);

    WRITE_COMMAND(COM_DISP_ON);
    WRITE_PARAMETER(0x16);

    for(int i = 0; i < 1000000; i++) {

    }
}
#endif

int FirstEmptyString() {
    for(int i = 0; i < MAX_NUM_STRINGS; i++) {
        if(strings[i] == 0) {
            return i;
        }
    }
    return MAX_NUM_STRINGS;
}

int CalculateFreeSize() {
    int firstEmptyString = FirstEmptyString();
    if(firstEmptyString == 0) {
        return SIZE_BUFFER_FOR_STRINGS;
    }
    return SIZE_BUFFER_FOR_STRINGS - (strings[firstEmptyString - 1] - bufferForStrings) - strlen(strings[firstEmptyString - 1]) - 1;
}

void DeleteFirstString() {
    if(FirstEmptyString() < 2) {
        return;
    }
    int delta = strlen(strings[0]) + 1;
    int numStrings = FirstEmptyString();
    for(int i = 1; i < numStrings; i++) {
        strings[i - 1] = strings[i] - delta;
    }
    for(int i = numStrings - 1; i < MAX_NUM_STRINGS; i++) {
        strings[i] = 0;
    }
    for(int i = 0; i < SIZE_BUFFER_FOR_STRINGS - delta; i++) {
        bufferForStrings[i] = bufferForStrings[i + delta];
    }
}

void AddString(const char *string) {
    if(GetDebugConsoleInPause()) {
        return;
    }
    static int num = 0;
    char buffer[100];
    sprintf(buffer, "%d\x11", num++);
    strcat(buffer, string);
    while(CalculateFreeSize() < (strlen(buffer) + 1)) {
        DeleteFirstString();
    }
    if(!strings[0]) {
        strings[0] = bufferForStrings;
        strcpy(strings[0], buffer);
    } else {
        char *addressLastString = strings[FirstEmptyString() - 1];
        char *address = addressLastString + strlen(addressLastString) + 1;
        strings[FirstEmptyString()] = address;
        strcpy(address, buffer);
    }
}

void Display_AddStringToIndicating(const char *string) {

    if(FirstEmptyString() == MAX_NUM_STRINGS) {
        DeleteFirstString();
    }

    AddString(string);
}

void Display_SetPauseForConsole(bool pause) {
    if(pause) {
        lastStringForPause = FirstEmptyString() - 1;
    } else {
        lastStringForPause = -1;
    }
}

void Display_OneStringUp() {
    if(!GetDebugConsoleInPause()) {
    } else if(lastStringForPause > GetDebugNumStringsInConsole() - 1) {
        lastStringForPause--;
    }
}

void Display_OneStringDown() {
    if(!GetDebugConsoleInPause()) {
    } else if(lastStringForPause < FirstEmptyString() - 1) {
        lastStringForPause++;
    }
}

void DrawConsole() {
    int count = 0;
    SetFont(GetSizeFontForConsole() == 5 ? TypeFont_5 : TypeFont_8);
    int height = GetSizeFont();

    int lastString = FirstEmptyString() - 1;
    int numString = GetDebugNumStringsInConsole();
    if(height == 8 && numString > 22) {
        numString = 22;
    }
    int delta = 0;
    if(IsShowStringNavigation()) {
        numString -= ((height == 8) ? 1 : 2);
        delta = 10;
    }
    int firstString = lastString - numString + 1;
    if(firstString < 0) {
        firstString = 0;
    }

#ifdef DISPLAY_COLOR
    int dY = 0;
#else
    int dY = -3;
#endif
    
    for(int numString = firstString; numString <= lastString; numString++) {
        int width = LenghtText(strings[numString]);
        FillRegion(GridLeft() + 1, GRID_TOP + 1 + count * (height + 1) + delta, width, height + 1, ColorBack());
        int y = GRID_TOP + 5 + count * (height + 1) - 4;
#ifdef DISPLAY_COLOR
        if(GetSizeFont() == 5) {
            y -= 3;
        }
#endif
        Display_DrawText(GridLeft() + 2, y + dY + delta, strings[numString], ColorFill());
        count++;
    }

    SetFont(TypeFont_8);
}

void Display_ShowWarning(Warning warning) {
    const char* message = Tables_GetWarning(warning);
    if(warnings[0] == 0) {
        Timer_SetTimer(Timer_ShowMessages, 100, OnTimerShowWarning);
    }
    bool alreadyStored = false;
    for(int i = 0; i < NUM_WARNINGS; i++) {
        if(warnings[i] == 0 && !alreadyStored) {
            warnings[i] = message;
            timeWarnings[i] = Timer_GetMS();
            alreadyStored = true;
        } else if(warnings[i] == message) {
            timeWarnings[i] = Timer_GetMS();
            return;
        }
    }
}

void OnTimerShowWarning() {
    static const int TIME_WARNING = 5000;

    uint time = Timer_GetMS();
    for(int i = 0; i < NUM_WARNINGS; i++) {
        if(time - timeWarnings[i] > TIME_WARNING) {
            timeWarnings[i] = 0;
            warnings[i] = 0;
        }
    }

    int pointer = 0;
    for(int i = 0; i < NUM_WARNINGS; i++) {
        if(warnings[i] != 0) {
            warnings[pointer] = warnings[i];
            timeWarnings[pointer] = timeWarnings[i];
            if(pointer != i) {
                timeWarnings[i] = 0;
                warnings[i] = 0;
            }
            pointer++;
        }
    }

    if(pointer == 0) {
        Timer_KillTimer(Timer_ShowMessages);
    }
}

void DrawStringInRectangle(int x, int y, char const *text) {
    int width = LenghtText(text);
    int height = 8;
    DrawRectangle(GridLeft(), y, width + 4, height + 4, ColorFill());
    DrawRectangle(GridLeft() + 1, y + 1, width + 2, height + 2, ColorBack());
    FillRegion(GridLeft() + 2, y + 2, width, height, FLASH_10);
    Display_DrawText(GridLeft() + 3, y + 2, text, FLASH_01);
}

void DrawWarnings() {
    static const int delta = 12;
    int y = GridBottom() - delta;
    for(int i = 0; i < 10; i++) {
        if(warnings[i] != 0) {
            DrawStringInRectangle(GridLeft(), y, warnings[i]);
            y -= delta;
        }
    }
}

void InitHelp() {
    Help_AddTopicForButton(B_Cursors, "������ <�������> ������������� ��� ���������� ��������� ���������");
    Help_AddTopicForButton(B_Display, "������ ������� ������������� ��� ��������� ����������� �� �������");
    Help_AddTopicForButton(B_Memory, "������ ������ ������������� ��� ����������� ���� ������");
    Help_AddTopicForButton(B_Measures, "������ ����� ������������� ��� �������� ������� � �������� ���� ���������");
    Help_AddTopicForButton(B_Service, "������ ������ ������������� ��� �������� ������� � �������� ���� ������");
    Help_AddTopicForButton(B_Start, "������ ����/���� ������������� ��� �������/��������� �������� ���������");
    Help_AddTopicForButton(B_Power, "������ ������� �������� � ��������� �����������");
    Help_AddTopicForButton(B_Channel0, "������ ����� 1 ������������� ��� �������� ������� � �������� ���� ����� 1");
    Help_AddTopicForButton(B_Channel1, "������ ����� 2 ������������� ��� �������� ������� � �������� ���� ����� 2");
    Help_AddTopicForButton(B_Time, "������ ���� ������������� ��� �������� ������� � �������� ���� ���¨����");
    Help_AddTopicForButton(B_Trig, "������ ����� ������������� ��� �������� ������� � �������� ���� �������������");
    Help_AddTopicForButton(B_Menu, "������ ���� ��������� ���������/��������� ����, ����������� ��������� �� ���� ������ \
� ����������� ��������� � �������� 1...5");
    Help_AddTopicForButton(B_F1, "������ 1 ��������� ������ ��������� ���������������� ������ ���� ��� �������� �������. \
��� ������� ������� (����� 0.5 ���) ���������/��������� ��������������� ����� ����.");
    Help_AddTopicForButton(B_F2, "������ 2 ��������� ������ ��������� ���������������� ������ ���� ��� �������� �������. \
��� ������� ������� (����� 0.5 ���) ���������/��������� ��������������� ����� ����.");
    Help_AddTopicForButton(B_F3, "������ 3 ��������� ������ ��������� ���������������� ������ ���� ��� �������� �������. \
��� ������� ������� (����� 0.5 ���) ���������/��������� ��������������� ����� ����.");
    Help_AddTopicForButton(B_F4, "������ 4 ��������� ������ ��������� ���������������� ������ ���� ��� �������� �������. \
��� ������� ������� (����� 0.5 ���) ���������/��������� ��������������� ����� ����.");
    Help_AddTopicForButton(B_F5, "������ 5 ��������� ������ ��������� ���������������� ������ ���� ��� �������� �������. \
��� ������� ������� (����� 0.5 ���) ���������/��������� ��������������� ����� ����.");
}

/** @} */
