/// @file

#include "DisplayPrimitives.h"
#include "DisplayDrawing.h"
#include "Colors.h"

#include <stdio.h>

void ProgressBar_Draw(ProgressBar *bar) {
    int x = bar->x;
    int y = bar->y;
    char buffer[100] = {0};
    float passedPercents = bar->fullTime == 0 ? 0 : bar->passedTime / bar->fullTime * 100;
    sprintf(buffer, "��������� %.1f %%", passedPercents);
    DrawStringInCenterRect(x, y - 15, bar->width, bar->height, buffer, ColorFill(), false);
    DrawRectangle(bar->x, bar->y, bar->width, bar->height, ColorFill());
    FillRegion(bar->x, bar->y, bar->width * passedPercents / 100.0f, bar->height, ColorFill());
    buffer[0] = 0;
    sprintf(buffer, "�������� %.1f �", (int)(bar->fullTime - bar->passedTime) / 1000.0f);
    DrawStringInCenterRect(x, y + bar->height, bar->width, bar->height, buffer, ColorFill(), false);
}
