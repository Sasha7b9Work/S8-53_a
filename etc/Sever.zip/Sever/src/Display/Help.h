/// @file

#pragma once

#include "../defines.h"
#include "../Panel/Controls.h"

void Help_ClearBase(void);
void Help_ClearBaseForButtons(void);
void Help_AddTopicForDisplay(char *message, int x, int y, int width, int height);
void Help_AddTopicForButton(PanelButton button, char* message);
void Help_AddTopicForRegulator(char* message, Regulator regulator);
bool Help_ShortPressureButton(PanelButton button);
bool Help_RegulatorLeft(Regulator reg);
bool Help_RegulatorRight(Regulator reg);
void Help_Draw(void);
