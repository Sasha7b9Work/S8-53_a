/// @file

#pragma once

void WelcomeScreen_Init(void);
void WelcomeScreen_Update(void);
