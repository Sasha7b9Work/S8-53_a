/// @file

#pragma once

#include "../defines.h"

#define SCREEN_WIDTH            320
#define SCREEN_WIDTH_IN_BYTES   (320 / 8)
#define SCREEN_HEIGHT           240
#define SCREEN_HEIGHT_IN_BYTES  (240 / 8)
#define SIZE_BUFFER_FOR_SCREEN  ((SCREEN_WIDTH) * (SCREEN_HEIGHT) / 8)

#define GRID_DELTA              20
#define GRID_TOP                19
#define GRID_CELLS_IN_HEIGHT    10
#define GRID_HEIGHT             ((GRID_CELLS_IN_HEIGHT) * (GRID_DELTA))
#define GRID_BOTTOM             ((GRID_TOP) + (GRID_HEIGHT))
#define GRID_WIDTH              (280)

#define GRID_RIGHT              ((GridLeft()) + (GridWidth()))

#define CUR_WIDTH               6
#define CUR_HEIGHT              8

#define MP_Y                    ((GRID_TOP) + 1)
#define MP_TITLE_WIDTH          79
#define MP_X                    ((GRID_RIGHT) - (MP_TITLE_WIDTH) - 1)
#define MP_TITLE_HEIGHT         34
#define MI_HEIGHT               33
#define MI_WIDTH                ((MP_TITLE_WIDTH) + 1)
#define MI_HEIGHT_VALUE         13
#define MI_WIDTH_VALUE          ((MI_WIDTH) - 4)
#define MOSI_HEIGHT             14
#define MOI_HEIGHT_TITLE        19
#define MOI_WIDTH               MP_TITLE_WIDTH

typedef enum {
    DrawMode_Auto,
    DrawMode_Hand
} DrawMode;

//! ��� �����
typedef enum {
    COLOR_BLACK                 = 0x00,
    COLOR_WHITE                 = 0x01,
    COLOR_GRID                  = 0x02,
    COLOR_DATA_0                = 0x03,
    COLOR_DATA_0_DARK           = 0x04,
    COLOR_DATA_1                = 0x05,
    COLOR_DATA_1_DARK           = 0x06,
    COLOR_MATHEM                = 0x07,
    COLOR_FFT                   = 0x08,
    COLOR_MENU_FIELD            = 0x09,
    COLOR_MENU_TITLE            = 0x0a,
    COLOR_MENU_TITLE_DARK       = 0x0b,
    COLOR_MENU_TITLE_BRIGHT     = 0x0c,
    COLOR_MENU_ITEM             = 0x0d,
    COLOR_MENU_ITEM_DARK        = 0x0e,
    COLOR_MENU_ITEM_BRIGHT      = 0x0f,
    COLOR_MENU_SHADOW           = 0x10,
    COLOR_MENU_SHADOW_DARK      = 0x11,
    COLOR_MENU_SHADOW_BRIGHTT   = 0x12,
    NUM_COLORS,
    CELL_BACK,
    CELL_FILL,
    FLASH_10,
    FLASH_01,
    INVERSE
} Color;       

typedef struct {
    Color   color;
    bool    alreadyUsed;
    float   red;
    float   green;
    float   blue;
    float   stepRed;
    float   stepGreen;
    float   stepBlue;
    float   brightness;
    int8    currentField;
} ColorType;

typedef enum {
    SB_Signals,
    SB_Send,
    SB_Intermediate
} SourceBuffer;

typedef enum {
    TypeFont_5,
    TypeFont_8,
    TypeFont_UGO,
    TypeFont_UGO2,
    TypeFont_Number
} TypeFont;

#ifdef DISPLAY_COLOR
void ColorType_IncreaseBrightness(ColorType *colorType);
void ColorType_DecreaseBrightness(ColorType *colorType);
void ColorType_Init(ColorType *colorType);
void ColorType_IncreaseComponent(ColorType *colorType);
void ColorType_DecreaseComponent(ColorType *colorType);
const char* NameColorFromValue(uint16 colorValue);
const char* NameColor(Color color);
#endif
