/// @file

#include "USB/v-com-api.h"
#include "Log.h"
#include "Settings/Settings.h"
#include "Display/Display.h"

#include <string.h>
#include <stdio.h>
#include <stdarg.h>

static bool loggerUSB = true;

void Log_Write(char *format, ...) {
    if(Settings_DebugModeEnable()) {
        const int SIZE_BUFFER = 200;
        static char buffer[SIZE_BUFFER];
        __va_list args;
        va_start(args, format);
        vsprintf(buffer, format, args);
        va_end(args);
        Display_AddStringToIndicating(buffer);
        if(loggerUSB) {
            VCP_SendData((uint8*)buffer, strlen(buffer));
        }
    }
}

void Log_Error(const char *module, const char *func, int numLine, char *format, ...) {
    if(Settings_DebugModeEnable()) {
        const int SIZE_BUFFER = 200;
        static char buffer[SIZE_BUFFER];
        __va_list args;
        va_start(args, format);
        vsprintf(buffer, format, args);
        va_end(args);
        char numBuffer[20];
        sprintf(numBuffer, ":%d", numLine);
        static char message[SIZE_BUFFER];
        message[0] = 0;
        strcat(message, "!!!ERROR!!! ");
        strcat(message, module);
        strcat(message, " ");
        strcat(message, func);
        strcat(message, numBuffer);
        Display_AddStringToIndicating(message);
        Display_AddStringToIndicating(buffer);
        if(loggerUSB) {
            VCP_SendData((uint8*)message, strlen(message));
            VCP_SendData((uint8*)buffer, strlen(buffer));
        }
    }
}

void Log_DisconnectLoggerUSB(void) {
    static uint8 data = 20;
    //Log_Write("������� %d", data);
    VCP_SendData(&data, 1);
}

void Log_EnableLoggerUSB(bool enable) {
    loggerUSB = enable;
}
