/// @file

#pragma once

typedef enum {
    LimitChan1_Volts,
    LimitChan2_Volts,
    LimitSweep_Time,
    EnabledPeakDet,
    LimitChan1_RShift,
    LimitChan2_RShift,
    LimitSweep_Level,
    LimitSweep_TShift,
    TooSmallSweepForPeakDet,
    TooFastScanForSelfRecorder,
    FileIsSaved,
    Warning_NumWarnings,
} Warning;


NumSignalsInSec Tables_NumSignalsInSecToENUM(int numSignalsInSec);
int             Tables_ENUM_toNumSignalsInSec(NumSignalsInSec numSignalsInSec);
const char*     Tables_GetWarning(Warning warning);
