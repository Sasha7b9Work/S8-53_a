/// @file

#pragma once

void Channel0Long(void);
void Channel1Long(void);
void TimeLong(void);
void TrigLong(void);
void StartDown(void);   
void PowerDown(void);   
void MenuLong(void);
void F1Long(void);
void F2Long(void);
void F3Long(void);
void F4Long(void);
void F5Long(void);
void RShift0Left(void) ;
void RShift0Right(void);
void RShift1Left(void);
void RShift1Right(void);
void Range0Left(void);
void Range0Right(void);
void Range1Left(void);
void Range1Right(void);
void TBaseLeft(void);
void TBaseRight(void);
void TShiftLeft(void);
void TShiftRight(void);
void TrigLevLeft(void);
void TrigLevRight(void);
void SetLeft(void);
void SetRight(void);
