/// @file

#include "Panel.h"
#include "../Settings/Settings.h"
#include "../Display/Display.h"
#include "../FPGA/FPGA_Settings.h"
#include "../FPGA/FPGA.h"
#include "../FPGA/FPGA_Types.h"
#include "../Menu/Menu.h"
#include "../Menu/Pages/Definition.h"
#include "../Menu/Pages/PageMemory.h"
#include "../Menu/Pages/PageChannels.h"
#include "../Menu/Pages/PageTrig.h"
#include "../Menu/Pages/PageTime.h"
#include "../Math/Math.h"
#include "../Timer.h"
#include "../Log.h"

static const uint MIN_TIME = 500;

void ChangeRShift(int *prevTime, void(*f)(Channel, int16), Channel chan, int16 relStep);
void OnTimerPowerButton(void);   ///< ��� �������, ��������������� �� ������������ �������, ������������ ��� ���������� �������� ������ ����������.

void Channel0Long(void) {
    Menu_LongPressureButton(B_Channel0);
}

void Channel1Long(void) {
    Menu_LongPressureButton(B_Channel1);
}

void TimeLong(void) {
    Menu_LongPressureButton(B_Time);
}

void TrigLong(void) {
    Menu_LongPressureButton(B_Trig);
}

void StartDown() {                            // B_Start
    if(GetMemoryModeWork() == ModeWork_Direct) {
        FPGA_OnPressStartStop();
    }
}

void PowerDown() {                            // B_Power
    if(MenuIsMinimize()) {
        PressSmallButtonExit();
    }
    Settings_Save();
    Log_DisconnectLoggerUSB();
    Timer_SetTimer(Timer_OnPowerButton, 400, OnTimerPowerButton);
}

void OnTimerPowerButton() {
    Panel_TransmitData(0x04);
}

void MenuLong() {
    Menu_LongPressureButton(B_Menu);
}

void F1Long() {
    Menu_LongPressureButton(B_F1);
}

void F2Long() {
    Menu_LongPressureButton(B_F2);
}

void F3Long() {
    Menu_LongPressureButton(B_F3);
}

void F4Long() {
    Menu_LongPressureButton(B_F4);
}

void F5Long() {
    Menu_LongPressureButton(B_F5);
}

//****************************************************************************************************************
int CalculateCount(int *prevTime) {
    uint time = Timer_GetMS();
    uint delta = time - *prevTime;
    *prevTime = time;

    if(delta > 75) {
        return 1;
    } else if(delta > 50) {
        return 2;
    } else if(delta > 25) {
        return 3;
    }
    return 4;
}

bool CanChangeTShift(int16 tShift) {
    static uint time = 0;
    if(tShift == 0) {
        time = Timer_GetMS();
        return true;
    } else if(time == 0) {
        return true;
    } else if(Timer_GetMS() - time > MIN_TIME) {
        time = 0;
        return true;
    }
    return false;
}

bool CanChangeRShiftOrTrigLev(TrigSource channel, int16 rShift) {
    static uint time[3] = {0, 0, 0};
    if(rShift == RShiftZero) {
        time[channel] = Timer_GetMS();
        return true;
    } else if(time[channel] == 0) {
        return true;
    } else if(Timer_GetMS() - time[channel] > MIN_TIME) {
        time[channel] = 0;
        return true;
    }
    return false;
}

void ChangeRShift(int *prevTime, void(*f)(Channel, int16), Channel chan, int16 relStep) {
    int count = CalculateCount(prevTime);
    int rShiftOld = GetRShift(chan);
    int rShift = GetRShift(chan) + relStep * count;
    if((rShiftOld > RShiftZero && rShift < RShiftZero) ||(rShiftOld < RShiftZero && rShift > RShiftZero)) {
        rShift = RShiftZero;
    }
    if(CanChangeRShiftOrTrigLev((TrigSource)chan, rShift)) {
        f(chan, rShift);
    }
}

void ChangeTrigLev(int *prevTime, void(*f)(TrigSource, int16), TrigSource trigSource, int16 relStep) {
    int count = CalculateCount(prevTime);
    int trigLevOld = GetTrigLev(trigSource);
    int trigLev = GetTrigLev(trigSource) + relStep * count;
    if((trigLevOld > TrigLevZero && trigLev < TrigLevZero) || (trigLevOld < TrigLevZero && trigLev > TrigLevZero)) {
        trigLev = TrigLevZero;
    }
    if(CanChangeRShiftOrTrigLev(trigSource, trigLev)) {
        f(trigSource, trigLev);
    }
}

void ChangeTShift(int *prevTime, void(*f)(int), int16 relStep) {
    int count = CalculateCount(prevTime);
    int tShiftOld = GetTShift();
    float step = relStep * count;
    if(step < 0) {
        if(step > -1) {
            step = -1;
        }
    } else {
        if(step < 1) {
            step = 1;
        }
    }

    int16 tShift = GetTShift() + step;
    if(((tShiftOld > 0) && (tShift < 0)) || (tShiftOld < 0 && tShift > 0)) {
        tShift = 0;
    }
    if(CanChangeTShift(tShift)) {
        f(tShift);
    }
}

void ChangeShiftScreen(int *prevTime, void (*f)(int), int16 relStep) {
    int count = CalculateCount(prevTime);
    float step = relStep * count;
    if(step < 0) {
        if(step > -1) {
            step = -1;
        }
    } else if(step < 1) {
        step = 1;
    }
    f(step);
}

void RShift0Left() {
    static int prevTime = 0;
    ChangeRShift(&prevTime, FPGA_SetRShift, Chan0, -STEP_RSHIFT);
}

void RShift0Right() {
    static int prevTime = 0;
    ChangeRShift(&prevTime, FPGA_SetRShift, Chan0, +STEP_RSHIFT);
}

void RShift1Left() {
    static int prevTime = 0;
    ChangeRShift(&prevTime, FPGA_SetRShift, Chan1, -STEP_RSHIFT);
}

void RShift1Right() {
    static int prevTime = 0;
    ChangeRShift(&prevTime, FPGA_SetRShift, Chan1, +STEP_RSHIFT);
}

void TrigLevLeft() {
    static int prevTime = 0;
    ChangeTrigLev(&prevTime, FPGA_SetTrigLev, GetTrigSource(), -STEP_RSHIFT);
}

void TrigLevRight() {
    static int prevTime = 0;
    ChangeTrigLev(&prevTime, FPGA_SetTrigLev, GetTrigSource(), +STEP_RSHIFT);
}

void TShiftLeft() {
    static int prevTime = 0;
    if(!FPGA_IsRunning()) {
        ChangeShiftScreen(&prevTime,Display_ShiftScreen, -2);
    } else {
        ChangeTShift(&prevTime, FPGA_SetTShift, -1);
    }
}

void TShiftRight() {
    static int prevTime = 0;
    if(!FPGA_IsRunning()) {
        ChangeShiftScreen(&prevTime, Display_ShiftScreen, 2);
    } else {
        ChangeTShift(&prevTime, FPGA_SetTShift, 1);
    }
}

void Range0Left() {
    FPGA_RangeIncrease(Chan0);
}

void Range0Right() {
    FPGA_RangeDecrease(Chan0);
}

void Range1Left() {
    FPGA_RangeIncrease(Chan1);
}

void Range1Right() {
    FPGA_RangeDecrease(Chan1);
}

void TBaseLeft() {
    FPGA_TBaseIncrease();
}

void TBaseRight() {
    FPGA_TBaseDecrease();
}

static int countSetRotates = 0;
void SetLeft() {
    countSetRotates--;
    if((countSetRotates % 1) == 0) {
        Menu_RotateRegulatorLeft(R_Set);
    }
}

void SetRight() {
    countSetRotates++;
    if((countSetRotates % 1) == 0) {
        Menu_RotateRegulatorRight(R_Set);
    }
}


