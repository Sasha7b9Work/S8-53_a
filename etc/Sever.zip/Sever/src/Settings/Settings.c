/// @file

#include "Settings.h"
#include "../Hardware/FLASH.H"
#include "../Display/Display.h"
#include "../Display/DisplayDrawingCol.h"
#include "../Panel/Panel.h"
#include "../FPGA/FPGA.h"
#include "../FPGA/FPGA_Types.h"
#include "../FPGA/FPGA_Settings.h"
#include "../Math/Math.h"
#include "../Math/GlobalFunctions.h"
#include "../Display/Display.h"
#include "../Menu/Menu.h"
#include "../Menu/Pages/PageChannels.h"
#include "../Menu/Pages/PageDisplay.h"
#include "../Menu/Pages/PageDebug.h"
#include "../Log.h"

#include <string.h>

extern Redraw redraw;

/** @addtogroup SETTINGS
    @{ */

static const Settings defaultSettings = {
    // display
    {
        ModeDrawSignal_Lines,   // modeDrawSignal
        TypeGrid_1,             // typeGrid
        false,                  // gridSizeChange
        NumAccumulation_1,      // numAccumulation

        NumAveraging_1,         // numAveraging

        Averaging_Accurately,   // modeAveraging
        NumMinMax_1,            // numMinMax
        5,                      // timeShowLevels
        true,                   // isInverse
        DisplaySmooth_Disable,  // smoothing
        NumSignalsInSec_25,     // num signals in one second
        Missed_Hide,            // missed
        Chan0,                  // lastAffectedChannel
        false,                  // resetAccumSignals
        512 - 140,              // shiftInMemory
        true,                   // showFullMemoryWindow
        false,                   // showStringNavigation
        5,                      // timeMessages
        AltMarkers_Show,        // altMarkers
        true,                   // showHints
        MenuAutoHide_None,      // menuAutoHide
#ifdef DISPLAY_COLOR
        100,                    // brightness
        {
            MAKE_COLOR(0,  0,  0),
            MAKE_COLOR(31, 63, 31),
            MAKE_COLOR(15, 31, 15),
            MAKE_COLOR(1, 50, 31),
            MAKE_COLOR(15, 31, 0),
            MAKE_COLOR(0,  63, 0),
            MAKE_COLOR(0,  31, 15),
            MAKE_COLOR(31, 63, 31),
            MAKE_COLOR(31, 63, 31),
            MAKE_COLOR(26, 54, 26),
            MAKE_COLOR(31, 44, 0),
            MAKE_COLOR(15, 22, 0),
            MAKE_COLOR(31, 63, 0),
            MAKE_COLOR(26, 34, 0),
            MAKE_COLOR(13, 17, 0),
            MAKE_COLOR(31, 51, 0)
        }
#endif
    },
    // channels
    {
        {
            true,                   // enable
            false,                  // inverse
            ModeCouple_AC,          // ModCouple
            Multiplier_1,           // Multiplier
            false,                  // filtr
            Range_500mV,            // range
            {RShiftZero, 0.0f},     // rShift
            {0, 0},                 // addRShift
			0,                      // addShiftADC
            1.0f                    // ����������� ����������
        },
        {
            true,                   // enable
            false,                  // inverse
            ModeCouple_AC,          // ModCouple
            Multiplier_1,           // Multiplier
            false,                  // filtr
            Range_500mV,            // range
            {RShiftZero, 0.0f},     // rShift
            {0, 0},                 // addRShift
			0,                      // addShiftADC
            1.0f                    // ����������� ����������
        }
        
    },
    // trig
    {
        StartMode_Auto,
        TrigSource_Channel0,
        TrigPolarity_Front,
        TrigInput_Full,
        {{TrigLevZero, 0.0f}, {TrigLevZero, 0.0f}, {TrigLevZero, 0.0f}},
        ModeLongPressTrig_Auto

    },
    // time
    {
        {0, 0.0f},
        TBase_200us,
        true,
        TPos_Center,
        false,
        false,
        SampleType_Equal
    },
    // cursors
    {
        { CursCntrl_Disable, CursCntrl_Disable },   // CursCntrl U
        { CursCntrl_Disable, CursCntrl_Disable },   // CursCntrl T
        Chan0,                                      // source
        { 60, 140, 60, 140 },                       // posCur U
        { 80, 200, 80, 200 },                       // posCur T
        { 60, 140, 60, 140 },                       // posCur U for 100%
        { 80, 200, 80, 200 },                       // posCur T for 100%
        CursMovement_Points,                        // CursMovement
        CursActive_None,                            // CursActive
        { CursLookMode_None, CursLookMode_None },   // ����� �������� ��������.
        false,                                      // showFreq
        false                                       // showCursors
    },
    // memory
    {
        FNP_1024,
        ModeWork_Direct,
        FileNamingType_Mask,
        "signal_%3N",
        {
            0,
            ModeInsert_Insert
        },
        false                    /// flashAutoConnect
    },
    // measures
    {
        MN_3_5,                     // measures number
        Chan1_2,                    // source
        ModeViewSignals_AsIs,       // mode view signal
        /*
        {Measure_VoltageMax,       Measure_VoltageMin,     Measure_VoltagePic,        Measure_VoltageMaxSteady,    Measure_VoltageMinSteady,
        Measure_VoltageAverage,    Measure_VoltageAmpl,    Measure_VoltageRMS,        Measure_VoltageVybrosPlus,    Measure_VoltageVybrosMinus,
        Measure_Period,            Measure_Freq,           Measure_TimeNarastaniya,   Measure_TimeSpada,            Measure_DurationPlus},
        */
        {Measure_VoltageMax,       Measure_VoltageMin,     Measure_VoltagePic,        Measure_VoltageMaxSteady,    Measure_VoltageMinSteady,
        Measure_VoltageAverage,    Measure_VoltageAmpl,    Measure_VoltageRMS,        Measure_SkvaznostPlus,    Measure_SkvaznostMinus,
        Measure_Period,            Measure_Freq,           Measure_DelayPlus,   Measure_DelayMinus,            Measure_DurationPlus},
        false,                      // show
        MeasuresField_Screen,       // ����� ��� ��������� ��������, ������� �� ������
        //{0, 200},                 // ��������� �������� �������� ���������� ��� ���� ���������
        //{372, 652},               // ��������� �������� �������� ������� ��� ���� ���������
        {50, 150},                  // ��������� �������� �������� ���������� ��� ���� ���������
        {422, 602},                 // ��������� �������� �������� ������� ��� ���� ���������
        CursCntrl_1,                // ��������� ������ �������� ����������
        CursCntrl_1,                // ��������� ������ �������� �������
        CursActive_T,               // ������� ������� �������.
        Measure_None                // marked Measure
    },
    // math
    {
        Function_Disable,
        false
    },
    // service
    {
        true,                   // screenWelcomeEnable
        true,                   // soundEnable
        true,                   // calibratorEnable
        ModeButtonMenu_Close    // modeButtonMenu
    },
    // common
    {
        0
    },
    // menu
    {
        {0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f},
        {   0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,    0},
        true,
        NULL
    },
    // debug
    {
        1,                      // numStrings
        0,                      // ������ ������ - 5
        0,                      // consoleInPause
        BalanceADC_Settings,    // balanceADC
        {0, 0},                 // shiftADC
        StretchADC_Settings,    // stretch
        {128, 128},             // stretchADC
        RShiftADC_Settings,
        {{0, 0}, {0, 0}},
        1000,                   // numMeasuresForGates
        0,                      // shiftT0
        false,                  // showStats
        6,                      // numAveForRand
        false,                  // view altera writting data
        false,                  // view all altera writting data
        0,                      // alt shift
        {
            {                                   // Sound[0]
                {1000.0f, 1.0f, 0.0f, 0.0f},    // Sound[0].sine
                {1000.0f, 0.0f, 0.0f, 0.5f},    // Sound[0].triangle
                {1000.0f, 0.0f, 0.0f, 0.5f},    // Sound[0].rectangle
                0.2f,                           // Sound[0].duration
                1.0f
            },
            {                                   // Sound[1]
                {1000.0f, 1.0f, 0.0f, 0.0f},    // Sound[1].sine
                {1000.0f, 0.0f, 0.0f, 0.5f},    // Sound[1].triangle
                {1000.0f, 0.0f, 0.0f, 0.5f},    // Sound[1].rectangle
                0.2f,                           // Sound[1].duration
                1.0f
            },
            {                                   // Sound[2]
                {1000.0f, 1.0f, 0.0f, 0.0f},    // Sound[2].sine
                {1000.0f, 0.0f, 0.0f, 0.5f},    // Sound[2].triangle
                {1000.0f, 0.0f, 0.0f, 0.5f},    // Sound[2].rectangle
                0.2f,                           // Sound[2].duration
                1.0f
            },
            {                                   // Sound[3]
                {1000.0f, 1.0f, 0.0f, 0.0f},    // Sound[3].sine
                {1000.0f, 0.0f, 0.0f, 0.5f},    // Sound[3].triangle
                {1000.0f, 0.0f, 0.0f, 0.5f},    // Sound[3].rectangle
                0.2f,                           // Sound[3].duration
                1.0f
            },
            {                                   // Sound[4]
                {1000.0f, 1.0f, 0.0f, 0.0f},    // Sound[4].sine
                {1000.0f, 0.0f, 0.0f, 0.5f},    // Sound[4].triangle
                {1000.0f, 0.0f, 0.0f, 0.5f},    // Sound[4].rectangle
                0.2f,                           // Sound[4].duration
                1.0f
            }
        },
        0,
        0,
        {
            false,              // ���������� �� ���� ����������
            false,              // rShift0
            false,              // rShift1
            false               // trigLev
        }
    }
};

Settings set;

#ifdef DISPLAY_COLOR
void LoadDefaultColors() {
    for(int color = 0; color < NUM_COLORS; color++) {
        set.display.colors[color] = defaultSettings.display.colors[color];
    }
}
#endif

void Settings_Load(bool _default) {
    uint16 rShiftADC00 = set.debug.rShiftADC[0][0];
    uint16 rShiftADC01 = set.debug.rShiftADC[0][1];
    uint16 rShiftADC10 = set.debug.rShiftADC[1][0];
    uint16 rShiftADC11 = set.debug.rShiftADC[1][1];
    memcpy((void*)&set, (void*)(&defaultSettings), sizeof(set));
    if(_default) {
        set.debug.rShiftADC[0][0] = rShiftADC00;
        set.debug.rShiftADC[0][1] = rShiftADC01;
        set.debug.rShiftADC[1][0] = rShiftADC10;
        set.debug.rShiftADC[1][1] = rShiftADC11;
    } else {
        FLASH_LoadSettings();
    }
    FPGA_LoadSettings();
    FPGA_SetNumSignalsInSec(GetNumSignalsInSec());
    Panel_EnableLEDChannel0(IsChannelEnable(Chan0));
    Panel_EnableLEDChannel1(IsChannelEnable(Chan1));
    FPGA_SetNumberMeasuresForGates(set.debug.numMeasuresForGates);
    Menu_SetAutoHide(true);
    Display_SetRShiftMarkers(true);
    Debug_TuneSounds();
}

void Settings_Save() {
    FLASH_SaveSettings();
}

int Settings_Size() {
    return sizeof(set);
}

void* Settings_Pointer() {
    return (void*)&set;
}

bool Settings_DebugModeEnable() {
    return true;
}

ModeAveraging GetTypeAveraging() {
    return set.display.modeAveraging;
}

void Settings_StoreIn(Settings *settings) {
    *settings = set;
}

void Settings_RestoreFrom(Settings *settings) {
    set = *settings;
}

/** @} */

/** @addtogroup SETTINGS_COMMON
    @{ */

Language GetLanguage() {
    return set.common.language;
}

void IncCommonCountEnables() {
    set.common.countEnables++;
}

void SetCommonCountEnables(int val) {
    set.common.countEnables = val;
}

void CommonCountErasedFlashSettings() {
    set.common.countErasedFlashSettings = 0;
}

void CommonCountErasedFlashSettingsInc() {
    set.common.countErasedFlashSettings++;
}

void SetCommonCountErasedFlashData(int val) {
    set.common.countErasedFlashData = val;
}

void SetCommonWorkingTimeInSecs(int val) {
    set.common.workingTimeInSecs = val;
}

void AddCommonWorkingTimeInSecs(int val) {
    set.common.workingTimeInSecs += val;
}
/** @} */

/** @addtogroup SETTINGS_MENU
    @{ */
int8 MenuPosActItem(NamePage namePage) {
    return set.menu.posActItem[namePage];
}

void SetMenuPosActItem(NamePage namePage, int8 pos) {
    set.menu.posActItem[namePage] = pos;
}

int8 MenuCurrentSubPage(NamePage namePage) {
    return set.menu.currentSubPage[namePage];
}

void SetMenuCurrentSubPage(NamePage namePage, int8 posSubPage) {
    set.menu.currentSubPage[namePage] = posSubPage;
}

bool MenuIsShown() {
    return set.menu.isShown;
}

void ShowMenu(bool show) {
    set.menu.isShown = show;
    Menu_SetAutoHide(true);
}

bool MenuIsMinimize() {
    return set.menu.pageSB != NULL;
}

TypePageSB GetMenuSmallButtonPage() {
    if(set.menu.pageSB == NULL) {
        return TypePageSB_None;
    }
    return set.menu.pageSB->type;
}

void SetPageSB(const PageSB *page) {
    set.menu.pageSB = page;
}

bool MenuPageDebugIsActive() {
    return set.menu.pageDebugActive;
}

void SetMenuPageDebugActive(bool active) {
    set.menu.pageDebugActive = active;
}

void CurrentPageSBregSetLeft() {
    if(set.menu.pageSB) {
        set.menu.pageSB->funcRegSetLeft();
    }
}

void CurrentPageSBregSetRight() {
    if(set.menu.pageSB) {
        set.menu.pageSB->funcRegSetRight();
    }
}

void PressSmallButton(PanelButton button) {
    if(set.menu.pageSB && button >= B_Menu && button <= B_F5 && set.menu.pageSB->buttons[button - B_Menu]) {
        set.menu.pageSB->buttons[button - B_Menu]->funcOnPress();
    }
}

const SmallButton* GetSmallButton(PanelButton button) {
    if(set.menu.pageSB && button >= B_Menu && button <= B_F5) {
        return set.menu.pageSB->buttons[button - B_Menu];
    }
    return NULL;
}

/** @} */
