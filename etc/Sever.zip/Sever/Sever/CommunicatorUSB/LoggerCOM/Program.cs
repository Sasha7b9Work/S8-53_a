using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.IO.Ports;
using System.Runtime.InteropServices;

namespace LoggerCOM {
    class Program {

        private static SerialPort port;
        const int REQUEST_FOR_CONNECT = 0x55;
        const int CONNECT_IS_OK = 0xaa;
        const byte DISCONNECT = 20;
        static bool isRunning = true;
        static bool isRecieved = false;

        static unsafe void Main(string[] args)
        {
            Console.WriteLine("�������� ���������� ...");


            port = new SerialPort();
            while (isRunning) {
                string[] ports = SerialPort.GetPortNames();
                foreach (string s in ports) {
                    try {
                        port.PortName = s;
                        if (port.IsOpen) {
                            port.Close();
                        }
                        port.BaudRate = 128000;
                        port.Open();
                    } catch (System.Exception e) {
                        if (s == "COM3") {
                            Console.WriteLine(e.ToString());
                        }
                        continue;
                    }
                    if (port.IsOpen) {
                        SendByte(REQUEST_FOR_CONNECT);
                        try {
                            long startTime = DateTime.Now.Ticks / 10000;
                            while ((DateTime.Now.Ticks / 10000 - startTime < 10) && port.BytesToRead == 0) { }
                            if (port.BytesToRead != 0) {
                                byte[] buffer = new byte[1];
                                port.Read(buffer, 0, 1);
                                if (buffer[0] == CONNECT_IS_OK) {
                                    Console.WriteLine("    ��������� �� " + s);
                                    isRecieved = true;
                                    port.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(OnDataRecieved);
                                    port.ErrorReceived += new System.IO.Ports.SerialErrorReceivedEventHandler(OnErrorRecieved);
                                    port.PinChanged += new System.IO.Ports.SerialPinChangedEventHandler(OnPinChanged);
                                    while (isRecieved && port.IsOpen)
                                    {
                                    }
                                    Console.WriteLine("is Recieved is now false");
                                    port.DataReceived -= new System.IO.Ports.SerialDataReceivedEventHandler(OnDataRecieved);
                                    port.ErrorReceived -= new System.IO.Ports.SerialErrorReceivedEventHandler(OnErrorRecieved);
                                    port.PinChanged -= new System.IO.Ports.SerialPinChangedEventHandler(OnPinChanged);
                                }
                            }
                        } catch (System.Exception e) {
                            Console.WriteLine(e.ToString());
                        }
                    }
                    if (port.IsOpen) {
                        port.Close();
                    }
                }
            }
        }

        private static void SendByte(byte data) {
            if (port.IsOpen) {
                byte[] sendingData = new byte[1];
                sendingData[0] = data;
                port.Write(sendingData, 0, 1);
            }
        }

        static private void OnDataRecieved(object sender, SerialDataReceivedEventArgs e) {
            int numBytes = port.BytesToRead;
            if (numBytes > 0) {
                if (numBytes == 1) {
                    byte[] buffer = new byte[1];
                    port.Read(buffer, 0, 1);
                    if (buffer[0] == DISCONNECT) {
                        Console.WriteLine("S8-53 is now disconnected...");
                        isRecieved = false;
                        return;
                    } else {
                        Console.WriteLine((int)buffer[0]);
                    }
                }
                byte[] str = new byte[numBytes];
                port.Read(str, 0, numBytes);

                string strU16 = "";

                for (int i = 0; i < numBytes; i++)
                {
                    strU16 += str[i] >= 192 ? Convert.ToChar((int)(str[i]) + 848) : Convert.ToChar(str[i]);
                }

                Console.WriteLine(strU16);
            }
        }
        
        static private void OnErrorRecieved(object sender, SerialErrorReceivedEventArgs e) {
            Console.WriteLine("ERROR!!! OnErrorRecieved ...");
            isRecieved = false;
        }

        static private void OnPinChanged(object sender, SerialPinChangedEventArgs e)
        {
            Console.WriteLine("ERROR!!! Pin is changed...");
        }

    }
}
