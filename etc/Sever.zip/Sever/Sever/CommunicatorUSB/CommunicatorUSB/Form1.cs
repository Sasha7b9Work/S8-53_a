﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Runtime.InteropServices;

namespace CommunicatorUSB
{
    public partial class MainForm : Form
    {
        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool AllocConsole ();

        private static ComPort port;
        private Thread drawingThread = new Thread(DrawData);
        private static bool isRunning = false;
        private static byte[] buffer = new byte[1];

        public MainForm()
        {
            InitializeComponent();
            
        }

        private void Form1_Load ( object sender, EventArgs e ) {
            if(AllocConsole()) {
                System.Console.WriteLine("Ok");
            }
            port = new ComPort();
            if(port.ConnectIfPossible()) {
                //display.Fill(Color.Black);
                //drawingThread.Priority = ThreadPriority.AboveNormal;
                drawingThread.Start();
            } else {
                display.Fill(Color.White);
            }
            timer1.Start();

        }

        private void MainForm_FormClosed ( object sender, FormClosedEventArgs e ) {
            port.Stop();
            if(isRunning) {
                isRunning = false;
                drawingThread.Join();
            }
        }

        private static void DrawData () {
            isRunning = true;
            while(isRunning) {
                if(port.DataReady()) {
                    buffer = port.GetData();
                    port.CanRead();
                }
            }
        }

        private void timer1_Tick ( object sender, EventArgs e ) {
            if(buffer.Length != 1) {
                DrawPicture();
                buffer = new byte[1];
            }
        }

        private void DrawEmpty() {
            display.BeginScene();
            Random rand = new Random();
            for (int x = 0; x < 320; x++) {
                for (int y = 0; y < 240; y++) {
                    display.SetPoint(x, y, Color.FromArgb(rand.Next(255), rand.Next(255), rand.Next(255)));
                }
            }
            display.EndScene(false);
        }

        private int GetBit(byte value, int bit) {
            return (value >> bit) & 0x01;
        }

        private void DrawPicture () {
            int start = Environment.TickCount;
            if(buffer.Length == ComPort.SIZE_BUFFER_FOR_COLOR) {
                display.Fill(Color.Black);
                Color[] colors = new Color[16];
                for(int i = 0; i < 16; i++) {
                    int color16 = (buffer[i * 2 + 1] << 8) + buffer[i * 2];
                    int blue = color16 & 0x1f;
                    int green = (color16 >> 5) & 0x3f;
                    int red = (color16 >> 11) & 0x1f;

                    colors[i] = Color.FromArgb((int)((float)red / 32.0f * 255.0f),
                                                    (int)((float)green / 64.0f * 255.0f),
                                                    (int)((float)blue / 32.0f * 255.0f));
                }

                int x = 0;
                int y = 0;

                for(int i = 33; i < ComPort.SIZE_BUFFER_FOR_COLOR; i++) {
                    byte data = buffer[i];
                    Color col1 = colors[data & 0x0f];
                    if (col1.R != 0 || col1.G != 0 || col1.B != 0) {
                        display.SetPoint(x, y, col1);
                    }
                    x++;
                    Color col = colors[(data & 0xf0) >> 4];
                    if(col.R != 0 || col.G != 0 || col.B != 0) {
                        display.SetPoint(x, y, col);
                    }
                    x++;
                    if(x == 320) {
                        y++;
                        x = 0;
                    }
                }
                display.EndScene(true);
                System.Console.WriteLine("Время рисования " + (Environment.TickCount - start) + "мс");
            } else if(buffer.Length != 1) {
                display.Fill(Color.Black);
                int x = 0;
                int y = 0;
                for (int i = 0; i < ComPort.SIZE_BUFFER_FOR_BLACK; i++)
                {
                    byte data = buffer[i];

                    for (int bit = 7; bit >= 0; bit--) {
                        if (GetBit(data, bit) == 1) {
                            display.SetPoint(x, y, Color.White);
                        }
                        x++;
                    }
                    if(x >= 320) {
                        y++;
                        x = 0;
                    }
                }
                display.EndScene(true);
            }
        }

        private void bMenu_MouseToUp ( object sender, EventArgs e ) {
            port.SendByte(13);
        }

        private void bF1_MouseToDown ( object sender, EventArgs e ) {
            port.SendByte(14 + 128);
        }

        private void bF1_MouseToUp ( object sender, EventArgs e ) {
            port.SendByte(14);
        }

        private void bF2_MouseToDown ( object sender, EventArgs e ) {
            port.SendByte(15 + 128);
        }

        private void bF2_MouseToUp ( object sender, EventArgs e ) {
            port.SendByte(15);
        }

        private void bF3_MouseToDown ( object sender, EventArgs e ) {
            port.SendByte(16 + 128);
        }

        private void bF3_MouseToUp ( object sender, EventArgs e ) {
            port.SendByte(16);
        }

        private void bF4_MouseToDown ( object sender, EventArgs e ) {
            port.SendByte(17 + 128);
        }

        private void bF4_MouseToUp ( object sender, EventArgs e ) {
            port.SendByte(17);
        }

        private void bF5_MouseToDown ( object sender, EventArgs e ) {
            port.SendByte(18 + 128);
        }

        private void bF5_MouseToUp ( object sender, EventArgs e ) {
            port.SendByte(18);
        }

        private void bChan0_MouseToDown ( object sender, EventArgs e ) {
            port.SendByte(1 + 128);
        }

        private void bChan0_MouseToUp ( object sender, EventArgs e ) {
            port.SendByte(1);
        }

        private void bChan1_MouseToDown ( object sender, EventArgs e ) {
            port.SendByte(3 + 128);
        }

        private void bChan1_MouseToUp ( object sender, EventArgs e ) {
            port.SendByte(3);
        }

        private void bTime_MouseToDown ( object sender, EventArgs e ) {
            port.SendByte(5 + 128);
        }

        private void bTime_MouseToUp ( object sender, EventArgs e ) {
            port.SendByte(5);
        }

        private void bTrig_MouseToDown ( object sender, EventArgs e ) {
            port.SendByte(7 + 128);
        }

        private void bTrig_MouseToUp ( object sender, EventArgs e ) {
            port.SendByte(7);
        }

        private void bCursors_MouseToDown ( object sender, EventArgs e ) {
            port.SendByte(9 + 128);
        }

        private void bCursors_MouseToUp ( object sender, EventArgs e ) {
            port.SendByte(9);
        }

        private void bDisplay_MouseToDown ( object sender, EventArgs e ) {
            port.SendByte(4 + 128);
        }

        private void bDisplay_MouseToUp ( object sender, EventArgs e ) {
            port.SendByte(4);
        }

        private void bMemory_MouseToDown ( object sender, EventArgs e ) {
            port.SendByte(6 + 128);
        }

        private void bMemory_MouseToUp ( object sender, EventArgs e ) {
            port.SendByte(6);
        }

        private void bMeasures_MouseToDown ( object sender, EventArgs e ) {
            port.SendByte(10 + 128);
        }

        private void bMeasures_MouseToUp ( object sender, EventArgs e ) {
            port.SendByte(10);
        }

        private void bHelp_MouseToDown ( object sender, EventArgs e ) {
            port.SendByte(12 + 128);
        }

        private void bHelp_MouseToUp ( object sender, EventArgs e ) {
            port.SendByte(12);
        }

        private void bService_MouseToDown ( object sender, EventArgs e ) {
            port.SendByte(2 + 128);
        }

        private void bService_MouseToUp ( object sender, EventArgs e ) {
            port.SendByte(2);
        }

        private void bStart_MouseToDown ( object sender, EventArgs e ) {
            port.SendByte(8 + 128);
        }

        private void bStart_MouseToUp ( object sender, EventArgs e ) {
            port.SendByte(8);
        }

        private void govSet_RotateLeft ( object sender, EventArgs e ) {
            port.SendByte(27);
        }

        private void govSet_RotateRight ( object sender, EventArgs e ) {
            port.SendByte(27 + 128);
        }

        private void govRShift0_RotateLeft ( object sender, EventArgs e ) {
            port.SendByte(21);
        }

        private void govRShift0_RotateRight ( object sender, EventArgs e ) {
            port.SendByte(21 + 128);
        }

        private void govRange0_RotateLeft ( object sender, EventArgs e ) {
            port.SendByte(20);
        }

        private void govRange0_RotateRight ( object sender, EventArgs e ) {
            port.SendByte(20 + 128);
        }

        private void govRShift1_RotateLeft ( object sender, EventArgs e ) {
            port.SendByte(23);
        }

        private void govRShift1_RotateRight ( object sender, EventArgs e ) {
            port.SendByte(23 + 128);
        }

        private void govTShift_RotateLeft ( object sender, EventArgs e ) {
            port.SendByte(25);
        }

        private void govTShift_RotateRight ( object sender, EventArgs e ) {
            port.SendByte(25 + 128);
        }

        private void govTBase_RotateLeft ( object sender, EventArgs e ) {
            port.SendByte(24);
        }

        private void govTBase_RotateRight ( object sender, EventArgs e ) {
            port.SendByte(24 + 128);
        }

        private void govTrigLev_RotateLeft ( object sender, EventArgs e ) {
            port.SendByte(26);
        }

        private void govTrigLev_RotateRight ( object sender, EventArgs e ) {
            port.SendByte(26 + 128);
        }

        private void bMenu_MouseToDown_1 ( object sender, EventArgs e ) {
            port.SendByte(13 + 128);
        }
    }
}
