﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO.Ports;
using System.Threading;
using System.Drawing;

namespace CommunicatorUSB {
    class ComPort {

        private static SerialPort port = new SerialPort();
        private Thread readThread = new Thread(Read);
        private static bool colorDisplay = true;
        private static byte[] buffer;
        public static int SIZE_BUFFER_FOR_COLOR = 320 * 240 / 2 + 16 * 2;
        public static int SIZE_BUFFER_FOR_BLACK = 320 * 240 / 8;
        private static bool running = false;
        private static bool dataReady = false;

        public ComPort () {
        }

        public void Stop() {
            if(running) {
                SendByte(254);
                running = false;
                readThread.Join();
                port.Close();
            }
        }

        public string[] GetPorts() {
            return SerialPort.GetPortNames();
        }

        public bool ConnectIfPossible () {
            foreach(string s in SerialPort.GetPortNames( )) {
                port.PortName = s;
                port.Open();
                if(port.IsOpen) {
                    SendByte(255);
                    port.ReadTimeout = 100;
                    try
                    {
                        port.BaudRate = 125000;
                        buffer = new byte[1];
                        port.Read(buffer, 0, 1);
                        if(buffer[0] == 255) {                          // Цветной монитор
                            colorDisplay = true;
                            readThread.Start();
                            return true;
                        } else if(buffer[0] == 254) {                   // ЧБ дисплей
                            colorDisplay = false;
                            System.Console.WriteLine("Приконнекчен чб");
                            readThread.Start();
                            return true;
                        }
                    } catch (System.Exception) {                    	

                    }
                }
                port.Close();
            }

            return false;
        }

        public void SendByte ( byte data ) {
            if(port.IsOpen) {
                byte[] sendingData = new byte[1];
                sendingData[0] = data;
                port.Write(sendingData, 0, 1);
            }
        }

        private static void Read () {
            running = true;
            if(colorDisplay) {
                while(running) {
                    buffer = new byte[SIZE_BUFFER_FOR_COLOR];
                    int numRecievedBytes = 0;
                    do {
                        int numBytes = port.BytesToRead;
                        if (numBytes > 0) {
                            port.Read(buffer, numRecievedBytes, numBytes);
                            numRecievedBytes += numBytes;
                        } else {
                            Thread.Sleep(10);
                        }
                    } while((numRecievedBytes < SIZE_BUFFER_FOR_COLOR) && running);
                    dataReady = true;
                    while(dataReady) { };
                }
            } else {
                while(running) {
                    buffer = new byte[SIZE_BUFFER_FOR_BLACK];
                    int numRecievedBytes = 0;
                    do {
                        int numBytes = port.BytesToRead;
                        if (numBytes > 0) {
                            port.Read(buffer, numRecievedBytes, numBytes);
                            numRecievedBytes += numBytes;
                        } else {
                            Thread.Sleep(10);
                        }
                    } while((numRecievedBytes < SIZE_BUFFER_FOR_BLACK) && running);
                    dataReady = true;
                    while(dataReady) { };
                }
            }
        }

        public bool DataReady () {
            return dataReady;
        }

        public byte[] GetData () {
            return buffer;
        }

        public void CanRead () {
            dataReady = false;
        }
    }
}
