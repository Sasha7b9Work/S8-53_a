﻿namespace CommunicatorUSB
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.bF5 = new CommunicatorUSB.Button();
            this.bF4 = new CommunicatorUSB.Button();
            this.bF3 = new CommunicatorUSB.Button();
            this.bF2 = new CommunicatorUSB.Button();
            this.bF1 = new CommunicatorUSB.Button();
            this.bStart = new CommunicatorUSB.Button();
            this.bService = new CommunicatorUSB.Button();
            this.bMemory = new CommunicatorUSB.Button();
            this.bHelp = new CommunicatorUSB.Button();
            this.bDisplay = new CommunicatorUSB.Button();
            this.bChan0 = new CommunicatorUSB.Button();
            this.bTrig = new CommunicatorUSB.Button();
            this.bTime = new CommunicatorUSB.Button();
            this.bChan1 = new CommunicatorUSB.Button();
            this.bMeasures = new CommunicatorUSB.Button();
            this.bCursors = new CommunicatorUSB.Button();
            this.bMenu = new CommunicatorUSB.Button();
            this.display = new CommunicatorUSB.Display();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(360, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "МЕНЮ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(371, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(13, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(371, 106);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(13, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(371, 143);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(13, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "3";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(371, 181);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(13, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "4";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(371, 223);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(13, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "5";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(410, 8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "установка";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(419, 95);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "КАНАЛ 1";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(493, 95);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 13);
            this.label9.TabIndex = 7;
            this.label9.Text = "КАНАЛ 2";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(591, 95);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 13);
            this.label10.TabIndex = 7;
            this.label10.Text = "РАЗВ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(675, 95);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 13);
            this.label11.TabIndex = 7;
            this.label11.Text = "СИНХР";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(489, 8);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(50, 13);
            this.label13.TabIndex = 7;
            this.label13.Text = "курсоры";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(555, 11);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(49, 13);
            this.label14.TabIndex = 7;
            this.label14.Text = "дисплей";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(615, 8);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(44, 13);
            this.label15.TabIndex = 7;
            this.label15.Text = "память";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(489, 48);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(39, 13);
            this.label16.TabIndex = 7;
            this.label16.Text = "измер";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(558, 48);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(48, 13);
            this.label17.TabIndex = 7;
            this.label17.Text = "помощь";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(612, 48);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(43, 13);
            this.label18.TabIndex = 7;
            this.label18.Text = "сервис";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(670, 30);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(58, 13);
            this.label19.TabIndex = 7;
            this.label19.Text = "пуск/стоп";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // bF5
            // 
            this.bF5.Location = new System.Drawing.Point(360, 239);
            this.bF5.Name = "bF5";
            this.bF5.Size = new System.Drawing.Size(36, 21);
            this.bF5.TabIndex = 6;
            this.bF5.MouseToDown += new System.EventHandler(this.bF5_MouseToDown);
            this.bF5.MouseToUp += new System.EventHandler(this.bF5_MouseToUp);
            // 
            // bF4
            // 
            this.bF4.Location = new System.Drawing.Point(360, 197);
            this.bF4.Name = "bF4";
            this.bF4.Size = new System.Drawing.Size(36, 21);
            this.bF4.TabIndex = 5;
            this.bF4.MouseToDown += new System.EventHandler(this.bF4_MouseToDown);
            this.bF4.MouseToUp += new System.EventHandler(this.bF4_MouseToUp);
            // 
            // bF3
            // 
            this.bF3.Location = new System.Drawing.Point(360, 157);
            this.bF3.Name = "bF3";
            this.bF3.Size = new System.Drawing.Size(36, 21);
            this.bF3.TabIndex = 4;
            this.bF3.MouseToDown += new System.EventHandler(this.bF3_MouseToDown);
            this.bF3.MouseToUp += new System.EventHandler(this.bF3_MouseToUp);
            // 
            // bF2
            // 
            this.bF2.Location = new System.Drawing.Point(360, 119);
            this.bF2.Name = "bF2";
            this.bF2.Size = new System.Drawing.Size(36, 21);
            this.bF2.TabIndex = 3;
            this.bF2.MouseToDown += new System.EventHandler(this.bF2_MouseToDown);
            this.bF2.MouseToUp += new System.EventHandler(this.bF2_MouseToUp);
            // 
            // bF1
            // 
            this.bF1.Location = new System.Drawing.Point(360, 82);
            this.bF1.Name = "bF1";
            this.bF1.Size = new System.Drawing.Size(36, 21);
            this.bF1.TabIndex = 2;
            this.bF1.MouseToDown += new System.EventHandler(this.bF1_MouseToDown);
            this.bF1.MouseToUp += new System.EventHandler(this.bF1_MouseToUp);
            // 
            // bStart
            // 
            this.bStart.Location = new System.Drawing.Point(680, 46);
            this.bStart.Name = "bStart";
            this.bStart.Size = new System.Drawing.Size(39, 21);
            this.bStart.TabIndex = 1;
            this.bStart.MouseToDown += new System.EventHandler(this.bStart_MouseToDown);
            this.bStart.MouseToUp += new System.EventHandler(this.bStart_MouseToUp);
            // 
            // bService
            // 
            this.bService.Location = new System.Drawing.Point(618, 64);
            this.bService.Name = "bService";
            this.bService.Size = new System.Drawing.Size(39, 21);
            this.bService.TabIndex = 1;
            this.bService.MouseToDown += new System.EventHandler(this.bService_MouseToDown);
            this.bService.MouseToUp += new System.EventHandler(this.bService_MouseToUp);
            // 
            // bMemory
            // 
            this.bMemory.Location = new System.Drawing.Point(618, 29);
            this.bMemory.Name = "bMemory";
            this.bMemory.Size = new System.Drawing.Size(39, 21);
            this.bMemory.TabIndex = 1;
            this.bMemory.MouseToDown += new System.EventHandler(this.bMemory_MouseToDown);
            this.bMemory.MouseToUp += new System.EventHandler(this.bMemory_MouseToUp);
            // 
            // bHelp
            // 
            this.bHelp.Location = new System.Drawing.Point(558, 64);
            this.bHelp.Name = "bHelp";
            this.bHelp.Size = new System.Drawing.Size(39, 21);
            this.bHelp.TabIndex = 1;
            this.bHelp.MouseToDown += new System.EventHandler(this.bHelp_MouseToDown);
            this.bHelp.MouseToUp += new System.EventHandler(this.bHelp_MouseToUp);
            // 
            // bDisplay
            // 
            this.bDisplay.Location = new System.Drawing.Point(558, 29);
            this.bDisplay.Name = "bDisplay";
            this.bDisplay.Size = new System.Drawing.Size(39, 21);
            this.bDisplay.TabIndex = 1;
            this.bDisplay.MouseToDown += new System.EventHandler(this.bDisplay_MouseToDown);
            this.bDisplay.MouseToUp += new System.EventHandler(this.bDisplay_MouseToUp);
            // 
            // bChan0
            // 
            this.bChan0.Location = new System.Drawing.Point(430, 117);
            this.bChan0.Name = "bChan0";
            this.bChan0.Size = new System.Drawing.Size(39, 21);
            this.bChan0.TabIndex = 1;
            this.bChan0.MouseToDown += new System.EventHandler(this.bChan0_MouseToDown);
            this.bChan0.MouseToUp += new System.EventHandler(this.bChan0_MouseToUp);
            // 
            // bTrig
            // 
            this.bTrig.Location = new System.Drawing.Point(678, 114);
            this.bTrig.Name = "bTrig";
            this.bTrig.Size = new System.Drawing.Size(39, 21);
            this.bTrig.TabIndex = 1;
            this.bTrig.MouseToDown += new System.EventHandler(this.bTrig_MouseToDown);
            this.bTrig.MouseToUp += new System.EventHandler(this.bTrig_MouseToUp);
            // 
            // bTime
            // 
            this.bTime.Location = new System.Drawing.Point(598, 114);
            this.bTime.Name = "bTime";
            this.bTime.Size = new System.Drawing.Size(39, 21);
            this.bTime.TabIndex = 1;
            this.bTime.MouseToDown += new System.EventHandler(this.bTime_MouseToDown);
            this.bTime.MouseToUp += new System.EventHandler(this.bTime_MouseToUp);
            // 
            // bChan1
            // 
            this.bChan1.Location = new System.Drawing.Point(501, 114);
            this.bChan1.Name = "bChan1";
            this.bChan1.Size = new System.Drawing.Size(39, 21);
            this.bChan1.TabIndex = 1;
            this.bChan1.MouseToDown += new System.EventHandler(this.bChan1_MouseToDown);
            this.bChan1.MouseToUp += new System.EventHandler(this.bChan1_MouseToUp);
            // 
            // bMeasures
            // 
            this.bMeasures.Location = new System.Drawing.Point(495, 64);
            this.bMeasures.Name = "bMeasures";
            this.bMeasures.Size = new System.Drawing.Size(39, 21);
            this.bMeasures.TabIndex = 1;
            this.bMeasures.MouseToDown += new System.EventHandler(this.bMeasures_MouseToDown);
            this.bMeasures.MouseToUp += new System.EventHandler(this.bMeasures_MouseToUp);
            // 
            // bCursors
            // 
            this.bCursors.Location = new System.Drawing.Point(495, 29);
            this.bCursors.Name = "bCursors";
            this.bCursors.Size = new System.Drawing.Size(39, 21);
            this.bCursors.TabIndex = 1;
            this.bCursors.MouseToDown += new System.EventHandler(this.bCursors_MouseToDown);
            this.bCursors.MouseToUp += new System.EventHandler(this.bCursors_MouseToUp);
            // 
            // bMenu
            // 
            this.bMenu.Location = new System.Drawing.Point(360, 30);
            this.bMenu.Name = "bMenu";
            this.bMenu.Size = new System.Drawing.Size(39, 30);
            this.bMenu.TabIndex = 1;
            this.bMenu.MouseToDown += new System.EventHandler(this.bMenu_MouseToDown_1);
            this.bMenu.MouseToUp += new System.EventHandler(this.bMenu_MouseToUp);
            // 
            // display
            // 
            this.display.Location = new System.Drawing.Point(7, 8);
            this.display.Name = "display";
            this.display.Size = new System.Drawing.Size(348, 270);
            this.display.TabIndex = 0;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(733, 282);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bF5);
            this.Controls.Add(this.bF4);
            this.Controls.Add(this.bF3);
            this.Controls.Add(this.bF2);
            this.Controls.Add(this.bF1);
            this.Controls.Add(this.bStart);
            this.Controls.Add(this.bService);
            this.Controls.Add(this.bMemory);
            this.Controls.Add(this.bHelp);
            this.Controls.Add(this.bDisplay);
            this.Controls.Add(this.bChan0);
            this.Controls.Add(this.bTrig);
            this.Controls.Add(this.bTime);
            this.Controls.Add(this.bChan1);
            this.Controls.Add(this.bMeasures);
            this.Controls.Add(this.bCursors);
            this.Controls.Add(this.bMenu);
            this.Controls.Add(this.display);
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Text = "С8-53";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button bMenu;
        private Button bF1;
        private Button bF2;
        private Button bF3;
        private Button bF4;
        private Button bF5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private Button bCursors;
        private Button bMeasures;
        private Button bDisplay;
        private Button bMemory;
        private Button bHelp;
        private Button bService;
        private Button bStart;
        private Button bChan0;
        private Button bChan1;
        private Button bTime;
        private Button bTrig;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private Display display;
        private System.Windows.Forms.Timer timer1;
    }
}

