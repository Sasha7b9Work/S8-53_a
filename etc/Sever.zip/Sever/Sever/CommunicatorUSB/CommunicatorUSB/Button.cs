﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CommunicatorUSB
{
    public delegate void HandlerEvent();

    public partial class Button : UserControl
    {
        public event EventHandler MouseToDown;
        public event EventHandler MouseToUp;

        public Button()
        {
            InitializeComponent();
        }

        private void button1_MouseUp ( object sender, MouseEventArgs e ) {
            if(MouseToUp != null) {
                MouseToUp(this, e);
            }
        }

        private void button1_MouseDown ( object sender, MouseEventArgs e ) {
            if(MouseToDown != null) {
                MouseToDown(this, e);
            }
        }
    }
}
