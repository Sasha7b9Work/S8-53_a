﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.IO;

namespace CommunicatorUSB
{
    public partial class Display : UserControl
    {
        [DllImport("gdi32")]
        private extern static int SetDIBitsToDevice(HandleRef hDC, int xDest, int yDest, int dwWidth, int dwHeight, int XSrc, int YSrc,
            int uStartScan, int cScanLines, ref int lpvBits, ref BITMAPINFO lpbmi, uint fuColorUse);

        [StructLayout(LayoutKind.Sequential)]
        private struct BITMAPINFOHEADER {
            public int bihSize;
            public int bihWidth;
            public int bihHeight;
            public short bihPlanes;
            public short bihBitCount;
            public int bihCompression;
            public int bihSizeImage;
            public double bihXPelsPerMeter;
            public double bihClrUsed;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct BITMAPINFO {
            public BITMAPINFOHEADER biHeader;
            public int biColors;
        }

        BITMAPINFO bmi;
        int []buffer = new int[320 * 240];
        //IntPtr hDC;
        //HandleRef hDCRef;
        Graphics g;
        //Bitmap bmp;

        public Display()
        {
            InitializeComponent();
            bmi = new BITMAPINFO {
                biHeader = {
                    bihBitCount = 32,
                    bihPlanes = 1,
                    bihSize = 40,
                    bihWidth = 320,
                    bihHeight = 240,
                    bihSizeImage = 320 * 240 * 4
                }
            };

            g = pbDisplay.CreateGraphics();
        }

        public void SetPoint ( int x, int y, Color color ) {
            buffer[x + y * 320] = color.ToArgb();
        }

        int counter = 0;

        public void EndScene (bool saveToFile) {

            Bitmap bmp = new Bitmap(320, 240, PixelFormat.Format32bppArgb);
            BitmapData bmData = bmp.LockBits(new Rectangle(0, 0, 320, 240), ImageLockMode.ReadWrite, bmp.PixelFormat);
            bmData.Stride = 320 * 4;
            Marshal.Copy(buffer, 0, bmData.Scan0, 320 * 240);
            bmp.UnlockBits(bmData);
            pbDisplay.Image = bmp;

            if (saveToFile)
            {
                counter++;
                String strCounter = counter.ToString("D3");
                String name = "c:\\temp\\" + strCounter + ".png";
                bmp.Save(name);
            }
        }

        private void ShowScreen() {

        }

        public void BeginScene() {
            for (int i = 0; i < 320 * 240; i++) {
                buffer[i] = Color.Black.ToArgb();
            }
        }

        public void Fill(Color color) {
            for (int i = 0; i < 320 * 240; i++) {
                buffer[i] = color.ToArgb();
            }
            EndScene(false);
        }

    }
}
