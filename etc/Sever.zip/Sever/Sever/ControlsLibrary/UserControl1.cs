﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlsLibrary
{
    public partial class UserControl1: UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }

        private void UserControl1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Brush backBrush = new SolidBrush(Color.Black);
            RectangleF rect = new RectangleF(0, 0, 10, 10);
            g.FillRectangle(backBrush, rect);
            base.OnPaint(e);
        }
    }
}
