#pragma once

#define ERROR_LOG(...)
