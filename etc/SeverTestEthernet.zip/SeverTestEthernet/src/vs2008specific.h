#pragma once

#ifdef __VS_2008__

#define __INLINE
#define __DSB();
//#define assert_param(x)
#define  PACK_STRUCT_STRUCT

#endif
