#include "Display.h"

void Display_Init() {

}

void Display_DrawRect(int _x, int _y, int _width, int _height) {

}

void Display_DrawText(char *_text, int _x, int _y) {

}

void Display_SetDrawStyle(int _colorFill, int _colorDraw) {

}

void Display_Clear(void) {

}

void Display_DrawCursors(void) {

}

void Display_DrawGrid(void) {

}
