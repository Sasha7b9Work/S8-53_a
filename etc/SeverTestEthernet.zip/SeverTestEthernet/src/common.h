#pragma once

typedef unsigned char uchar;
typedef unsigned int  uint;
typedef int bool;

#define true 1
#define false 0

void IntToStrCat(char *_buffer, int _value);
void CreateDebugMessage(const char* const _messageIn, char* _debugMessage);
