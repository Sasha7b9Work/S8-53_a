#pragma once

void Decoder_ProcessingData(const char *_buffer, uint _length);